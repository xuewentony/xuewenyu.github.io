%  main_TableB1Figure1.m
%  
%  This program replicates the simulation results (Table 1B and Figure 1) reported in 
%  " A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models",
%  by Mohitosh Kejriwal, Pierre Perron and Xuewen Yu. 
%
%  Note: The number of replications can be changed to a smaller number, say 
%   mrep = 10000, to get a quicker output.

clear all; clc;
rng('default'); rng(1000);
mrep = 100000;

% subfigure row 2 column 2
testnum = 2; tau = 0.5; option = 1; cv = 12.11; cvone = 9.50;
dmuall = [0.2 0.4 0.6 0.8 1 2 3 4];  dbeta2 = 0;
errnum = 2; T = 120; re1 = []; tic
for i = 1:length(dmuall)
    dmu = dmuall(i);
    Rej = Func_fig1(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); re1 = [re1, Rej];
end
toc

% subfigure row 2 column 1
testnum = 1; tau = 0.5; option = 1; cv = 12.11; cvone = 9.26;
dmu = 0; dbeta2all = -[0.1 0.2 0.3 0.4 0.5 1 1.5 2];
errnum = 2; T = 120; re2 = []; tic
for i = 1:length(dbeta2all)
    dbeta2 = dbeta2all(i);
    Rej = Func_fig1(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); re2 = [re2, Rej];
end
toc
re12 = [re1; re2]*100;
%csvwrite('fig1_row1.csv',re12)

% subfigure row 1 column 2
testnum = 2; tau = 0.5; option = 1; cv = 12.11; cvone = 9.50;
Tall = [60 120 180 240 300 360 480 600]; dbeta2 = 0; dmu = 1;
errnum = 2; re3 = []; tic
for i = 1:length(Tall)
    T = Tall(i);
    Rej = Func_fig1(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); re3 = [re3, Rej];
end
toc

% subfigure row 1 column 1
testnum = 1; tau = 0.5; option = 1; cv = 12.11; cvone = 9.26;
Tall = [60 120 180 240 300 360 480 600]; dbeta2 = -0.4; dmu = 0;
errnum = 2; re4 = []; tic
for i = 1:length(Tall)
    T = Tall(i);
    Rej = Func_fig1(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); re4 = [re4, Rej];
end
toc
re34 = [re3; re4]*100;
%csvwrite('fig1_row2.csv',re34)

TableB1=[re4([1:4],:); re3([1:4],:); re2([1:4],:); re1([1:4],:)];
csvwrite('TableB1.csv',TableB1);


%%% Plot Figure 1
figure;
re3 = re34(1:5,:); re4 = re34(6:10,:);
idx_T = 1:8; idx_Tnum = [60 120 180 240 300 360 480 600]; 
ana1 = re3(2:5,idx_T); ana2 = re4(2:5,idx_T); 
subplot(2,2,2)
hold on; box on; title('Testing for a change in $\delta_{t}$ in DGP-3b','interpreter','latex','fontweight','bold','FontSize',15)
plot(idx_Tnum,ana1(1,:),'-','color',[0,0,0],'LineWidth',2);
plot(idx_Tnum,ana1(2,:),'-.','color',[0,0,1],'LineWidth',2);
plot(idx_Tnum,ana1(3,:),'--','color',[1,0,0],'LineWidth',2);
%plot(idx_Tnum,ana1(4,:),':','color',[0,1,0],'LineWidth',2);
xlabel('T','FontSize',12);
ylabel('Rejection rate','FontSize',12);

subplot(2,2,1)
hold on; box on; title('Testing for a change in $c_{t}$ in DGP-2b','fontweight','bold','interpreter','latex','FontSize',15)
plot(idx_Tnum,ana2(1,:),'-','color',[0,0,0],'LineWidth',2);
plot(idx_Tnum,ana2(2,:),'-.','color',[0,0,1],'LineWidth',2);
plot(idx_Tnum,ana2(3,:),'--','color',[1,0,0],'LineWidth',2);
%plot(idx_Tnum,ana2(4,:),':','color',[0,1,0],'LineWidth',2);
%legend('test result','1^{st} stage','2^{nd} stage','2^{nd} stage, true break date','location','northeast')
legend('test result','1^{st} stage','2^{nd} stage','location','northeast')
xlabel('T','FontSize',12);
ylabel('Rejection rate','FontSize',12);

re1 = re12(1:5,:); re2 = re12(6:10,:);
idx_mu = 1:8; idx_munum = [0.2 0.4 0.6 0.8 1 2 3 4]; 
idx_beta = 1:8; idx_betanum = [0.1 0.2 0.3 0.4 0.5 1 1.5 2];
ana1 = re1(2:5,idx_mu); ana2 = re2(2:5,idx_beta); 
subplot(2,2,4)
hold on; box on; title('Testing for a change in $\delta_{t}$ in DGP-3b','fontweight','bold','interpreter','latex','FontSize',15)
plot(idx_munum,ana1(1,:),'-','color',[0,0,0],'LineWidth',2);
plot(idx_munum,ana1(2,:),'-.','color',[0,0,1],'LineWidth',2);
plot(idx_munum,ana1(3,:),'--','color',[1,0,0],'LineWidth',2);
%plot(idx_munum,ana1(4,:),':','color',[0,1,0],'LineWidth',2);
xlabel('\Delta_{c}','FontSize',12);
ylabel('Rejection rate','FontSize',12);

subplot(2,2,3)
hold on; box on; title('Testing for a change in $c_{t}$ in DGP-2b','fontweight','bold','interpreter','latex','FontSize',15)
plot(idx_betanum,ana2(1,:),'-','color',[0,0,0],'LineWidth',2);
plot(idx_betanum,ana2(2,:),'-.','color',[0,0,1],'LineWidth',2);
plot(idx_betanum,ana2(3,:),'--','color',[1,0,0],'LineWidth',2);
%plot(idx_betanum,ana2(4,:),':','color',[0,1,0],'LineWidth',2);
xlabel('\Delta_{\delta}','FontSize',12);
ylabel('Rejection rate','FontSize',12);

saveas(gcf,'Figure1','epsc');

