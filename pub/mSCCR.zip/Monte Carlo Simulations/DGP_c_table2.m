% This function construct the Data Generating Process for DGP-panel C in Table 2

function [Y X p q] = DGP_c_table2(T,tau,dmu,dbeta,ddelta,errnum)

eta1 = randn(T,1);  x = eta1+1;
eta2 = randn(T,1);  z = cumsum(eta2); x34=[randn(T,1), cumsum(randn(T,1))];
X = [ones(T,1), x, z, x34]; t = ceil(tau*T);
mu = [1*ones(t,1); (1+dmu)*ones(T-t,1)];
beta = [1*ones(t,1); (1+dbeta)*ones(T-t,1)];
delta = [1*ones(t,1); (1+ddelta)*ones(T-t,1)];
switch errnum
    case 1
        eps = randn(T,1);
    case 2
        e = randn(T,1); eps = zeros(T,1); eps(1) = e(1);
        for i = 2:T
            eps(i) = 0.5*eps(i-1)+e(i);
        end
    case 3
        e = randn(T,1); eps = zeros(T,1); eps(1) = e(1);
        for i = 2:T
            eps(i) = e(i)-0.5*e(i-1);
        end
end
Y = mu+beta.*x+delta.*z+eps; Y=Y+x34*[1; 1];
p = 2; q = 2;

end
