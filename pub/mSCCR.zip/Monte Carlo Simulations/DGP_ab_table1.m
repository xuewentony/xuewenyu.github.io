% This function construct the Data Generating Process for DGP-panel A/B in Table 1

function [Y X p q] = DGP_ab_table1(T,tau,dmu,dbeta2,errnum)

%eta1 = randn(T,1);  x1 = cumsum(eta1);
eta2 = randn(T,1);  x2 = cumsum(eta2); 
X = [ones(T,1), x2]; t = ceil(tau*T);
mu = [1*ones(t,1); (1+dmu)*ones(T-t,1)];
%beta1 = [3*ones(T,1)];
beta2 = [-1*ones(t,1); (-1-dbeta2)*ones(T-t,1)];
switch errnum
    case 1
        eps = randn(T,1);
    case 2
        e = randn(T,1); eps = zeros(T,1); eps(1) = e(1);
        for i = 2:T
            eps(i) = 0.5*eps(i-1)+e(i);
        end
    case 3
        e = randn(T,1); eps = zeros(T,1); eps(1) = e(1);
        for i = 2:T
            eps(i) = e(i)-0.5*e(i-1);
        end
end
Y = mu-beta2.*x2+eps;
p = 0; q = 1;
end

