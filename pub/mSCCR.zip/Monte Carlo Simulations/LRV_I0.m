% This function set calculates the long run variance (hybrid version)
% It contains several functions that is used in the main function LRV_I0.m
function [jhat, jhat_nocor] = LRV_I0(u0,u1,regs);

[nt,d]= size(regs); vmat0 = zeros(nt,d); vmat1 = zeros(nt,d);

for i=1:d
    vmat0(:,i)=regs(:,i).*u0;
	vmat1(:,i)=regs(:,i).*u1;
end
st=bandw(vmat1);

% lag 0 covariance
jhat=vmat0'*vmat0;
% forward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat0(j+1:nt,:)'*vmat0(1:nt-j,:);
end
% backward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat0(1:nt-j,:)'*vmat0(j+1:nt,:);
end
% small sample correction
jhat=jhat/(nt);

jhat_nocor = (u1'*u1/(nt))*regs'*regs/(nt);

end

%%% --- Below are some functions built in the main function LRV_I0.m ---
% This function calculates the bandwidth parameter
function st=bandw(vhat)
% procedure that compute the automatic bandwidth based on AR(1)
% approximation for each vector of the matrix vhat. Each are given equal
% weight 1.
[nt,d]=size(vhat);
a2n=0;
a2d=0;
for i=1:d
    b=olsqr(vhat(2:nt,i),vhat(1:nt-1,i));
    sig=(vhat(2:nt,i)-b*vhat(1:nt-1,i))'*(vhat(2:nt,i)-b*vhat(1:nt-1,i));
    sig=sig/(nt-1);
    a2n=a2n+4*b*b*sig*sig/(1-b)^8;
    a2d=a2d+sig*sig/(1-b)^4;
end
a2=a2n/a2d;
st=1.3221*(a2*nt)^.2;
end

% This function constructs the kernel 
function ker=kern(x)
% procedure to evaluate the quadratic kernel at some value x.
del=6*pi*x/5;
ker=3*(sin(del)/del-cos(del))/(del*del);
end

% This function conducts OLS estimation
function b=olsqr(y,x)
b=inv(x'*x)*x'*y;
end