% This function set calculates KP and two-step test sizes and then generates Figure 1. 
% It contains several functions that is used in the main function Func_fig1.m
function res = Func_fig1(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep)

retwo_5 = zeros(mrep,4);  reone = zeros(mrep,1);
parfor m = 1:mrep

    rng(1*mrep+m, 'twister');
    [y, x] = DGP_ab_table1(T,tau,dmu,dbeta2,errnum);
    [~, k] = size(x);
    [sup_wald_one] = wald(y,x,testnum,option);
    reone(m) = (cvone <= sup_wald_one);     
    
    [rej, rej1, rej2, rej3] = twostep_SB_andtruebr(y,x,cv,testnum,option); retwo_5(m,:) = [rej, rej1, rej2, rej3];
    
end
res = [sum(reone)/mrep; [sum(retwo_5(:,[1,2]))/mrep]'; sum(retwo_5(:,3))/sum(retwo_5(:,2)); sum(retwo_5(:,4))/sum(retwo_5(:,2))];
end

%%% --- Below are some functions built in the main function Func_fig1.m ---
% This function constructs the  KP wald statistic
function [sup_wald, br_ssr]=wald(y,x,testnum,option)

T = length(y);
beta = (x'*x)\(x'*y); u = y-x*beta; ssr0 = u'*u;
t1=round(T*.15); t2=round(T*.85); ssrdiff=zeros(t2-t1+1,1); sigall=zeros(t2-t1+1,1); j=t1;
while j<=t2
    x1 = transx(x,j,testnum);
    b1 = (x1'*x1)\(x1'*y); u1 = y-x1*b1; ssr1 = u1'*u1;
    sigall(j-t1+1,:) = LRV(u,u1);
    ssrdiff(j-t1+1,:)=(ssr0-ssr1);
    j=j+1;
end
[~, maxssrdiff_loc] = max(ssrdiff);
br_ssr = maxssrdiff_loc+t1-1;

if option == 1   % option 1 estimate all LRV
    
    f = ssrdiff./sigall;
    [sup_wald, maxf_loc] = max(f);
    br_f = maxf_loc+t1-1;
    
elseif option == 2  % option 2 estimate under optimal break point LRV
    
    f = ssrdiff/sigall(maxssrdiff_loc);
    [sup_wald, maxf_loc] = max(f);
    br_f = maxf_loc+t1-1;
    
end
end

% This function conducts the two-step test, result=1 means rejection, result=0 means non-rejection.
function [res, rej1, rej2, rej3] = twostep_SB_andtruebr(y,x,cv,testnum,option)

[T, k] = size(x);
[sup_wald, br] = wald(y,x,[1:k],option); br2 = T*0.5;
rej1 = (cv <= sup_wald); rej2 = 0; rej3 = 0;
if rej1 == 1
    xnew = transx(x,br,setdiff(1:k,testnum));
    beta = (xnew'*xnew)\(xnew'*y); u = y-xnew*beta; ssr0 = u'*u;
    xnew2 = transx(xnew,br,1:length(testnum));
    beta2 = (xnew2'*xnew2)\(xnew2'*y); u2 = y-xnew2*beta2; ssr1 = u2'*u2;
    sigsq = LRV(u,u2);
    F = (ssr0-ssr1)/sigsq; rej2 = (chi2inv(0.95,length(testnum)) <= F);
    %% 5% default significance, other levels are subject to change
	
	xnew3 = transx(xnew,br2,1:length(testnum));
    beta3 = (xnew3'*xnew3)\(xnew3'*y); u3 = y-xnew3*beta3; ssr3 = u3'*u3;
    sigsq = LRV(u,u3);
    F = (ssr0-ssr3)/sigsq; rej3 = (chi2inv(0.95,length(testnum)) <= F);
end
res = rej1*rej2;
end

% This function calculates the long run variance.
function [omega] = LRV(ur,uu)

T = length(ur);
eb=uu(1:T-1); ef=uu(2:T); rho=(eb'*ef)/(eb'*eb);
a2=4*rho^2/(1-rho)^4; eband=1.3221*(a2*T)^.2;

jb=((1:(T-1))/eband)'; jband=jb*1.2*pi;
kern = ((sin(jband)./jband - cos(jband))./(jband.^2)).*3;

sig=ur'*ur; lam=0; j=1;
while j<=T-1
    lam=lam+(ur(1:T-j)'*ur(1+j:T))*kern(j);
    j=j+1;
end
omega=(sig+2*lam)/T;
end

% This function constructs the reconstructed matrix given break date used in various scenarios.
function [xnew, xtest, xrest] = transx(x,t,testno)

[T,p] = size(x); len = length(testno);
xtest = [[x(1:t,testno); zeros(T-t,len)], [zeros(t,len); x(t+1:T,testno)]];
xrest = x(:,setdiff(1:p,testno));
xnew = [xrest, xtest];

end