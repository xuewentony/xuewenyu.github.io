%  main_Table1.m
%  
%  This program replicates the simulation results (Table 1) reported in 
%  " A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models",
%  by Mohitosh Kejriwal, Pierre Perron and Xuewen Yu. 
%
%  Note: The number of replications can be changed to a smaller number, say 
%   mrep = 1000, to get a quicker output. 

clear all; clc;
rng('default'); rng(1000);
mrep = 100000;
Table1=[];

% Panel A
testnum = 2; tau = 0.5; option = 1; cv = 12.11; cvone = 9.50; %% cvone from KP wpversion
dall = [0 0; 0 -0.4; 1 0; 1 -0.4];
res=[]; tic
for T=[120 240]
    re2 = []; 
    for errnum = 1:3
        re1 = []; 
        for i = 1:4
            dmu = dall(i,1); dbeta2 = dall(i,2);			
			Rej = Func_table1ab(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); 			
            re1 = [re1, Rej]; 
        end
        re2 = [re2; re1]; 
    end
    res=[res, re2]; 
end
toc
Table1=[Table1; res];

% Panel B
testnum = 1; tau = 0.5; option = 1; cv = 12.11; cvone = 9.26; %% cvone from KP, for the rest, if unstated, from KP 
dall = [0 0; 0 -0.4; 1 0; 1 -0.4];
res=[]; tic
for T=[120 240]
    re2 = []; 
    for errnum = 1:3
        re1 = []; 
        for i = 1:4
            dmu = dall(i,1); dbeta2 = dall(i,2);			
			Rej = Func_table1ab(T,tau,dmu,dbeta2,errnum,testnum,cv,cvone,option,mrep); 			
            re1 = [re1, Rej]; 
        end
        re2 = [re2; re1]; 
    end
    res=[res, re2]; 
end
toc
Table1=[Table1; res];

% Panel C
testnum = 2; tau = 0.5; option = 1; cv = 13.24; cvone = 8.58; %% cvone-from BP
dall = [0 0 0.4; 0 2 0.4; 1 0 0; 1 2 0.4];
res=[]; tic
for T=[120 240]
    re2 = []; 
    for errnum = 1:3
        re1 = []; 
        for i = 1:4
            dmu = dall(i,1); dbeta = dall(i,2); ddelta = dall(i,3);
            Rej = Func_table1c(T,tau,dmu,dbeta,ddelta,errnum,testnum,cv,cvone,option,mrep);
            re1 = [re1, Rej]; 
        end
        re2 = [re2; re1]; 
    end
    res=[res, re2]; 
end
toc
Table1=[Table1; res];

csvwrite('Table1.csv',Table1);

