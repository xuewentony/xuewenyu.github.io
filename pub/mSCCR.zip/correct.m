% This function is from m-break-matlab.zip (http://blogs.bu.edu/perron/codes/), 
% developed by Yohei Yamamoto.
%
% This is a procedures which activates the computation of robust standard errors
function hac=correct(reg,res,prewhit)

[nt,d]= size(reg);
b     = zeros(d,1);
bmat  = zeros(d,d);
vstar = zeros(nt-1,d);
vmat  = zeros(nt,d);

% First construct the matrix z_t*u_t.

for i=1:d
    vmat(:,i)=reg(:,i).*res;
end

% Procedure that applies prewhitenning to the matrix vmat by filtering with
% a VAR(1). If prewhit=0, it is skipped.

if prewhit==1;
    
    for i=1:d
        b = olsqr(vmat(2:nt,i),vmat(1:nt-1,:));
        bmat(i,:)=b';
        vstar(:,i)=vmat(2:nt,i)-vmat(1:nt-1,:)*b;
    end
    
    % Call the kernel on the residuals
    
    jh = jhatpr(vstar);
    
    % recolor
    
    hac = inv(eye(d)-bmat)*jh*(inv(eye(d)-bmat))';
    
else
    hac = jhatpr(vmat);     
end
end


function jhat=jhatpr(vmat)

% procedure to compute the long-run covariance matrix of vmat.

[nt,d]=size(vmat);
jhat=zeros(d,d);

% calling the automatic bandwidth selection

st=bandw(vmat);

% lag 0 covariance

jhat=vmat'*vmat;

% forward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat(j+1:nt,:)'*vmat(1:nt-j,:);
end

% backward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat(1:nt-j,:)'*vmat(j+1:nt,:);
end

% small sample correction
jhat=jhat/(nt-d);

end

function st=bandw(vhat)

% procedure that compute the automatic bandwidth based on AR(1)
% approximation for each vector of the matrix vhat. Each are given equal
% weight 1.

[nt,d]=size(vhat);
a2n=0;
a2d=0;
for i=1:d
    b=olsqr(vhat(2:nt,i),vhat(1:nt-1,i));
    sig=(vhat(2:nt,i)-b*vhat(1:nt-1,i))'*(vhat(2:nt,i)-b*vhat(1:nt-1,i));
    sig=sig/(nt-1);
    a2n=a2n+4*b*b*sig*sig/(1-b)^8;
    a2d=a2d+sig*sig/(1-b)^4;
end
a2=a2n/a2d;
st=1.3221*(a2*nt)^.2;
end

function ker=kern(x)

% procedure to evaluate the quadratic kernel at some value x.

del=6*pi*x/5;
ker=3*(sin(del)/del-cos(del))/(del*del);
end   