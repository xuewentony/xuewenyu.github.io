%  main_Table5.m
%  
%  This program replicates the empirical results (Table 5) reported in 
%  " A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models",
%  by Mohitosh Kejriwal, Pierre Perron and Xuewen Yu. 
%
%  PART-I is log-log form; PART-II is semi-log form

clear all; clc;

%%%%============ PART-I: Log-Log form ================
dataraw=readmatrix('DATA.txt'); data=dataraw(1:208,:);
MdP=data(:,5); YdP=data(:,3); r=data(:,8);
m=data(:,10); T = length(data(:,1));
M = 5; eps_trim = 0.15; siglev = 0.05;
opt_tr = 0; opt_sercorr = 1;
opt_endo = 1; l_T = 4;

%%%%%%% without restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(MdP); z=[log(YdP), log(r)];
[nb, brdate, UD_F_full, UD_cv_full] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[138];
vec3=mod(vec,4)+1; %break month

%%%%%%% with restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(m); z=log(r);
xfix =[]; xbr=[z, x];
[Mat_est_Res, Mat_wc_Res, res_Res] = get_BootCI_loglog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,1);  %Bootstrap CI

%%% organize the results table
% Table5 (Panel A): regime-wise estimates and CI
m1=[Mat_est_Res(:,1:3), Mat_wc_Res(:,1:3)];
m2=[Mat_est_Res(:,4:6), Mat_wc_Res(:,4:6)];
m3=[Mat_est_Res(:,7:9), Mat_wc_Res(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table=cell2table(Table);
for i=1:2*len1 table(i,2)={'-'}; end
Table5_A=[table];


%%%%============ PART-II: Semi-Log form ================
MdP=data(:,5); YdP=data(:,3); r=data(:,8);
m=data(:,10); T = length(data(:,1));
M = 5; eps_trim = 0.15; siglev = 0.05;
opt_tr = 0; opt_sercorr = 1;
opt_endo = 1; l_T = 4;

%%%%%%% without restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(MdP); z=[log(YdP), r];
[nb, brdate, UD_F_full, UD_cv_full] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[137];
vec3=mod(vec,4)+1; %break month

%%%%%%% with restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(m); z=r;
xfix =[]; xbr=[z, x];
[Mat_est_Res, Mat_wc_Res, res_Res] = get_BootCI_semilog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,1);  %Bootstrap CI

%%% organize the results table
% Table5 (Panel B): regime-wise estimates and CI
m1=[Mat_est_Res(:,1:3), Mat_wc_Res(:,1:3)];
m2=[Mat_est_Res(:,4:6), Mat_wc_Res(:,4:6)];
m3=[Mat_est_Res(:,7:9), Mat_wc_Res(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table=cell2table(Table);
for i=1:2*len1 table(i,2)={'-'}; end
Table5_B=[table];

%%% save results Table3, Table4
Table5=[Table5_A; Table5_B];
writetable(Table5,'Table5.xls','WriteVariableNames',0);



