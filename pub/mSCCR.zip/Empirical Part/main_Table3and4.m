%  main_Table3and4.m
%  
%  This program replicates the empirical results (Table 3 and 4) reported in 
%  " A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models",
%  by Mohitosh Kejriwal, Pierre Perron and Xuewen Yu. 
%
%  PART-I is log-log form; PART-II is semi-log form

clear all; clc;

%%%%============ PART-I: Log-Log form ================
dataraw=readmatrix('DATA.txt'); data=dataraw(1:208,:);
MdP=data(:,5); YdP=data(:,3); r=data(:,8);
m=data(:,10); T = length(data(:,1));
M = 5; eps_trim = 0.15; siglev = 0.05;
opt_tr = 0; opt_sercorr = 1;
opt_endo = 1; l_T = 4;

%%%%%%% without restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(MdP); z=[log(YdP), log(r)];
[nb, brdate, UD_F_full, UD_cv_full] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[138];
vec3=mod(vec,4)+1; %break month
[stats_full, cv_full] = AKtest(y,x,z,nb,brdate,l_T,siglev);
%%%---------Purpose (II)------------
% testvec (vector of parameters under testing) is the order number (or vector of numbers) of the column(s) of the full design matrix Xfull.
% Xfull is specified column-wisely (from the left to the right) by: intercept (by default), I(0) regressors (if any), I(1) regressors.
if nb ~= 0
    testvec = [1]; Xfull = [x, z];
    [testre_1, F_nb_full_1, chi_nb_full_1] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [2]; Xfull = [x, z];
    [testre_2, F_nb_full_2, chi_nb_full_2] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [3]; Xfull = [x, z];
    [testre_3, F_nb_full_3, chi_nb_full_3] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end

xfix =[]; xbr=[z, x];
[Mat_est_noRes, Mat_wc_noRes, res_noRes] = get_BootCI_loglog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,0,YdP); %Bootstrap CI

%%%%%%% with restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(m); z=log(r);
[nb, brdate, UD_F, UD_cv, datevec] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T); 
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[38, 68];
vec3=mod(vec,4)+1; %break month
[stats, cv] = AKtest(y,x,z,nb,brdate,l_T,siglev);

%%%---------Purpose (II)------------
% testvec (vector of parameters under testing) is the order number (or vector of numbers) of the column(s) of the full design matrix Xfull.
% Xfull is specified column-wisely (from the left to the right) by: intercept (by default), I(0) regressors (if any), I(1) regressors.
if nb ~= 0
    testvec = [1]; Xfull = [x, z];
    [testre_1, F_nb_1, chi_nb_1] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [2]; Xfull = [x, z];
    [testre_2, F_nb_2, chi_nb_2] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end

xfix =[]; xbr=[z, x];
[Mat_est_Res, Mat_wc_Res, res_Res] = get_BootCI_loglog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,1);  %Bootstrap CI

%%% organize the results table
% Table3 (left): Two-step and AK tests
Table3_left=[[stats_full, cv_full]; [UD_F_full, UD_cv_full]; ...
[F_nb_full_1, chi_nb_full_1]; [F_nb_full_2, chi_nb_full_2]; [F_nb_full_3, chi_nb_full_3]; ...
[stats, cv]; [UD_F, UD_cv]; [F_nb_1, chi_nb_1]; [F_nb_2, chi_nb_2]];

% Table4 (A1A2): regime-wise estimates and CI
m1=[Mat_est_noRes(:,1:3), Mat_wc_noRes(:,1:3)];
m2=[Mat_est_noRes(:,4:6), Mat_wc_noRes(:,4:6)];
m3=[Mat_est_noRes(:,7:9), Mat_wc_noRes(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table1=cell2table(Table);

m1=[Mat_est_Res(:,1:3), Mat_wc_Res(:,1:3)];
m2=[Mat_est_Res(:,4:6), Mat_wc_Res(:,4:6)];
m3=[Mat_est_Res(:,7:9), Mat_wc_Res(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table2=cell2table(Table);
for i=1:2*len1 table2(i,2)={'-'}; end
Table4_A1A2=[table1; table2];


%%%%============ PART-II: Semi-Log form ================
MdP=data(:,5); YdP=data(:,3); r=data(:,8);
m=data(:,10); T = length(data(:,1));
M = 5; eps_trim = 0.15; siglev = 0.05;
opt_tr = 0; opt_sercorr = 1;
opt_endo = 1; l_T = 4;

%%%%%%% without restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(MdP); z=[log(YdP), r];
[nb, brdate, UD_F_full, UD_cv_full] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[137];
vec3=mod(vec,4)+1; %break month
[stats_full, cv_full] = AKtest(y,x,z,nb,brdate,l_T,siglev);
%%%---------Purpose (II)------------
% testvec (vector of parameters under testing) is the order number (or vector of numbers) of the column(s) of the full design matrix Xfull.
% Xfull is specified column-wisely (from the left to the right) by: intercept (by default), I(0) regressors (if any), I(1) regressors.
if nb ~= 0
    testvec = [1]; Xfull = [x, z];
    [testre_1, F_nb_full_1, chi_nb_full_1] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [2]; Xfull = [x, z];
    [testre_2, F_nb_full_2, chi_nb_full_2] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [3]; Xfull = [x, z];
    [testre_3, F_nb_full_3, chi_nb_full_3] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end

xfix =[z(:,2)]; xbr=[z(:,1), x];
[Mat_est_noRes, Mat_wc_noRes, res_noRes] = get_BootCI_semilog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,0,YdP);  %Bootstrap CI

%%%%%%% with restriction
%%%---------Purpose (I)------------
x=[ones(T,1)]; y=log(m); z=r;
[nb, brdate, UD_F, UD_cv, datevec] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
vec=brdate+1; vec2=floor(vec/4)+1959;  %break year, results is vec=[37, 67, 98];
vec3=mod(vec,4)+1; %break month
[stats, cv] = AKtest(y,x,z,nb,brdate,l_T,siglev);
%%%---------Purpose (II)------------
% testvec (vector of parameters under testing) is the order number (or vector of numbers) of the column(s) of the full design matrix Xfull.
% Xfull is specified column-wisely (from the left to the right) by: intercept (by default), I(0) regressors (if any), I(1) regressors.
if nb ~= 0
    testvec = [1]; Xfull = [x, z];
    [testre_1, F_nb_1, chi_nb_1] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
    testvec = [2]; Xfull = [x, z];
    [testre_2, F_nb_2, chi_nb_2] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end

xfix =[]; xbr=[z, x];
[Mat_est_Res, Mat_wc_Res, res_Res] = get_BootCI_semilog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,1);  %Bootstrap CI

%%% organize the results table
% Table3 (right): Two-step and AK tests
Table3_right=[[stats_full, cv_full]; [UD_F_full, UD_cv_full]; ...
[F_nb_full_1, chi_nb_full_1]; [F_nb_full_2, chi_nb_full_2]; [F_nb_full_3, chi_nb_full_3]; ...
[stats, cv]; [UD_F, UD_cv]; [F_nb_1, chi_nb_1]; [F_nb_2, chi_nb_2]];

% Table4 (B1B2): regime-wise estimates and CI
m1=[Mat_est_noRes(:,1:3), Mat_wc_noRes(:,1:3)];
m2=[Mat_est_noRes(:,4:6), Mat_wc_noRes(:,4:6)];
m3=[Mat_est_noRes(:,7:9), Mat_wc_noRes(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table1=cell2table(Table);

m1=[Mat_est_Res(:,1:3), Mat_wc_Res(:,1:3)];
m2=[Mat_est_Res(:,4:6), Mat_wc_Res(:,4:6)];
m3=[Mat_est_Res(:,7:9), Mat_wc_Res(:,7:9)];
[len1, len2]=size(m1); Table=[];
for i=1:len1
    temp1=[];
    for j=1:len2
        m1_ij=m1(i,j); mm1=num2str(m1_ij,'%.2f');
        if abs(m1_ij)<1 if m1_ij<0 mm1(2) = []; else mm1(1) = []; end; end
        m2_ij=m2(i,j); mm2=num2str(m2_ij,'%.2f');
        if abs(m2_ij)<1 if m2_ij<0 mm2(2) = []; else mm2(1) = []; end; end
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.2f');
        if abs(m3_ij)<1 if m3_ij<0 mm3(2) = []; else mm3(1) = []; end; end
        temp2=[mm1; split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table=[Table; temp1];
end
table2=cell2table(Table);
for i=1:2*len1 table2(i,2)={'-'}; end
Table4_B1B2=[table1; table2];

%%% save results Table3, Table4
Table3=[Table3_left, Table3_right];
Table4=[Table4_A1A2; Table4_B1B2];
csvwrite('Table3.csv',Table3)
writetable(Table4,'Table4.xls','WriteVariableNames',0);



