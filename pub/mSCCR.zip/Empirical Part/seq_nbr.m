% This function conducts the sequential procedure to determine the number of breaks.
% Input:
%   y: the regressand
%   z: I(1) regressors
%   x: I(0) regressors (if any, and always include the intercept as default)
%   M: the maximum number of breaks allowed, default is 5
%   eps_trim: trimming value, 0.15 is the default level and the only option
%   siglev: significance level
%   opt_tr: =0, nontredning case; =1 trending case
%   opt_sercorr: =0, no serial correlation correction; =1 with serial correlation correction (default)
%   opt_endo: =0, no endogenity correction; =1 with endogenity correction (default)
%   l_T: the leads/lag length, set by the users
%
% Output:
%   nb: number of breaks detected from the sequential procedure
%   brdate: corresponding break dates, if no breaks detected, return null.
%   UD_F: UDmax test statistic result
%   UD_cv: critical values of UDmax test statistic's asymptotic distribution
%   datevec: dates vector

%  including intercept as default
function [nb, brdate, UD_F, UD_cv, datevec] = seq_br(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T)

%%%-----------UDmax test first for initialization---------------------
T = length(y); h = round(eps_trim*T);
if opt_endo == 0
    X = [x, z]; pq = length(X(1,:)); zlag = []; lagdim = 0; l_T = 0;
    [glb datevec bigvec] = dating(y,X,h,M,pq,T);
elseif opt_endo == 1
    cov_eps = 1e-4; maxi = 20; fixb = 0; betaini = 0; printd = 0;
    zlag = leadslag(z,l_T); [T, lagdim] = size(zlag);
    X = [x(l_T+2:end-l_T,:), z(l_T+2:end-l_T,:)]; y = y(l_T+2:end-l_T);
    pq = length(X(1,:)); h = round(eps_trim*T);
    [glb,datevec,bigvec] = nldat(y,X,zlag,h,M,lagdim,pq,T,fixb,cov_eps,maxi,betaini,printd);
end

p=0; if length(x(1,:))~=1 p = length(x(1,:))-1; end; q = length(z(1,:));
[UD_F, supF_i] = UDmax(y,X,M,p,pq,T,datevec,zlag,lagdim,opt_sercorr);
[UD_cv, cv_i] = get_UDcv(M,p,q,opt_tr,eps_trim,siglev);

%%%-----------sequential procedure---------------------
if UD_F <= UD_cv
    nb = 0; fprintf('No breaks detected. \n \n');
    brdate = [];
else
    stop_k = 0; i = 1;
    while stop_k == 0 && i <= M
        
        if p~=0
            prewhit = 0; hetdat = 1; hetvar = 1; robust = 1; if opt_sercorr == 0 robust = 0;  end
            [supfl] = spflp1(bigvec,datevec(1:i,i),i+1,y,X,h,pq,prewhit,robust,zlag,lagdim,hetdat,hetvar);
        elseif p==0
            supfl=spflp1_p0(datevec(1:i,i),i+1,y,X,h,pq,zlag,lagdim,eps_trim);
        end
        cv_sqk = get_SEQcv(i,p,q,opt_tr,eps_trim,siglev);
        if supfl <= cv_sqk
            stop_k = 1; nb = i;
        end
        i = i+1;
    end
    if i == M+1
        nb = M;
    end
    brdate = datevec(1:nb,nb)+l_T;
    fprintf(strcat(num2str(nb),' break(s) detected, they are at ',num2str(brdate'+1),'. \n \n'));
end

end

%%% --- Below are some functions built in the main function seq_br.m ---
% This is a procedure that computes the supF(l+1|l) test 
function supfl=spflp1_p0(brdate,m,y,X,h,pq,zlag,lagdim,eps_trim);
T=length(y); datevec=[0; brdate; T];
Xbar=pzbar(X,m-1,brdate);
[~, ur]=olsqr(y, [Xbar, zlag]); SSR0=ur'*ur;
ssralter=[]; adddate=[]; uall=[];
for i=1:m
    di=datevec(i)+1:datevec(i+1); Ti=length(di); hi=min([ceil(Ti*eps_trim),pq+lagdim+1]);
    t1=di(1)+hi;
    while t1<=di(end)-hi+1
        nbrdate=sort([t1; brdate]); nXbar=pzbar(X,m,nbrdate);
        [~, uu_t1]=olsqr(y, [nXbar, zlag]); uall=[uall, uu_t1]; adddate=[adddate; t1];
        ssralter=[ssralter; uu_t1'*uu_t1]; t1=t1+1;
    end
end
[SSR1, minloc]=min(ssralter); uu=uall(:,minloc);
lrv=LRV(ur,uu); supfl=(SSR0-SSR1)/lrv;
end

% This function calculates long run variance
function [omega] = LRV(ur,uu)
T = length(ur);
eb=uu(1:T-1); ef=uu(2:T); rho=(eb'*ef)/(eb'*eb);
a2=4*rho^2/(1-rho)^4; eband=1.3221*(a2*T)^.2;

jb=((1:(T-1))/eband)'; jband=jb*1.2*pi;
kern = ((sin(jband)./jband - cos(jband))./(jband.^2)).*3;

sig=ur'*ur; lam=0; j=1;
while j<=T-1
    lam=lam+(ur(1:T-j)'*ur(1+j:T))*kern(j);
    j=j+1;
end
omega=(sig+2*lam)/T; 
end 