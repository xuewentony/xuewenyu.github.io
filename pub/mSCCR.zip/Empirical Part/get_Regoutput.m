% This function set computes the regime-wise estimates
% It contains several functions that is used in the main function get_Regoutput.m
function [beta, res, varcov, hacvarcov, hacsd, t_hac, t_standard, y, X] = get_Regoutput(y,xfix,xbr,z,x,m,brdate,opt_tr,opt_sercorr,opt_endo,l_T)

bigt = length(y); 
if opt_endo == 0
    if ~isempty(xbr) Xbr=pzbar(xbr,m,brdate); else Xbr=[]; end
    X = [Xbr, xfix]; pq = length(X(1,:)); zlag = []; lagdim = 0; l_T = 0;
    [beta, res, varcov, hacvarcov, hacsd, t_hac, t_standard] = ols(y,X);
elseif opt_endo == 1
    zlag = leadslag(z,l_T); [bigt, lagdim] = size(zlag);
	if ~isempty(xbr) Xbr=pzbar(xbr,m,brdate); else Xbr=[]; end
	X = [Xbr(l_T+2:end-l_T,:), xfix(l_T+2:end-l_T,:), zlag];
    y = y(l_T+2:end-l_T);
    pq = length(X(1,:));
    [beta, res, varcov, hacvarcov, hacsd, t_hac, t_standard] = ols(y,X);
end

end

%%% --- Below are some functions built in the main function get_Regoutput.m ---
% This function calculates OLS estimates 
function [beta, res, varcov, hacvarcov, hacsd, t_hac, t_standard] = ols(y,x);

[T, k] = size(x);
invxx = inv(x'*x);
beta = invxx*x'*y;
res = y-x*beta;
sigsq = res'*res/(T-k);
varcov = sigsq*invxx;
t_standard=beta./diag(sqrt(varcov));

vmat  = zeros(T,k);
for i=1:k
    vmat(:,i)=x(:,i).*res;
end
hacvarcov=T*invxx*jhatpr(vmat)*invxx;
hacsd = diag(sqrt(hacvarcov)); t_hac=beta./hacsd;
end

% This function constructs certain quantities in long run variance term, it is originally from m-break-matlab.zip %(http://blogs.bu.edu/perron/codes/), developed by Yohei Yamamoto.
function jhat=jhatpr(vmat)

% procedure to compute the long-run covariance matrix of vmat.

[nt,d]=size(vmat);
jhat=zeros(d,d);

% calling the automatic bandwidth selection

st=bandw(vmat);

% lag 0 covariance

jhat=vmat'*vmat;

% forward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat(j+1:nt,:)'*vmat(1:nt-j,:);
end

% backward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*vmat(1:nt-j,:)'*vmat(j+1:nt,:);
end

% small sample correction
jhat=jhat/(nt-d);

end

% This function constructs bandwidth parameter in long run variance term, it is originally from m-break-matlab.zip %(http://blogs.bu.edu/perron/codes/), developed by Yohei Yamamoto.
function st=bandw(vhat)

% procedure that compute the automatic bandwidth based on AR(1)
% approximation for each vector of the matrix vhat. Each are given equal
% weight 1.

[nt,d]=size(vhat);
a2n=0;
a2d=0;
for i=1:d
    b=olsqr(vhat(2:nt,i),vhat(1:nt-1,i));
    sig=(vhat(2:nt,i)-b*vhat(1:nt-1,i))'*(vhat(2:nt,i)-b*vhat(1:nt-1,i));
    sig=sig/(nt-1);
    a2n=a2n+4*b*b*sig*sig/(1-b)^8;
    a2d=a2d+sig*sig/(1-b)^4;
end
a2=a2n/a2d;
st=1.3221*(a2*nt)^.2;
end

% This function constructs kernel functions in long run variance term, it is originally from m-break-matlab.zip %(http://blogs.bu.edu/perron/codes/), developed by Yohei Yamamoto.
function ker=kern(x)

% procedure to evaluate the quadratic kernel at some value x.

del=6*pi*x/5;
ker=3*(sin(del)/del-cos(del))/(del*del);
end   



