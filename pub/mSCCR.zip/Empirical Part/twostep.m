% This function conducts the two-step tests for structural breaks in cointegrated regressions.
% Input:
%   y: the regressand
%   z: I(1) regressors
%   x: I(0) regressors (if any, and always include the intercept as default)
%   Xfull: = [x, z], full design matrix, which is specified column-wisely (from the left to the right) by:
%      intercept (by default), I(0) regressors (if any), I(1) regressors.
%   testvec: the order number (or vector of numbers) of the column(s) of the full design matrix X
%   nb: number of breaks from the output of seq_br.m
%   brdate: corresponding break dates from the output of seq_br.m
%   eps_trim: trimming value, 0.15 is the default level and the only option
%   siglev: significance level
%   opt_tr: =0, nontredning case; =1 trending case
%   opt_sercorr: =0, no serial correlation correction; =1 with serial correlation correction (default)
%   opt_endo: =0, no endogenity correction; =1 with endogenity correction (default)
%   l_T: the leads/lag length, set by the users
%
% Output:
%   testre: test result, =0, testing vector is not time varying; =1, testing vector is time varying
%   F_nb: the test statistic result
%   chi_nb: the corresponding critical values

function [testre, F_nb, chi_nb] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T)

%%%-------construct the new design matrix-----------
bigt = length(y); i = nb; testdim = length(testvec); restvec = setdiff([1:length(Xfull(1,:))]',testvec);
Xtest = Xfull(:,testvec); Xrest = Xfull(:,restvec);
if opt_endo == 0
    l_T = 0; zlag = []; lagdim = 0; if isempty(restvec) Xrestbar = []; else Xrestbar = pzbar(Xrest,i,brdate-l_T); end
    Xtest = Xtest;
elseif opt_endo == 1
    cov_eps = 1e-4; maxi = 20; fixb = 0; betaini = 0; printd = 0;
    zlag = leadslag(z,l_T); [bigt, lagdim] = size(zlag);
	if isempty(restvec) 
	Xrest = []; Xrestbar = []; 
	else  
    Xrest = Xrest(l_T+2:end-l_T,:); Xrestbar = pzbar(Xrest,i,brdate-l_T);
	end
    y = y(l_T+2:end-l_T); Xtest = Xtest(l_T+2:end-l_T,:);
end

%%%-------construct the F-test-------------
rsub=zeros(i,i+1); j=1;
while j <= i
    rsub(j,j)=-1; rsub(j,j+1)=1; j=j+1;
end
rmat=kron(rsub,eye(testdim));
Xtestbar=pzbar(Xtest,i,brdate-l_T);
[dbdel, uu]=olsqr(y,[Xtestbar, Xrestbar, zlag]);
delta=dbdel(1:(i+1)*testdim,1);
p=0; if length(x(1,:))~=1 p=length(x(1,:))-1; end;
if p ~= 0
prewhit = 0; hetdat = 1; hetvar = 1; robust = 1; if opt_sercorr == 0 robust = 0;  end
Xrestbarzlag = [Xrestbar, zlag]; lagrestdim = length(Xrestbarzlag(1,:));
vdel=pvdel(y,Xtest,i,testdim,bigt,brdate-l_T,prewhit,robust,Xrestbarzlag,lagrestdim,0,hetdat,hetvar);   %%% Need to modify this part
fstar=delta'*rmat'*inv(rmat*vdel*rmat')*rmat*delta;
F_nb=(bigt-(i+1)*testdim-lagrestdim)*fstar/(bigt*i);
elseif p==0
[~, ur]=olsqr(y,[Xtest, Xrestbar, zlag]);
lrv=LRV(ur,uu); ssrdiff=ur'*ur-uu'*uu;
F_nb=ssrdiff/lrv;
end

%%%-------test result-------------
chi_nb = chi2inv(1-siglev,i*testdim);
if F_nb > chi_nb testre = 1; disp('The parameter(s) under testing is time-varying under estimated break dates.');
else testre = 0; disp('The parameter(s) under testing is not time-varying under estimated break dates.'); end

end

% This function calculates long run variance
function [omega] = LRV(ur,uu)
T = length(ur);
eb=uu(1:T-1); ef=uu(2:T); rho=(eb'*ef)/(eb'*eb);
a2=4*rho^2/(1-rho)^4; eband=1.3221*(a2*T)^.2;

jb=((1:(T-1))/eband)'; jband=jb*1.2*pi;
kern = ((sin(jband)./jband - cos(jband))./(jband.^2)).*3;

sig=ur'*ur; lam=0; j=1;
while j<=T-1
    lam=lam+(ur(1:T-j)'*ur(1+j:T))*kern(j);
    j=j+1;
end
omega=(sig+2*lam)/T;
end