% This function gets the critical values for the SupF(k) and UDmax(M) in Kejriwal and Perron (2010).
% Input:
%   M: the maximum number of breaks allowed, default is 5
%   p: number of I(0) variables
%   q: number of I(1) variables
%   opt_tr: =0, nontredning case, =1 trending case 
%   eps_trim: trimming value, 0.15 is the default level and the only option
%   siglev: significance level
%
% Output:
%   UD_cv: corresponding UDmax critical value 
%   cv_k: corresponding SupF(k) critical values, the result is a matrix of dimension (1x5) 
function [UD_cv, cv_k] = get_UDcv(M,p,q,opt_tr,eps_trim,siglev)

if p == 0 && q == 1
cv = ...
[        10.34         8.85         7.66         6.66          5.3        10.53        11.18         9.25         8.09         6.95         5.53        11.33;
        12.11         9.96          8.6         7.36          5.9        12.25        13.03        10.39         8.94          7.6         6.12        13.07;
        13.85        11.41          9.4         7.99         6.42        13.91        15.08        11.49         9.66         8.28         6.67        15.13;
        17.03        12.41         10.4         8.71         7.08         17.4        16.86        12.73        10.82         8.95         7.32        16.86];
		
elseif p == 0 && q == 2
cv = ...
[        12.36        11.01          9.6         8.45         6.96        12.64        11.88        10.31            9         7.98         6.62        12.13;
         14.3        12.11        10.41         9.19         7.64        14.47        13.63        11.34         9.94         8.68         7.31        13.99;
        15.72        13.37        11.26         9.75         8.15         15.9        15.51        12.57        10.86         9.37         7.92        15.53;
        17.67        14.73        12.21        10.77         8.82        17.67        17.31        14.63         12.1        10.51         8.73        17.31];
		
elseif p == 0 && q == 3
cv = ...
[        14.88        12.84        11.49        10.19         8.53        15.09        14.39        12.14        10.79         9.61         8.22        14.65;
        16.66        14.11        12.38        10.94         9.12        16.71         16.5        13.22        11.66        10.33         8.92        16.61;
        18.32        15.24        13.01        11.52         9.61        18.35        18.08        14.45        12.54        11.04         9.44        18.24;
        20.78        16.29        14.36        12.37        10.23        20.78        20.28        15.55         13.8        12.02         10.1        20.28];
		
elseif p == 0 && q == 4
cv = ...
[        16.87        14.72         13.2        11.75          9.9        17.05        16.27         13.8        12.41        11.17         9.62        16.46;
        19.08         15.9        14.15        12.68        10.72        19.16        18.36        15.08        13.38        12.07        10.28        18.46;
        20.81        17.15        15.21        13.38        11.43        20.89        20.52        17.01        14.33        12.98        10.93        20.52;
        22.59        18.85        16.44        14.25        11.98        22.59        23.12        18.71        15.77        13.87        11.72        23.12];
		
elseif p == 1 && q == 1
cv = ...
[        11.69         9.88         8.63         7.52         6.27        11.99        11.98        10.29         8.96         7.83         6.63        12.27;
        13.24        10.96         9.62         8.29         6.87        13.43        13.74        11.64         9.92         8.66         7.28        14.06;
        14.78         12.1        10.54         8.99         7.56        14.87        15.86        12.85        10.87          9.3         7.87        15.91;
        17.28         13.4        11.53         9.75         8.11        17.39        17.99        14.27        11.87         10.2         8.44        17.99];
				
elseif p == 2 && q == 1
cv = ...
[        12.88        11.06         9.55         8.53         7.52        13.26        13.24        11.17         9.79         8.85         7.69        13.51;
         15.1        12.13        10.53         9.42         8.16        15.25        15.16        12.19        10.85         9.61         8.29         15.2;
        17.51        13.04         11.3         9.98         8.71         17.6        16.89        13.33        11.59        10.48         8.87        16.89;
         19.1        14.68        12.35        11.07         9.51         19.1        18.95        14.43        12.79        11.23          9.9        18.95];
		
		
elseif p == 1 && q == 2
cv = ...
[        13.85        12.05        10.48         9.35         7.99        14.23        13.42        11.33        10.06            9         7.73        13.64;
        15.91        13.45         11.5        10.23         8.64        16.07        15.42        12.76        11.03         9.86         8.44        15.47;
        17.68         14.6        12.44        11.06          9.3        18.06         17.5        13.95        12.05        10.58         8.97         17.5;
        19.89        16.02         13.8        11.88        10.14        20.03        19.61        15.23        13.05        11.38         9.59        19.61];
		
elseif p == 2 && q == 2
cv = ...
[        14.82        13.09        11.64         10.4         9.04        15.24        14.91         12.5        11.14        10.06         8.83        15.28;
        17.02        14.49        12.51        11.19         9.73        17.33        17.17        14.02        12.23        10.91         9.59        17.22;
        19.59        15.57        13.39        11.85        10.29        19.59        19.48        15.41        13.18        11.57        10.23        19.48;
        21.66        17.07        14.35        12.81        10.85        21.66        21.46         16.5        14.18         12.6        10.82        21.46];	
end

if eps_trim ~= 0.15
disp('Warning: cv with this trimming cannot be found in this program. The default is 0.15 trimming. The corresponding result might be wrong.');
end

if M ~= 5
disp('Warning: cv with this Maximum number of breaks cannot be found in this program. The default for maximum numberis 5. The corresponding result might be wrong.');
end

if siglev == 0.1 indsig = 1;
elseif siglev == 0.05 indsig = 2;
elseif siglev == 0.025 indsig = 3;
elseif siglev == 0.01 indsig = 4;
else disp('Warning: cv with this siglev cannot be found in this program. The corresponding result might be wrong.'); indsig = 2;
end

UD_cv = cv(indsig,opt_tr*6+M+1);
cv_k = cv(indsig,opt_tr*6+1:opt_tr*6+5);
end