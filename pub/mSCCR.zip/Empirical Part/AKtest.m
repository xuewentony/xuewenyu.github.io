% This function set conducts Arai-Kurozumi (2007, Econometric Reviews) test
% It contains several functions that is used in the main function AKtest.m

function [stats, cv] = AKtest(y,x,z,m,brdate,l_T,siglev)

T = length(y); 
if l_T == 0
    if ~isempty(x) Xbar=pzbar(x,m,brdate); else Xbar=[]; end
	Zbar=pzbar(z,m,brdate);
    XZbar = [Xbar, Zbar]; zlag = []; regs=[XZbar, zlag];
    stats = AKstats(y,regs);
else
    zlag = leadslag(z,l_T); [T, lagdim] = size(zlag);
    if ~isempty(x) Xbar=pzbar(x,m,brdate); else Xbar=[]; end
	Zbar=pzbar(z,m,brdate); XZbar = [Xbar, Zbar]; 
	XZbar2 = XZbar(l_T+2:end-l_T,:); regs=[XZbar2, zlag];
    y = y(l_T+2:end-l_T);
    stats = AKstats(y,regs);
end
[~, q]=size(z); cv = AKcv(q,m,brdate,T,siglev);
end

%%% --- Below are some functions built in the main function AKtest.m ---
% This function constructs AK test statistic 
function [testre, beta, res, nume, omega] = AKstats(y,x);
[T, k] = size(x); invxx = inv(x'*x); beta = invxx*x'*y;
res = y-x*beta; sqcsres = cumsum(res).^2; nume=sum(sqcsres)/T^2;
rho=(res(1:T-1)'*res(1:T-1))\(res(1:T-1)'*res(2:T));
a1=1.1447*((4*rho^2*T)/((1+rho)^2*(1-rho)^2))^(1/3);
a2=1.1447*((4*0.9^2*T)/((1+0.9)^2*(1-0.9)^2))^(1/3);
bw=min([a1,a2]); lam=0; sig = res'*res;  
for s=1:floor(bw)  lam=lam+(1-(s/(floor(bw)+1)))*res(s+1:T)'*res(1:T-s);  end
omega=(1/T)*(sig+2*lam); testre=nume/omega;
end

% This function gets (simulates) the critical values of AK test's asymptotic distribution
function cv = AKcv(q,brnum,brdate,T,siglev);
lam=brdate/T; TT=2000; mrep=10000; V=zeros(mrep,1);
for m=1:mrep
w1 = cumsum(randn(TT,1))/sqrt(TT); w2 = cumsum(randn(TT,q))/sqrt(TT);
w=[ones(TT,1), w2]; Tt=floor(lam*TT); G=zeros(TT,1); brvec=[0; Tt; TT];
for i=1:brnum+1
t1=brvec(i)+1; t2=brvec(i+1); wi=w(t1:t2,:); w1i=w1(t1:t2); g1i=(wi'*wi)\(wi'*[0; diff(w1i)]);
if i~=1 Glast=G(t1-1); else Glast=0; end
G(t1:t2)=Glast+cumsum(wi*g1i);
end
Q=w1-G; V(m)=mean(Q.^2);
end
sV=sort(V);
cv=sV(ceil((1-siglev)*mrep));
end