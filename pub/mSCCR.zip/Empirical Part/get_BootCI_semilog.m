% This function set computes regime-wise estimates and their bootstrap confidence intervals (C.I.) of the semi-log form
% It contains several functions that is used in the main function get_BootCI_semilog.m

function [Mat_est, Mat_wc, res] = get_BootCI_semilog(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T,option,YdP);

T = length(y); brep=1000;
[beta, res,~,~,hacsd,~,~,y,X] = get_Regoutput(y,xfix,xbr,z,x,nb,brdate,opt_tr,opt_sercorr,opt_endo,l_T);
Matboot_est=zeros((nb+1),3, brep); Matboot_wc=zeros((nb+1),3, brep);
if option==0   %%without restriction
    estmat = [beta(2:2:2*(nb+1)), beta(1:2:2*(nb+1)-1), [beta(5); beta(5)]];
	semat= [hacsd(2:2:2*(nb+1)), hacsd(1:2:2*(nb+1)-1), [hacsd(5); hacsd(5)]];
    wc = get_cost_noRes(T,beta,brdate,nb,YdP);
    for j=1:brep
        yb=X*beta+randn(length(res),1).*res;
        [betab] = olsbeta(yb,X);
		Matboot_est(:,:,j) = [betab(2:2:2*(nb+1)), betab(1:2:2*(nb+1)-1), [betab(5); betab(5)]];
        Matboot_wc(:,:,j) = get_cost_noRes(T,betab,brdate,nb,YdP);
    end
   
elseif option==1 %%with restriction
    estmat = [beta([2:2:2*(nb+1)]), NaN(nb+1,1), beta([1:2:2*(nb+1)-1])];
	semat= [hacsd([2:2:2*(nb+1)]), NaN(nb+1,1), hacsd([1:2:2*(nb+1)-1])];
	wc = get_cost_Res(T,beta,brdate,nb);
    for j=1:brep
        yb=X*beta+randn(length(res),1).*res;
        [betab] = olsbeta(yb,X);
		Matboot_est(:,:,j) = [betab([2:2:2*(nb+1)]), NaN(nb+1,1), betab([1:2:2*(nb+1)-1])];
        Matboot_wc(:,:,j) = get_cost_Res(T,betab,brdate,nb);
    end
end

s1=sort(Matboot_wc,3); Matse_wc_L=squeeze(s1(:,:,ceil(brep*0.025))); Matse_wc_U=squeeze(s1(:,:,ceil(brep*0.975)));
s2=sort(squeeze(mean(Matboot_wc,1))'); meanse_wc_L=s2(ceil(brep*0.025),:); meanse_wc_U=s2(ceil(brep*0.975),:);
Mat_wc=[[wc; mean(wc)], [Matse_wc_L; meanse_wc_L], [Matse_wc_U; meanse_wc_U]];

s1=sort(Matboot_est,3); Matse_est_L=squeeze(s1(:,:,ceil(brep*0.025))); Matse_est_U=squeeze(s1(:,:,ceil(brep*0.975)));
Matse_est_L=estmat-1.96*semat; Matse_est_U=estmat+1.96*semat;
s2=sort(squeeze(mean(Matboot_est,1))'); meanse_est_L=s2(ceil(brep*0.025),:); meanse_est_U=s2(ceil(brep*0.975),:);
Mat_est=[[estmat; mean(estmat)], [Matse_est_L; meanse_est_L], [Matse_est_U; meanse_est_U]];
end

%%% --- Below are some functions built in the main function get_BootCI_semilog.m ---
% This function computes wellfare cost of inflation of the unrestricted model 
function WC_noRes=get_cost_noRes(T,beta,brdate,nb,YdP)
datevec=[0, brdate, T]; aa=beta(2:2:2*(nb+1)); cc=beta(1:2:2*(nb+1)-1); bb=[beta(5), beta(5)]; WC_noRes=zeros(3,(nb+1)); 
for i=1:(nb+1)
dati=[datevec(i)+1:datevec(i+1)]; a1=aa(i); b1=bb(i); c1=cc(i);	rr=[0.03 0.08 0.13]; 
for j=1:3
r1=rr(j); WC_noRes(j,i)=exp(a1)/(-b1)*mean(YdP(dati))^(c1-1)*(1-(1-b1*r1).*exp(b1*r1))*100;
end 
end
WC_noRes = [WC_noRes'];

end

% This function computes wellfare cost of inflation of the restricted model
function WC_Res=get_cost_Res(T,beta,brdate,nb)
eta=beta([1:2:2*(nb+1)-1]); a=beta([2:2:2*(nb+1)]); w=zeros(3,(nb+1)); rr=[0.03 0.08 0.13];
for i=1:(nb+1)
    a1=a(i); eta1=eta(i); w(:,i)=exp(a1)/(-eta1)*(1-(1-eta1*rr).*exp(eta1*rr))*100;
end
WC_Res = [w'];
end

% This function computes OLS estimates
function b=olsbeta(y,X)
b=(X'*X)\(X'*y);
end


