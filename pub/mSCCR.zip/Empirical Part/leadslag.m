% This function constructs the leads lags (length of l_T) matrix of z.
function [zlag] = leadslag(z,l_T);

[T, k] = size(z); diffz = diff(z); zlag = diffz(l_T+1:end-l_T,:);
for i = 1:l_T
    zlag = [zlag, diffz(l_T+1+i:end-l_T+i,:)];   %% leads
    zlag = [diffz(l_T+1-i:end-l_T-i,:), zlag];   %% lags
end
end