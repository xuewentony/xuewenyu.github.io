% This function is from m-break-matlab.zip (http://blogs.bu.edu/perron/codes/), 
% developed by Yohei Yamamoto.
%
% This function calculates ols estimates.
function [b, res]=olsqr(y,x)

b=inv(x'*x)*x'*y; res=y-x*b;
end