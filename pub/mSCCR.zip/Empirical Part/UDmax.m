% This function conducts the UDmax test of Kejriwal and Perron (JBES, 2010).
% Input:
%   y: the regressand
%   z: the full set of regressors (excluding the leads and lags terms)
%   M: the maximum number of breaks allowed, default is 5
%   pq: value of p+q
%   bigt: effective sample size of the regression
%   datevec: estimated break dates vector (from 1 to M) from dating.m
%   lls: the leads and lags terms used in endogenity correction
%   lagdim: dimension of the leads and lags terms used in endogenity correction
%   opt_sercorr: =0, no serial correlation correction; =1 with serial correlation correction (default)
%
% Output:
%   UD_F: UDmax test statistic result, which is max(supF_i)
%   supF_i: SupF test statistic results for each i: from 1 to M.

function [UD_F, supF_i] = UDmax(y,z,M,p,pq,bigt,datevec,lls,lagdim,opt_sercorr)

supF_i = zeros(M,1); T=length(y);
for i = 1:M
    rsub=zeros(i,i+1); j=1;
    while j <= i
        rsub(j,j)=-1; rsub(j,j+1)=1;
        j=j+1;
    end
    rmat=kron(rsub,eye(pq));
    zbar=pzbar(z,i,datevec(1:i,i));
    if lagdim==0
        [delta, uu]=olsqr(y,zbar);
    else
        [dbdel, uu]=olsqr(y,[zbar lls]); delta=dbdel(1:(i+1)*pq,1);
    end
    
    if p~=0
        prewhit = 0; hetdat = 1; hetvar = 1; robust = 1; if opt_sercorr == 0 robust = 0;  end
        vdel=pvdel(y,z,i,pq,bigt,datevec(1:i,i),prewhit,robust,lls,lagdim,0,hetdat,hetvar);   %%% Need to modify this part
        fstar=delta'*rmat'*inv(rmat*vdel*rmat')*rmat*delta;
        supF_i(i)=(bigt-(i+1)*pq-lagdim)*fstar/(bigt*i);
    elseif p==0
        if lagdim==0 MG=eye(T); else MG=eye(T)-lls*inv(lls'*lls)*lls'; end
		Wbar=zbar; vdel=inv(Wbar'*MG*Wbar);
        fstar=delta'*rmat'*inv(rmat*vdel*rmat')*rmat*delta;		
        if lagdim==0
            [~, ur]=olsqr(y,z);
        else
            [~, ur]=olsqr(y,[z lls]);
        end
        lrv=LRV(uu,uu);
        supF_i(i)=(fstar/i)/lrv;
    end
end
UD_F = max(supF_i);
end

function [omega] = LRV(ur,uu)
T = length(ur);
eb=uu(1:T-1); ef=uu(2:T); rho=(eb'*ef)/(eb'*eb);
a2=4*rho^2/(1-rho)^4; eband=1.3221*(a2*T)^.2;

jb=((1:(T-1))/eband)'; jband=jb*1.2*pi;
kern = ((sin(jband)./jband - cos(jband))./(jband.^2)).*3;

sig=ur'*ur; lam=0; j=1;
while j<=T-1
    lam=lam+(ur(1:T-j)'*ur(1+j:T))*kern(j);
    j=j+1;
end
omega=(sig+2*lam)/T;  
end