This is a set of codes conducting the tests proposed in (1). Kejriwal, Perron and Yu (2021, JTSA), 
"A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models", 
and (2). Kejriwal and Perron (2010, JBES) "Testing for 
multiple structural changes in cointegrated regression models".

For users, run "mSCCR.m" ('m'ultiple 'S'tructural 'C'hanges in 'C'ointegrated 'R'egressions). 
Each file contains the details/description of how to use it.

Besides, this zip folder also contains two sub-folders that replicates the simulation results 
and the empirical work in Kejriwal, Perron and Yu (2021, JTSA), 
"A Two Step Procedure for Testing Partial Parameter Stability in Cointegrated Regression Models".

Specifically, they are:

<1>. Monte Carlo Simulations:
main files are: main_Table1.m, main_Table2.m, main_TableB1Figure1.m

<2>. Empirical Part:
main files are: main_Table3and4.m, main_Table5.m
and they share mostly the same functions as in the main zip folder, together with some additional
functions that are used to conduct the subsequent empirical analysis after break(s) determination, 
for instance, report regime-wise estimates and confidence intervals. So you might find it useful at some point.



NOTE: (1). This set of codes uses a lot of functions provided in Pierre Perron's website for projects 
Bai and Perron (1998, ECTA), "Estimating and Testing Linear Models with Multiple Structural 
Changes", Bai and Perron (2003, JAE) "Computation and Analysis 
of Multiple Structural Change Models". See m-break-matlab.zip (http://blogs.bu.edu/perron/codes/), 
which is a Matlab version developed by Yohei Yamamoto. 
(2). This code comes without technical support of any kind. It is expected to
reproduce the results reported in the paper. Under no circumstances will
the author be held responsible for any use (or misuse) of this code.

June, 2021, Xuewen Yu, http://xuewenyu.weebly.com
Contact: yu656@purdue.edu; xuewentonyyu@gmail.com



