% This script serves two purposes: 
% (I). Determine the number of breaks and the associated break dates in  
%      cointegrated regressions, following Kejriwal and Perron (2010, JBES).
% (II). Conduct the two-step procedure testing for breaks of parameter(s)
%       of interest, following Kejriwal, Perron and Yu (2021, JTSA).
%
% Input:
%   y: the regressand
%   z: I(1) regressors
%   xraw: I(0) regressors (if any)
%   testvec: the order number (or vector of numbers) of the column(s) of the full design matrix Xfull = [intercept, xraw, z].
%
% Some settings can be changed by users:
%   M: maximum allowed breaks, set 5 as default
%   eps_trim: trimming value, 0.15 is the default level and the only option (other options' critical values can be found in KP, 2010)
%   siglev: significance level (default = 0.05)
%   opt_tr: =0, nontredning case (default); =1 trending case. For details, see Kejriwal and Perron (2010).
%   opt_sercorr: =0, no serial correlation correction; =1 with serial correlation correction (default)
%   opt_endo: =0, no endogenity correction; =1 with endogenity correction (default)
%   l_T: the leads/lag length, set by the users
%
% Output:
%   ---Purpose (I)---
%   nb: number of breaks detected from the sequential procedure 
%   brdate: corresponding break dates, if no breaks detected, return null.
%   ---Purpose (II)---
%   testre: test result, =0, testing vector is not time varying; =1, testing vector is time varying
%   F_nb: the test statistic result
%   chi_nb: the corresponding critical values

%%% The following is an example. To run it on a real dataset, replace the simulated input with the real data input.
clear all; clc;
rng('default'); rng(100);
breaksize=1; % break size, no break if it is 0
z = cumsum(randn(250,1)); 
y = [z(1:75,:)+randn(75,1); (1+breaksize)*z(76:150)+randn(75,1); z(151:end,:)+randn(100,1);]; %two breaks

T = length(y); xraw = [];  
x = [ones(T,1), xraw]; % x is the matrix stores the intercept and the I(0) regressors (if any)
Xfull = [x, z]; 

M = 5; eps_trim = 0.15; siglev = 0.05;
opt_tr = 0; opt_sercorr = 1;
opt_endo = 1; l_T = 4;

%%%---------Purpose (I)------------
[nb, brdate, s1, scv] = seq_nbr(y,z,x,M,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);

%%%---------Purpose (II)------------
% testvec (vector of parameters under testing) is the order number (or vector of numbers) of the column(s) of the full design matrix Xfull. 
% Xfull is specified column-wisely (from the left to the right) by: intercept (by default), I(0) regressors (if any), I(1) regressors.
if nb ~= 0
    testvec = [1]; % test for intercept
    [testre, F_nb, chi_nb] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end
if nb ~= 0
    testvec = [2]; % test for I(1) regressor
    [testre, F_nb, chi_nb] = twostep(y,z,x,Xfull,testvec,nb,brdate,eps_trim,siglev,opt_tr,opt_sercorr,opt_endo,l_T);
end