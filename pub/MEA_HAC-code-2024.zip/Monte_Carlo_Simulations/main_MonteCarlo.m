%  This program generates the simulation results (Table 1-4 and C.1-C.4).
%  Note: The number of replications can be changed to a smaller number, say 
%  mrep = 1000, to get a quicker output. 
clear all; clc;
rng('default'); rng(1000, 'twister') 
mrep=10000; brep=400;
para=[1 .5 1 1; 1 .5 1/3 1; 2 .3 3 0.7; ...
    3 0 0 0; 5 .01 .9 .09; 7 5 0 0; 7 5 0 -0.5]; 
armagam=[1 0; 1 .5; 2 .5];

%%==================== Experiment I: alpha=0.5, without mean; ==================
sig=.05; c=.5; alpha=.5; mean_option = 0; 
resra = [];  reslen = []; totaltime=tic;
for i=1:length(armagam(:,1))
    armatype=armagam(i,1); gamma=armagam(i,2);
    ratioall = []; lenall = [];
    for jj = 1:length(para(:,1))
        voltype=para(jj,1); theta1=para(jj,2); sig1=para(jj,3); theta2=para(jj,4);
        oab=para(jj,2:end);  reall=[]; tic;
        for T=[50 100 200]
            rho=1+c/T^(alpha); if mean_option == 0 mu=0; elseif mean_option == 1 mu=T^(-alpha/4); end
            ratiotemp=zeros(mrep,6); lentemp=zeros(mrep,6); ratiotempPM=zeros(mrep,1); lentempPM=zeros(mrep,1);		
			rule=floor(3*(T/100)^(1/5)); [K1,K2,K3,K4] = genKhalf(T,3,5,10,rule);

            parfor m=1:mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                [covre, lenre] = variousBoothacCI(y,rho,sig,brep,K1,K2,K3,K4);
                ratiotemp(m,:)=covre; lentemp(m,:)=lenre;
            end
            
			m=1;
            while m<=mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                T=length(y); y2=y(2:end); y1=[y(1:end-1)]; b=(y1'*y1)\(y1'*y2);  b1=b(1);
                if sig==.1 PMcv=6.315; elseif sig==.05 PMcv=12.7; end
                if b1>=1
                    CI_PM=[b1-(b1^2-1)/b1^T*PMcv, b1+(b1^2-1)/b1^T*PMcv]; covPM=(rho<=CI_PM(2))*(rho>=CI_PM(1));
                    CIdiff=(CI_PM(2)-CI_PM(1))*10e4; if CIdiff>0 lenPM=CIdiff; else lenPM=NaN; end 
                    ratiotempPM(m)=covPM; lentempPM(m)=lenPM; m=m+1;
                end
            end
			
            ratiotemp=[ratiotemp(:,1), ratiotempPM, ratiotemp(:,2:end)];
            lentemp=[lentemp(:,1), lentempPM, lentemp(:,2:end)];  
			
			ratioall=[ratioall; mean(ratiotemp)]; ratio_row=mean(ratiotemp)
            lentemp2=[];
            for kk=1:7
                lentemp3=lentemp(:,kk);  lentemp2=[lentemp2, mean(lentemp3(find(~isnan(lentemp3))))];
            end
            lenall=[lenall; lentemp2]; %length has been multiplied by 10e4 to avoid rounding errors
            %len_row=lentemp2;  
        end
        toc;
    end
    resra = [resra; ratioall'];
    reslen = [reslen; lenall'];
end
toc(totaltime); save case_a5meanzero.mat;
resra_csv = print_Texresults(resra*100,1); writetable(resra_csv, strcat('Table_cov_a5_meanzero.xls'),'WriteVariableNames',0); 
reslen_csv = print_Texresults(reslen,2); writetable(reslen_csv, strcat('Table_len_a5_meanzero.xls'),'WriteVariableNames',0); 

%%==================== Experiment II: alpha=0.5, with mean; ==================
sig=.05; c=.5; alpha=.5; mean_option = 1; 
resra = [];  reslen = []; totaltime=tic;
for i=1:length(armagam(:,1))
    armatype=armagam(i,1); gamma=armagam(i,2);
    ratioall = []; lenall = [];
    for jj = 1:length(para(:,1))
        voltype=para(jj,1); theta1=para(jj,2); sig1=para(jj,3); theta2=para(jj,4);
        oab=para(jj,2:end);  reall=[]; tic;
        for T=[50 100 200]
            rho=1+c/T^(alpha); if mean_option == 0 mu=0; elseif mean_option == 1 mu=T^(-alpha/4); end
            ratiotemp=zeros(mrep,6); lentemp=zeros(mrep,6); ratiotempPM=zeros(mrep,1); lentempPM=zeros(mrep,1);		
			rule=floor(3*(T/100)^(1/5)); [K1,K2,K3,K4] = genKhalf(T,3,5,10,rule);

            parfor m=1:mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                [covre, lenre] = variousBoothacCI(y,rho,sig,brep,K1,K2,K3,K4);
                ratiotemp(m,:)=covre; lentemp(m,:)=lenre;
            end
            
			m=1;
            while m<=mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                T=length(y); y2=y(2:end); y1=[y(1:end-1)]; b=(y1'*y1)\(y1'*y2);  b1=b(1);
                if sig==.1 PMcv=6.315; elseif sig==.05 PMcv=12.7; end
                if b1>=1
                    CI_PM=[b1-(b1^2-1)/b1^T*PMcv, b1+(b1^2-1)/b1^T*PMcv]; covPM=(rho<=CI_PM(2))*(rho>=CI_PM(1));
                    CIdiff=(CI_PM(2)-CI_PM(1))*10e4; if CIdiff>0 lenPM=CIdiff; else lenPM=NaN; end 
                    ratiotempPM(m)=covPM; lentempPM(m)=lenPM; m=m+1;
                end
            end
			
            ratiotemp=[ratiotemp(:,1), ratiotempPM, ratiotemp(:,2:end)];
            lentemp=[lentemp(:,1), lentempPM, lentemp(:,2:end)];
			
			ratioall=[ratioall; mean(ratiotemp)]; ratio_row=mean(ratiotemp)
            lentemp2=[];
            for kk=1:7
                lentemp3=lentemp(:,kk);  lentemp2=[lentemp2, mean(lentemp3(find(~isnan(lentemp3))))];
            end
            lenall=[lenall; lentemp2]; %length has been multiplied by 10e4 to avoid rounding errors
            %len_row=lentemp2;  
        end
        toc;
    end
    resra = [resra; ratioall'];
    reslen = [reslen; lenall'];
end
toc(totaltime); save case_a5meannonzero.mat;
resra_csv = print_Texresults(resra*100,1); writetable(resra_csv, strcat('Table_cov_a5_meannonzero.xls'),'WriteVariableNames',0); 
reslen_csv = print_Texresults(reslen,2); writetable(reslen_csv, strcat('Table_len_a5_meannonzero.xls'),'WriteVariableNames',0); 

%%==================== Experiment III: alpha=0.8, without mean; ==================
sig=.05; c=.5; alpha=.8; mean_option = 0; 
resra = [];  reslen = []; totaltime=tic;
for i=1:length(armagam(:,1))
    armatype=armagam(i,1); gamma=armagam(i,2);
    ratioall = []; lenall = [];
    for jj = 1:length(para(:,1))
        voltype=para(jj,1); theta1=para(jj,2); sig1=para(jj,3); theta2=para(jj,4);
        oab=para(jj,2:end);  reall=[]; tic;
        for T=[50 100 200]
            rho=1+c/T^(alpha); if mean_option == 0 mu=0; elseif mean_option == 1 mu=T^(-alpha/4); end
            ratiotemp=zeros(mrep,6); lentemp=zeros(mrep,6); ratiotempPM=zeros(mrep,1); lentempPM=zeros(mrep,1);		
			rule=floor(3*(T/100)^(1/5)); [K1,K2,K3,K4] = genKhalf(T,3,5,10,rule);

            parfor m=1:mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                [covre, lenre] = variousBoothacCI(y,rho,sig,brep,K1,K2,K3,K4);
                ratiotemp(m,:)=covre; lentemp(m,:)=lenre;
            end
            
			m=1;
            while m<=mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                T=length(y); y2=y(2:end); y1=[y(1:end-1)]; b=(y1'*y1)\(y1'*y2);  b1=b(1);
                if sig==.1 PMcv=6.315; elseif sig==.05 PMcv=12.7; end
                if b1>=1
                    CI_PM=[b1-(b1^2-1)/b1^T*PMcv, b1+(b1^2-1)/b1^T*PMcv]; covPM=(rho<=CI_PM(2))*(rho>=CI_PM(1));
                    CIdiff=(CI_PM(2)-CI_PM(1))*10e4; if CIdiff>0 lenPM=CIdiff; else lenPM=NaN; end 
                    ratiotempPM(m)=covPM; lentempPM(m)=lenPM; m=m+1;
                end
            end
			
            ratiotemp=[ratiotemp(:,1), ratiotempPM, ratiotemp(:,2:end)];
            lentemp=[lentemp(:,1), lentempPM, lentemp(:,2:end)];
			
			ratioall=[ratioall; mean(ratiotemp)]; ratio_row=mean(ratiotemp)
            lentemp2=[];
            for kk=1:7
                lentemp3=lentemp(:,kk);  lentemp2=[lentemp2, mean(lentemp3(find(~isnan(lentemp3))))];
            end
            lenall=[lenall; lentemp2]; %length has been multiplied by 10e4 to avoid rounding errors
            %len_row=lentemp2;  
        end
        toc;
    end
    resra = [resra; ratioall'];
    reslen = [reslen; lenall'];
end
toc(totaltime); save case_a8meanzero.mat;
resra_csv = print_Texresults(resra*100,1); writetable(resra_csv, strcat('Table_cov_a8_meanzero.xls'),'WriteVariableNames',0); 
reslen_csv = print_Texresults(reslen,2); writetable(reslen_csv, strcat('Table_len_a8_meanzero.xls'),'WriteVariableNames',0); 

%%==================== Experiment IV: alpha=0.8, with mean; ==================
sig=.05; c=.5; alpha=.5; mean_option = 1; 
resra = [];  reslen = []; totaltime=tic;
for i=1:length(armagam(:,1))
    armatype=armagam(i,1); gamma=armagam(i,2);
    ratioall = []; lenall = [];
    for jj = 1:length(para(:,1))
        voltype=para(jj,1); theta1=para(jj,2); sig1=para(jj,3); theta2=para(jj,4);
        oab=para(jj,2:end);  reall=[]; tic;
        for T=[50 100 200]
            rho=1+c/T^(alpha); if mean_option == 0 mu=0; elseif mean_option == 1 mu=T^(-alpha/4); end
            ratiotemp=zeros(mrep,6); lentemp=zeros(mrep,6); ratiotempPM=zeros(mrep,1); lentempPM=zeros(mrep,1);		
			rule=floor(3*(T/100)^(1/5)); [K1,K2,K3,K4] = genKhalf(T,3,5,10,rule);

            parfor m=1:mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                [covre, lenre] = variousBoothacCI(y,rho,sig,brep,K1,K2,K3,K4);
                ratiotemp(m,:)=covre; lentemp(m,:)=lenre;
            end
            
			m=1;
            while m<=mrep
                [y, sigtrue]= DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab);
                T=length(y); y2=y(2:end); y1=[y(1:end-1)]; b=(y1'*y1)\(y1'*y2);  b1=b(1);
                if sig==.1 PMcv=6.315; elseif sig==.05 PMcv=12.7; end
                if b1>=1
                    CI_PM=[b1-(b1^2-1)/b1^T*PMcv, b1+(b1^2-1)/b1^T*PMcv]; covPM=(rho<=CI_PM(2))*(rho>=CI_PM(1));
                    CIdiff=(CI_PM(2)-CI_PM(1))*10e4; if CIdiff>0 lenPM=CIdiff; else lenPM=NaN; end 
                    ratiotempPM(m)=covPM; lentempPM(m)=lenPM; m=m+1;
                end
            end
			
            ratiotemp=[ratiotemp(:,1), ratiotempPM, ratiotemp(:,2:end)];
            lentemp=[lentemp(:,1), lentempPM, lentemp(:,2:end)];
			
			ratioall=[ratioall; mean(ratiotemp)]; ratio_row=mean(ratiotemp)
            lentemp2=[];
            for kk=1:7
                lentemp3=lentemp(:,kk);  lentemp2=[lentemp2, mean(lentemp3(find(~isnan(lentemp3))))];
            end
            lenall=[lenall; lentemp2]; %length has been multiplied by 10e4 to avoid rounding errors
            %len_row=lentemp2;  
        end
        toc;
    end
    resra = [resra; ratioall'];
    reslen = [reslen; lenall'];
end
toc(totaltime); save case_a8meannonzero.mat;
resra_csv = print_Texresults(resra*100,1); writetable(resra_csv, strcat('Table_cov_a8_meannonzero.xls'),'WriteVariableNames',0); 
reslen_csv = print_Texresults(reslen,2); writetable(reslen_csv, strcat('Table_len_a8_meannonzero.xls'),'WriteVariableNames',0); 