% This function constructs CI estimates by GSW
function [CI] = GSW(y,rho,sig)

T= length(y); y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1)); b1=b(1);
sde=sqrt((err'*err/T)/(dy1'*dy1));
[lambdasq, K] = GSWLRV(err); GSWsde=sqrt(lambdasq/(dy1'*dy1));
CI=[b1-GSWsde*tinv(1-sig/2,K), b1-GSWsde*tinv(sig/2,K)]; %CI=[b1-sde*norminv(1-sig/2), b1-sde*norminv(sig/2)]; %no serial correlation

end

function [lambdasq, K] = GSWLRV(err,K);

T=length(err);
if nargin == 1
    K=find_Kopt(err);
end

lambdasq=0;
for i=1:2:K-1
    lambdasq=lambdasq+(1/sqrt(T)*sqrt(2)*cos(pi*(i+1)*[1:T]/T)*err)^2;
end
for i=2:2:K
    lambdasq=lambdasq+(1/sqrt(T)*sqrt(2)*sin(pi*i*[1:T]/T)*err)^2;
end
lambdasq=lambdasq/K;
end

function re=find_Kopt(err) %%% Phillips 2005

T=length(err);
depvar=err(2:end); regs=[err(1:end-1), ones(T-1,1)]; %AR with intercept (Guo et. al. 2019), instead of pure AR(1), regs=[err(1:end-1)]; 
beta=(regs'*regs)\(regs'*depvar); e=depvar-regs*beta; sigsq=e'*e/(T-1-2); beta=beta(1);
omesq=sigsq/((1-beta)^2); D=-(pi^2/3)*(sigsq*beta)/((1-beta)^4);
K=(((2*(omesq^2))/(4*(D^2)))^(1/5))*(T^(4/5));
hatK=ceil(K);
if hatK<=5 Kopt=5; end
if hatK>5 && hatK<=T Kopt=K; end
if hatK>T Kopt=T; end
re=floor(Kopt/2)*2;

end