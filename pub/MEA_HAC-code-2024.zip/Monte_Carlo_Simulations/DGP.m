% This function specifies the data generating process
function [y sig] = DGP(voltype,T,rho,mu,theta1,sig1,theta2,armatype,gamma,oab)

e=[randn(T,1)]; y=zeros(T,1);
switch voltype
    case 1
        t1s=ceil(theta1*T);
        sig=[ones(t1s,1); sig1*ones(T-t1s,1)];
    case 2
        t1s=ceil(theta1*T); t2s=ceil(theta2*T);
        sig=[ones(t1s,1); sig1*ones(t2s-t1s,1); ones(T-t2s,1)];
    case 3
        sig=1+5*[1:T]'/T; %sig=1+3*[1:T]'/T;
    case 4
        sig=(6-5*[1:T]'/T); %sig=4-3*[1:T]'/T;
    case 5  %%garch--GK04
        sig=ones(T,1); omega=oab(1); alpha=oab(3); beta=oab(2);
        h = zeros(T,1); h(1)=omega; nu = randn(T,1); 
        e = randn(T,1); e(1) = nu(1)*sqrt(h(1));
        for t=2:T
            h(t)=omega+alpha*e(t-1)^2+beta*h(t-1);
            e(t)=nu(t)*sqrt(h(t));
        end
        e=e./std(e);
    case 6 %%SV--GK04
        sig=ones(T,1);
        nu = randn(T,1); h = zeros(T,1);
        uu = randn(T,1)*.424; h(1)=.5*uu(1);
        for t=2:T h(t)=.936*h(t-1)+.5*uu(t); end
        e = nu.*exp(h);
	case 7 %%CT09
        sig=ones(T,1); w=theta1; c=sig1; bw=theta2;
		nu_uu=randn(T,2)*[1, bw; bw, 1];
        nu = nu_uu(:,1); uu = nu_uu(:,2); 
		h = zeros(T,1); %h(1)=uu(1); 
		for t=2:T h(t)=(1-c/T)*h(t-1)+uu(t); end
        e = nu.*exp(h*w/sqrt(T)*0.5);
end
v=e.*sig; u=v;
if armatype == 1
    for t=2:T u(t)=gamma*u(t-1)+sqrt(1-gamma^2)*v(t); end
elseif armatype == 2
    for t=2:T u(t)=sqrt(1-gamma^2)*v(t)+gamma*v(t-1); end
end

y(1)=mu+u(1);
for t=2:T y(t)=mu+rho*y(t-1)+u(t); end

end
