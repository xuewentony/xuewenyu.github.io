% This function calculates the long run variance (Andrews, 1993) using AR(1) prewhitening
function [omega] = LRVwh1(u,whiten)

T = length(u);

if whiten==1
    ub=u(1:T-1,:);
    uf=u(2:T,:);
    a=inv(ub'*ub)*(ub'*uf);
    e=uf-ub*a;
	T=T-1;
else
    e=u;
end

eb=e(1:T-1,:); ef=e(2:T,:); rho=(eb'*ef)/(eb'*eb);
a2=4*rho^2/(1-rho)^4; eband=1.3221*(a2*T)^.2;

jb=((1:(T-1))/eband)'; jband=jb*1.2*pi;
kern = ((sin(jband)./jband - cos(jband))./(jband.^2)).*3;

sig=e'*e; lam=0; j=1;
while j<=T-1
    lam=lam+(e(1:T-j,:)'*e(1+j:T,:))*kern(j);
    j=j+1;
end
omega=(sig+2*lam)/T;


% Recolor %
if whiten==1
    omega=omega/(1-a)^2;
end

omega=omega;

end

