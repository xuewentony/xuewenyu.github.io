% This function transforms the outputs in Table 1-4 and C.1-C.4 to
% LaTex version outputs with suitable exposion.
function re = print_Texresults(A,option)

if option == 1 % print results table for coverage rate
t2=[];
for i=1:21
    t1=[];
    for j=1:21
        e=A(i,j);
        if e<100
            e2=round(e,1);
            if e2==100
                t1=[t1, split(num2str(e2))];
            else
                t1=[t1, split(num2str(e2,'%.1f'))];
            end
        elseif e==100
            e2=100; t1=[t1, split(num2str(e2))];
        end
    end
    t2=[t2; t1];
end

elseif option == 2 % print results table for effective length ratio

Aini = A; A = [];
for i=1:3
Apart = Aini((i-1)*7+1:i*7,:); A = [A; Apart(2:end,:)./repmat(Apart(1,:),6,1)];
end

t2=[];
for i=1:18
    t1=[];
    for j=1:21
        e=A(i,j);
        if e<=10
            e2=round(e,2);
            if e2>=10
                e2=round(e,1); t1=[t1, split(num2str(e2,'%.1f'))];
            else
                t1=[t1, split(num2str(e2,'%.2f'))];
            end
        elseif e>=10
            e2=round(e,1); t1=[t1, split(num2str(e2,'%.1f'))];
        end
    end
    t2=[t2; t1];
end

end

t2 = cell2table(t2);
re = t2;

end