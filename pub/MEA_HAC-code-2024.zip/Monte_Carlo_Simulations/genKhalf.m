% This function generates serial correlated random samples specified in DWB
function  [K1,K2,K3,K4] = genKhalf(T,a,b,c,d);

A=[1:T-1]'; Kmat=A*ones(1,length(A))-ones(length(A),1)*A';
K1=calKhalf(Kmat,a); K2=calKhalf(Kmat,b);
K3=calKhalf(Kmat,c); K4=calKhalf(Kmat,d);

end

function Khalf = calKhalf(Kmat,a)
Kmat=abs(Kmat/a); Kmat(find(Kmat>=1))=1;  Kmat=1-abs(Kmat); Khalf=sqrtm(Kmat);
end

