% This function summarizes methods for constructing CIs for AR(1) parameter
function [cov, len, CI] = variousBoothacCI(y,rho,sig,brep,K1,K2,K3,K4)

T= length(y); y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1)); b1=b(1);
[omega] = LRVwh1(dy1.*err,1); hacsde=sqrt(T*omega/(dy1'*dy1)^(2)); %sde=sqrt((err'*err/T)/(dy1'*dy1));

CI=[b1-hacsde*norminv(1-sig/2), b1-hacsde*norminv(sig/2)]; %t-hac
CI=[CI; GSW(y,rho,sig)]; %GSW

cv = gen_bootcv(y,T,b,err,sig,brep,K1,K2,K3,K4); %DWB
CI=[CI; [b1-hacsde*cv(:,2), b1-hacsde*cv(:,1)]]; m=length(CI(:,1));
cov = (rho*ones(m,1) <= CI(:,2)).*(rho*ones(m,1) >= CI(:,1));
len = NaN(m,1); CIdiff=(CI(:,2)-CI(:,1))*10e4; covidx=find((cov==ones(m,1))); len(covidx)=CIdiff(covidx);

end

%%% --- Below are some functions built in the main function variousBoothacCI.m ---
function cv = gen_bootcv(y,T,beta,err,sig,brep,K1,K2,K3,K4);
% This function generates bootstrap critical values under DWB
stats=zeros(brep,4);
for b=1:brep
    
    w1=K1*randn(T-1,1); w2=K2*randn(T-1,1);
    w3=K3*randn(T-1,1); w4=K4*randn(T-1,1);
    
    eall=repmat(err,1,4).*[w1, w2, w3, w4];
    
    yball=zeros(T,4);  yball(1,:)=y(1)*ones(1,4);
    for t=2:T yball(t,:)=beta(1)*yball(t-1,:)+beta(2)+eall(t-1,:); end
    
    for j=1:4  stats(b,j) = HacCal(yball(:,j),beta(1));  end
end
sstats=sort(stats); cv=sstats(round([sig/2, 1-sig/2]*brep),:)';
end

function [re] = HacCal(y,beta)
% This function calculates t-hac statistic
T= length(y); y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1));
[omega] = LRVwh1(dy1.*err,1); hacsde=sqrt(T*omega/(dy1'*dy1)^(2));
re=(b(1)-beta)/hacsde;
end
