% This function conducts bootstrap bubble tests of HLZ (2018, ER)
function [res] = bootBZDF(y)

r0=.1; brep=499; T=length(y); %siglev=.05;
[U supbz supdf sighat0] = BZDF(y,T,r0,0);
resb = zeros(brep,3);
for b = 1:brep
    err = diff(y); yb=cumsum([0; err.*randn(T-1,1)]);
    [Ub supbzb supdfb] = BZDF(yb,T,r0,1,sighat0);
    resb(b,:)= [Ub supbzb supdfb];
end
res = 1-mean([U supbz supdf] > resb);
end

%%% --- Below are some functions built in the main function bootBZDF.m ---
function [U supbz supdf sighat] = BZDF(y,T,r0,option,sighat0)

yt = y-y(1); u=diff(yt);
if option==0 sighat = npvol(u); else sighat = sighat0; end
% option=0, original; =1, bootstrap
swindow0 = floor(r0*T);
bz=zeros(T,1);
for t=swindow0:1:T
    bz(t)= bz_stats(yt(1:t,1),sighat(1:t-1));
    %sighatt=npvol(u(1:t-1)); bz(t)= bz_stats(yt(1:t,1),sighatt);  %%not available, not that easy
end
supbz = max(bz(swindow0:T));

IC=0; adflag=0;
sadf=PWY(y,swindow0,IC,adflag);
supdf=sadf;
U = max([supbz, supdf]);

end

function sadf=PWY(y,swindow0,IC,adflag)
T=length(y);
adfs=NaN(T,1);
for r2=swindow0:1:T
    adfs(r2)= ADF(y(1:r2,1),IC,adflag);   % two tail 5% significant level
end
sadf=max(adfs(swindow0:T));
end

function re = bz_stats(y,u)
dy=diff(y);
re=sum(dy.*y(1:end-1)./u)/sqrt(sum(y(1:end-1).*y(1:end-1)./u));
end

function re = npvol(u)
T = length(u); x = [1:T]'; usq=u.^2; hpool = [1/(2*T):(1/6-1/(2*T))/9:1/6]';
hn = length(hpool); hh = hpool; check = zeros(hn,1);
q = usq; hi = 1;
while hi <= hn
    h = hh(hi);
    qh = epi(x,T*h,1)*usq;
    check(hi) = sum((q-qh).^2);
    hi = hi+1;
end
[~, hi] = min(check); h = hh(hi);
re = epi(x,T*h,0)*usq;
end


function w = epi(a,h,leave)
aa = a*ones(1,length(a))-ones(length(a),1)*a';
u = (aa'/h)';
w = 1/sqrt(2*pi)*exp(-u.^2/2);
if leave==1
    for i=1:length(w(:,1))
        w(i,i)=0;
    end
end
w=w./(sum(w')'*ones(1,length(w(1,:))));
end