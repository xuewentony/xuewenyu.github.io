% This function coducts the autoregressive estimation under AIC/BIC selection of lags.

function [rho, err, optlag] = AR_est(y,option,fixlag,IC,K)

% option=0 for fixed lag; fixlag is the lag specified
% option=1 for IC selection of lags; IC=1 AIC, IC=2 BIC; K is the maximum lag allowed
T = length(y);
if option == 1
    ICvalue = zeros(K,1);
    depvar = y(K+1:end);
    for lags = 1:K
        ylag = zeros(T-K,lags);
        for k= 1:lags
            ylag(:,k) = y(K+1-k:end-k);
        end
        regs = [ones(T-K,1), ylag];
        beta = inv(regs'*regs)*regs'*depvar; err=depvar-regs*beta; ssr = err'*err;
        if IC==1               %@ AIC @
            ICvalue(lags)=log(ssr/(T-K))+lags*2/(T-K);
        elseif IC==2           %@ BIC @
            ICvalue(lags)=log(ssr/(T-K))+lags*log(T-K)/(T-K);
        end
    end
    [~, minic_loc] = min(ICvalue); optlag = minic_loc;
elseif option == 0
    optlag = fixlag;
end

depvar = y(optlag+1:end); regs=[ones(T-optlag,1)];
ylag = zeros(T-optlag,optlag);
for k= 1:optlag
    ylag(:,k) = y(optlag+1-k:end-k);
end
regs = [regs, ylag];
beta = inv(regs'*regs)*regs'*depvar;
err=depvar-regs*beta; rho = sum(beta(2:end));
end
