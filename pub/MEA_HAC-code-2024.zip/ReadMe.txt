This folder consists of a set of MATLAB codes to replicate 
the simulation/empirical results in the paper
Yu and Kejriwal (2024), "Inference in Mildly Explosive Autoregressions under
Unconditional Heteroskedasticity", Econometric Theory, forthcoming.

The files are:

<1>. Part I (Empirical study, the current directory): 
 (1). Programs for Application 1 (stock data): 
 main_emp1_stock.m; Stock_Data.csv (raw data, from Guo et. al., 2019).
 (2). Programs for Application 2 (U.S. housing price index): 
 main_emp2_UShouseprice.m; CSUSHPISA.csv,SPCS20RSA.csv,SPCS10RSA.csv (raw data, from Fed St. Louis).
  
<2>. Part II (Monte_Carlo_Simulations folder): 
The main program for Tables 1-4 and C.1-C.4 is: main_MonteCarlo.m

For questions, please contact Xuewen Yu, xuewenyu@fudan.edu.cn or xuewentonyyu@gmail.com
