% This function transforms the outputs to
% LaTex version outputs that show stars.

function re = printLaTex_withstars_3f(estimates, starmat)

estimates = round(estimates,3);
[m, N] = size(estimates);
re = [];
for i = 1:m
    strtemp = [];
    for j = 1:N
        num = estimates(i,j);
        tempnum = num2str(num,'%.3f');
        star = starmat(i,j);
        if star == 1 word = '\oneS';
        elseif star == 2 word = '\twoS';
        elseif star == 3 word = '\threeS';
        else word = '';
        end
        re_str = strcat(tempnum,word,' ');
        strtemp = [strtemp, split(re_str)];
    end
    re = [re; strtemp];
end

end




