% This function summarizes methods for constructing CIs for AR(1) parameter
function [CI] = CI_est(y,sig,brep)

T= length(y); 
len_all=floor(4.5*(T/100)^(1/5)); [K1,K2,K3,K4] = genKhalf(T,3,5,10,len_all);

y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1)); b1=b(1);
[omega] = LRVwh1(dy1.*err,1); hacsde=sqrt(T*omega/(dy1'*dy1)^(2)); %sde=sqrt((err'*err/T)/(dy1'*dy1));

CI=[b1-hacsde*norminv(1-sig/2), b1-hacsde*norminv(sig/2)]; %t-hac
if sig==.1 PMcv=6.315; elseif sig==.05 PMcv=12.7; end
CI=[CI; [b1-(b1^2-1)/b1^T*PMcv, b1+(b1^2-1)/b1^T*PMcv]];  %PM
CI_GSW=GSW_CIest(y,sig); CI=[CI; CI_GSW(2,:)]; %GSW
cv = gen_bootcv(y,T,b,err,sig,brep,K1,K2,K3,K4); 
CI=[CI; [b1-hacsde*cv(:,2), b1-hacsde*cv(:,1)]]; m=length(CI(:,1)); %DWB-3,5,10,rule

end

%%% --- Below are some functions built in the main function CI_est.m ---
function cv = gen_bootcv(y,T,beta,err,sig,brep,K1,K2,K3,K4);
stats=zeros(brep,4);
for b=1:brep
    
    w1=K1*randn(T-1,1); w2=K2*randn(T-1,1);
    w3=K3*randn(T-1,1); w4=K4*randn(T-1,1);
    
    eall=repmat(err,1,4).*[w1, w2, w3, w4];
    
    yball=zeros(T,4);  yball(1,:)=y(1)*ones(1,4);
    for t=2:T yball(t,:)=beta(1)*yball(t-1,:)+beta(2)+eall(t-1,:); end
    
    for j=1:4  stats(b,j) = HacCal(yball(:,j),beta(1));  end
end
sstats=sort(stats); cv=sstats(round([sig/2, 1-sig/2]*brep),:)';
end

function [re] = HacCal(y,beta)
T= length(y); y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1));
[omega] = LRVwh1(dy1.*err,1); hacsde=sqrt(T*omega/(dy1'*dy1)^(2));
re=(b(1)-beta)/hacsde;
end


function  [K1,K2,K3,K4] = genKhalf(T,a,b,c,d);
A=[1:T-1]'; Kmat=A*ones(1,length(A))-ones(length(A),1)*A';
K1=calKhalf(Kmat,a); K2=calKhalf(Kmat,b);
K3=calKhalf(Kmat,c); K4=calKhalf(Kmat,d);
end

function Khalf = calKhalf(Kmat,a)
Kmat=abs(Kmat/a); Kmat(find(Kmat>=1))=1;  Kmat=1-abs(Kmat); Khalf=sqrtm(Kmat);
end

function [CI] = GSW_CIest(y,sig)

T= length(y); y2=y(2:end); y1=[y(1:end-1), ones(T-1,1)];
b=(y1'*y1)\(y1'*y2); err=y2-y1*b; dy1=y(1:end-1)-mean(y(1:end-1)); b1=b(1);
sde=sqrt((err'*err/T)/(dy1'*dy1));

[lambdasq, K] = GSWLRV(err); GSWsde=sqrt(lambdasq/(dy1'*dy1));

CI=[b1-sde*norminv(1-sig/2), b1-sde*norminv(sig/2)];
CI=[CI; [b1-GSWsde*tinv(1-sig/2,K), b1-GSWsde*tinv(sig/2,K)]];

end

function [lambdasq, K] = GSWLRV(err,K);

T=length(err);
if nargin == 1
    K=find_Kopt(err);
end

lambdasq=0;
for i=1:2:K-1
    lambdasq=lambdasq+(1/sqrt(T)*sqrt(2)*cos(pi*(i+1)*[1:T]/T)*err)^2;
end
for i=2:2:K
    lambdasq=lambdasq+(1/sqrt(T)*sqrt(2)*sin(pi*i*[1:T]/T)*err)^2;
end
lambdasq=lambdasq/K;
end

function re=find_Kopt(err) %%% Phillips 2005

T=length(err);
depvar=err(2:end); regs=[err(1:end-1), ones(T-1,1)]; %AR with intercept (Guo et. al. 2019), instead of pure AR(1), regs=[err(1:end-1)]; 
beta=(regs'*regs)\(regs'*depvar); e=depvar-regs*beta; sigsq=e'*e/(T-1-2); beta=beta(1);
omesq=sigsq/((1-beta)^2); D=-(pi^2/3)*(sigsq*beta)/((1-beta)^4);
K=(((2*(omesq^2))/(4*(D^2)))^(1/5))*(T^(4/5));
hatK=ceil(K);
if hatK<=5 Kopt=5; end
if hatK>5 && hatK<=T Kopt=K; end
if hatK>T Kopt=T; end
re=floor(Kopt/2)*2;

end

