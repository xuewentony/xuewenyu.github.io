%%% This program generates the empirical results for Application I.

clc; clear all;
% Data cleaning
data=readmatrix('Stock_Data.csv');
y = data(:,[2:3:29]); [T, N] = size(y);   %%%data: T=100; N=10;
indexnames={'DJI';'IBOVESPA';'CSI300';'HSI';'AS51';'FCHI';'GDAXI';'ITLMS';'CASE';'NGSEINDX'};
countrynames={'USA';'Brazil';'China';'Hong Kong';'Australia';'France';'Germany';'Italy';'Egypt';'Nigeria'};

% Model estimation
option = 1; fixlag = []; IC = 2; K =6;
beta_all=zeros(1,N); optlag = zeros(1,N); 
for i = 1:10
yi=y(:,i); [rhoi, erri, optlagi] = AR_est(yi,option,fixlag,IC,K);
eval([strcat('err',num2str(i)),'=erri;']); beta_all(:,i)=rhoi; optlag(i) = optlagi;
end

% Figure 1: raw series
figure;
for i = 1:10
    subplot(3,4,i)
    plot(1:T,y(:,i),'LineWidth',1);
    title(countrynames(i));
    xlabel('T'); if i ==1 ylabel('Index Value'); end;
end
set(gcf, 'Units', 'centimeters', 'Position', [2, 2, 24, 18]);
saveas(gcf,'Fig-Stock-rawseries','epsc');

% Figure 2: variance profile & nonparametric volatility estimates
idx1 = [1:5, 11:15]; idx2 = [6:10, 16:20]; cpool = [0.25; 0.4; 0.6; 0.75]; 
figure; 
for i = 1:10
    eval(['erri=',strcat('err',num2str(i)),';']);
    erri(find(isnan(erri))) = []; errisq = erri.^2;
    len = length(errisq); new = zeros(len,1);
    for ii = 1:length(new)
        new(ii) = (sum(errisq(1:ii)))/sum(errisq);
    end
    b = [0:1/(length(new)-1):1]';
    subplot(4,5,idx1(i)); plot(b,new,'k',b,b,'--r','LineWidth',1); 
    if i ==1 || i==6 ylabel('Variance Profile'); end
    title(countrynames(i)); %title(strcat('$',countrynames(i),'$'),'interpreter','latex');
    
    eval(['erri=',strcat('err',num2str(i)),';']);
    erri(find(isnan(erri))) = []; len = length(erri);
    sigmasq = npvol_esti(erri,cpool); sigmasq = sigmasq/mean(sigmasq);
    subplot(4,5,idx2(i)); plot(T-length(erri)+1:T,sigmasq,'--b','LineWidth',1); hold on; plot(T-length(erri)+1:T,ones(length(erri),1),':k','LineWidth',1); 
    if i ==1 || i==6 ylabel('Volatility Intensity'); end; xlabel('T');
%     title(countrynames(i)); 
end
set(gcf, 'Units', 'centimeters', 'Position', [2, 2, 24, 18]);
saveas(gcf,'Fig-Stock-VarianceProfile_VolEstimates','epsc');

% Table 5: nonstationary volatility tests
test_nsvol_lag4=zeros(4,N); test_nsvol_lagauto=zeros(4,N);
for i = 1:10
    eval(['erri=',strcat('err',num2str(i)),';']);
    trunc_lag=4; [re4, cv] = nsvol_test(erri,trunc_lag); reauto = nsvol_test(erri);
	test_nsvol_lag4(:,i) = re4; test_nsvol_lagauto(:,i) = reauto;
end
sigre=[];
for j=1:4
rej=test_nsvol_lag4(j,:); cvj=cv(j,:);
rej(find(rej>=cvj(3)))=-3; rej(find(rej>=cvj(2)))=-2; rej(find(rej>=cvj(1)))=-1; rej(find(rej<cvj(1) & rej>=0))=0; 
sigre=[sigre; abs(rej)];
end
test_nsvol_lag4_withstar = printLaTex_withstars_3f(test_nsvol_lag4', sigre'); % generate LaTex output
cv_cell = get_3f(cv);
Table1 = cell2table([test_nsvol_lag4_withstar; cv_cell']);
writetable(Table1, 'Table_Stock_nsvoltest.xls','WriteVariableNames',0);

% Table 6: bubble tests
rng('default'); rng(10);
test_HLZa=zeros(3,N); % U, supBZ, supDF (supBZ may suffer from non-monotonic power), ---HLZa, ER paper
for i = 1:10
    yi=y(:,i); [res] = bootBZDF(yi);
	test_HLZa(:,i) = res; 
end
rng('default'); rng(10);
test_HLZb=zeros(6,N); % uPSYsPSY, PSY, sPSY, uPWYsPWY, PWY, sPWY, ---HLZb, ET paper
for i = 1:10
    yi=y(:,i); [res] = bootsPSY_HLZ(yi);
	test_HLZb(:,i) = res; 
end
Table2 = [test_HLZa', test_HLZb(1:3,:)']; 
beta_all_ar1 = zeros(1,N);
for i = 1:10
yi=y(:,i); yi2=yi(2:end); yi1=[yi(1:end-1), ones(T-1,1)]; bi=(yi1'*yi1)\(yi1'*yi2); beta_all_ar1(:,i)=bi(1);
end
Table2 = [beta_all_ar1', Table2];
Table2 = get_3f(Table2);
Table2 = cell2table(Table2);
writetable(Table2, 'Table_Stock_bubbletests.xls','WriteVariableNames',0);

% Table 7: CI construction
rng('default'); rng(10);
sig=0.05; brep=499+1;
re_CI=[];
for i=1:N
    [CI] = CI_est(y(:,i),sig,brep); re_CI=[re_CI, CI];
end

m1=beta_all_ar1;  
m2=re_CI(:,1:2:19); m2 = ceil(m2*1000)/1000;
m3=re_CI(:,2:2:20); m3 = floor(m3*1000)/1000;
[len1, len2]=size(m2); Table3=[];
for i=1:len2
    m1_i=m1(i); mm1=num2str(m1_i,'%.3f'); Table3=[Table3, split(mm1)]; 
end
for i=1:len1
    temp1=[];
    for j=1:len2
        m2_ij=max(m2(i,j),1.001); mm2=num2str(m2_ij,'%.3f');
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.3f');
        temp2=[split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table3=[Table3; temp1];
end
Table3=cell2table(Table3');
for i=[5,6,8] Table3(i,2:end)={'-'}; end
writetable(Table3,'Table_Stock_CI.xls','WriteVariableNames',0);



