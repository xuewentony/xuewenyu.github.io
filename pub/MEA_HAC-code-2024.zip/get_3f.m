% This function reformalizes the output to have exactly 3 digits.

function re = get_3f(A)

[m, n] = size(A);
re = [];
for i=1:m
    temp=[];
    for j=1:n
      tempj = num2str(A(i,j),'%.3f'); 
      temp = [temp, split(tempj)];
    end 
    re = [re; temp];
end

end




