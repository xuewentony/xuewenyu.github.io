%%%  This program generates the empirical results for Application I.
clc; clear all;
% Data cleaning 
data1=readmatrix('CSUSHPISA.csv'); y1 = data1(182:231,2); 
% National, peak at 231th: 184.364, 03/01/2006, take 50 series, then 182th-231th: 02/01/2002 - 03/01/2006
data2=readmatrix('SPCS20RSA.csv'); y2 = data2(27:76,2); 
% US-20, peak at 76th: 206.6561, 04/01/2006, take 50 series, then 27th-76th: 03/01/2002 - 04/01/2006
data3=readmatrix('SPCS10RSA.csv'); y3 = data3(183:232,2); 
% US-10, peak at 232th: 226.9045, 04/01/2006, take 50 series, then 183th-232th: 03/01/2002 - 04/01/2006

y = [y1, y2, y3];
[T, N] = size(y);   %%%data: T=50; N=3;
names={'National';'20-City Composite';'10-City Composite'};

% Model estimation
option = 1; fixlag = []; IC = 2; K = 6;
beta_all=zeros(1,N); optlag = zeros(1,N); 
for i = 1:3
yi=y(:,i); [rhoi, erri, optlagi] = AR_est(yi,option,fixlag,IC,K);
eval([strcat('err',num2str(i)),'=erri;']); beta_all(:,i)=rhoi; optlag(i) = optlagi;
end

% Figure 3: Raw series, variance Profile & nonparametric volatility estimates
idx1 = [1:3]; idx2 = [4:6]; idx3 = [7:9]; cpool = [0.25; 0.4; 0.6; 0.75]; 
sd1 = datenum('02-2002','mm-yyyy'); ed1 = datenum('03-2006','mm-yyyy'); dt1 = linspace(sd1,ed1,50);
sd2 = datenum('03-2002','mm-yyyy'); ed2 = datenum('04-2006','mm-yyyy'); dt2 = linspace(sd2,ed2,50);
figure; 
for i = 1:3
    if i==1 dt=dt1; else dt=dt2; end
	
    subplot(3,3,idx1(i)); plot(dt,y(:,i),'LineWidth',1); 
    datetick('x','yy','keeplimits');  xlabel('Year') %hold off;
    title(names(i)); xlim([dt(1) dt(end)]); 
    if i ==1 ylabel('Index Value'); end;
	
    eval(['erri=',strcat('err',num2str(i)),';']);
    erri(find(isnan(erri))) = []; errisq = erri.^2;
    len = length(errisq); new = zeros(len,1);
    for ii = 1:length(new)
        new(ii) = (sum(errisq(1:ii)))/sum(errisq);
    end
    b = [0:1/(length(new)-1):1]';
    subplot(3,3,idx2(i)); plot(b,new,'k',b,b,'--r','LineWidth',1); 
    if i ==1 ylabel('Variance Profile'); end
        
    eval(['erri=',strcat('err',num2str(i)),';']);
    erri(find(isnan(erri))) = []; len = length(erri);
    sigmasq = npvol_esti(erri,cpool); sigmasq = sigmasq/mean(sigmasq);
    subplot(3,3,idx3(i)); 
    plot(dt(T-length(erri)+1:T),sigmasq,'--b','LineWidth',1); hold on; 
    plot(dt(T-length(erri)+1:T),ones(length(erri),1),':k','LineWidth',1); 
    datetick('x','yy','keeplimits'); xlabel('Year');
    if i ==1 ylabel('Volatility Intensity'); end; 
	xlim([dt(1) dt(end)]);

end
set(gcf, 'Units', 'centimeters', 'Position', [2, 2, 24, 24]);
saveas(gcf,'Fig-UShouse-RawSeries-VarianceProfile_VolEstimates','epsc');

% Table 8, panel A: nonstationary volatility tests and bubble tests
test_nsvol_lag4=zeros(4,N); test_nsvol_lagauto=zeros(4,N);
for i = 1:N
    eval(['erri=',strcat('err',num2str(i)),';']);
    trunc_lag=4; %trunc_lag=2; 
    [re4, cv] = nsvol_test(erri,trunc_lag); reauto = nsvol_test(erri);
	test_nsvol_lag4(:,i) = re4; test_nsvol_lagauto(:,i) = reauto;
end
sigre=[];
for j=1:4
rej=test_nsvol_lag4(j,:); cvj=cv(j,:);
rej(find(rej>=cvj(3)))=-3; rej(find(rej>=cvj(2)))=-2; rej(find(rej>=cvj(1)))=-1; rej(find(rej<cvj(1) & rej>=0))=0; 
sigre=[sigre; abs(rej)];
end
test_nsvol_lag4_withstar = printLaTex_withstars_3f(test_nsvol_lag4', sigre'); % generate LaTex output
cv_cell = get_3f(cv);
Table1 = cell2table([test_nsvol_lag4_withstar; cv_cell']);
%writetable(Table1, 'Table_UShouse_nsvoltest.xls','WriteVariableNames',0);

% Table 8, panel B: bubble tests
rng('default'); rng(10);
test_HLZa=zeros(3,N); % U, supBZ, supDF (supBZ may suffer from non-monotonic power), ---HLZa, ER paper
for i = 1:N
    yi=y(:,i); [res] = bootBZDF(yi);
	test_HLZa(:,i) = res; 
end
rng('default'); rng(10);
test_HLZb=zeros(6,N); % uPSYsPSY, PSY, sPSY, uPWYsPWY, PWY, sPWY, ---HLZb, ET paper
for i = 1:N
    yi=y(:,i); [res] = bootsPSY_HLZ(yi);
	test_HLZb(:,i) = res; 
end
Table2 = [test_HLZa', test_HLZb(1:3,:)']; Table2_v2 = get_3f(Table2);
Table2 = cell2table(Table2_v2);
%writetable(Table2, 'Table_UShouse_bubbletests.xls','WriteVariableNames',0);
Table12 = cell2table([test_nsvol_lag4_withstar'; Table2_v2']);
writetable(Table12, 'Table_UShouse_nsvolbubbletests.xls','WriteVariableNames',0);

% Table 9: CI construction
rng('default'); rng(10);
sig=0.05; brep=400; brep=499+1;
re_CI=[];
for i=1:N
    [CI] = CI_est(y(:,i),sig,brep); re_CI=[re_CI, CI];
end

beta_all_ar1 = zeros(1,N);
for i = 1:N
yi=y(:,i); yi2=yi(2:end); yi1=[yi(1:end-1), ones(T-1,1)]; bi=(yi1'*yi1)\(yi1'*yi2); beta_all_ar1(:,i)=bi(1);
end
m1=beta_all_ar1;  
m2=re_CI(:,1:2:5); m2 = ceil(m2*1000)/1000;
m3=re_CI(:,2:2:6); m3 = floor(m3*1000)/1000;
[len1, len2]=size(m2); Table3=[];
for i=1:len2
    m1_i=m1(i); mm1=num2str(m1_i,'%.3f'); Table3=[Table3, split(mm1)]; 
end
for i=1:len1
    temp1=[];
    for j=1:len2
        m2_ij=max(m2(i,j),1.001); mm2=num2str(m2_ij,'%.3f');
        m3_ij=m3(i,j); mm3=num2str(m3_ij,'%.3f');
        temp2=[split(strcat('[',mm2,', ',mm3,']'))];
        temp1=[temp1, temp2];
    end
    Table3=[Table3; temp1];
end
Table3=cell2table(Table3);
writetable(Table3,'Table_UShouse_CI.xls','WriteVariableNames',0);



