% This function coducts the nonstationary volatility test of Cavaliere and Taylor (2008, JTSA).

function [re, cv] = nsvol_test(u,trunc_lag)

T=length(u); usq = u.^2;
eta = zeros(T,1);
for t = 1:T
    eta(t) = (sum(usq(1:t)))/sum(usq);
end
W=eta-[1:T]'/T;

omegasq=sum(usq)/T;
if nargin == 1  %% if trunc_lag is not specified, do Andrews' (1993, ETCA) rule
    lambda = LRV_Bartlette(usq-mean(usq));
else %% else, using the specified trunc_lag
    lambda = LRV_Bartlette(usq-mean(usq),trunc_lag);
end

H_R=T^(1/2)*omegasq/sqrt(lambda)*(max(W)-min(W)); 
H_KS=T^(1/2)*omegasq/sqrt(lambda)*max(abs(W)); 
H_CVM=T*omegasq^2/lambda*mean(W.^2); 
H_AD=T*omegasq^2/lambda*sum(W(2:T-1).^2./(([2:T-1]'/T).*(1-[2:T-1]'/T)))/T; 

re=[H_R; H_KS; H_CVM; H_AD];

cv = [1.62, 1.75, 2.01; 1.23, 1.36, 1.63; 0.347, 0.461, 0.743; 1.933, 2.492, 3.85]; % 10%, 5%, 1% critical values from Shorack and Wellner (1986)

end

%%% --- Below are functions (Bartlette kernel Long Run Variance estimate) built in the main function nsvol_test.m ---
function [jhat] = LRV_Bartlette(u,st);

nt = length(u); 
if nargin == 1 st = bandw(u); end %if trunc_lag is not specified, do Andrews' (1993, ETCA) rule

% lag 0 covariance
jhat=u'*u;

if st ~= 0
% forward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*u(j+1:nt,:)'*u(1:nt-j,:);
end
% backward sum
for j=1:nt-1
    jhat=jhat+kern(j/st)*u(1:nt-j,:)'*u(j+1:nt,:);
end
end

jhat=jhat/(nt);

end

function st=bandw(vhat)
% procedure that compute the automatic bandwidth based on AR(1)
% approximation for each vector of the matrix vhat. Each are given equal
% weight 1.
[nt,d]=size(vhat);
a1n=0;
a1d=0;
for i=1:d
    b=olsqr(vhat(2:nt,i),vhat(1:nt-1,i));
    sig=(vhat(2:nt,i)-b*vhat(1:nt-1,i))'*(vhat(2:nt,i)-b*vhat(1:nt-1,i));
    sig=sig/(nt-1);
    a1n=a1n+4*b*b*sig*sig/((1-b)^6*(1+b)^2);
    a1d=a1d+sig*sig/(1-b)^4;
end
a1=a1n/a1d;
st=1.1447*(a1*nt)^(1/3);
end

function ker=kern(x)
% procedure to evaluate the Bartlette kernel at some value x.
ker=(1-abs(x)).*(abs(x) <=1);
end

function b=olsqr(y,x)
b=inv(x'*x)*x'*y;
end