% This function conducts bootstrap bubble tests of HLZ (2020, ET)
function [re] = bootsPSY_HLZ(y)

r0=.1; brep=499; T=length(y); %siglev=.05;
res = sPSY_HLZ(y,T,r0);
resb = zeros(brep,6);
for b = 1:brep
    err = diff(y); yb=cumsum([0; err.*randn(T-1,1)]);
    resb(b,:) = sPSY_HLZ(yb,T,r0);
end
re = 1-mean(res > resb);
end

%%% --- Below are some functions built in the main function bootsPSY_HLZ.m ---
function [re] = sPSY_HLZ(y,T,r0)

IC=0; adflag=0; swindow0 = floor(r0*T);
[PSY PWY]=PSYPWYcal(y,swindow0,IC,adflag);
[sPSY sPWY]=sPSYsPWYcal(y,swindow0);

uPSYsPSY = max([PSY, sPSY]);
uPWYsPWY = max([PWY, sPWY]);
re = [uPSYsPSY PSY sPSY uPWYsPWY PWY sPWY];
end

function [gsadf sadf]=PSYPWYcal(y,swindow0,IC,adflag)

T=length(y);
gsadfs=NaN(T,1); adfs=NaN(T,1);
for r2=swindow0:1:T
    rwadft=zeros(r2-swindow0+1,1);
    for r1=1:1:r2-swindow0+1
               rwadft(r1)= ADF(y(r1:r2,1),IC,adflag);   % two tail 5% significant level
    end
    gsadfs(r2)=max(rwadft);
	adfs(r2)=rwadft(1);
end

gsadf=max(gsadfs(swindow0:T));
sadf=max(adfs(swindow0:T));

end 

function ADFlag= ADF(y,IC,adflag)

T0=length(y);
T1=size(y,1)-1; const=ones(T1,1); 

y1  = y(1:T1);
dy  = y(2:T0)- y(1:T1);
x1=[y1 const]; 

T=T1-adflag;
dof=T-2;

if IC>0
            ICC=zeros(adflag+1,1);
            ADF=zeros(adflag+1,1);
            
            for k=0:1:adflag
                  % Model specification
                   xx=x1(adflag+1:T1,:);         %@-from k+1 to the end (including y1 and x)-@
                   dy01=dy(adflag+1:T1);      %@-from k+1 to the end (including dy0)-@

                   if k>0
                           x2=[xx zeros(T,k)];
                           for j=1:1:k
                              x2(:,size(xx,2)+j)=dy(adflag+1-j:T1-j);     % @-including k lag variables of dy in x2-@
                           end
                   else
                          x2=xx;
                   end
                   
                   % OLS regression
                   beta = (x2'*x2)\(x2'*dy01);                               % @-model A-@
                   eps  = dy01 - x2*beta;

                   % Information Criteria
                  npdf=sum(-1/2*log(2*pi)-1/2*(eps.^2));
                 if IC==1               %@ AIC @
                        ICC(k+1)=-2*npdf/T+2*size(beta,1)/T;
                 elseif IC==2           %@ BIC @
                        ICC(k+1)=-2*npdf/T+size(beta,1)*log(T)/T;
                 end

                se = eps'*eps/dof;
                sig=sqrt(diag(se*inv(x2'*x2)));

                ADF(k+1)=beta(1)/sig(1);
            end
            
            [~, lag0]=min(ICC);
            ADFlag=ADF(lag0);
            %lag=lag0-1;
            
elseif IC==0
  
              %% Model specification
               xx=x1(adflag+1:T1,:);         %@-from k+1 to the end (including y1 and x)-@
               dy01=dy(adflag+1:T1);      %@-from k+1 to the end (including dy0)-@

               if adflag>0
                       x2=[xx zeros(T,adflag)];
                       for j=1:1:adflag
                          x2(:,size(xx,2)+j)=dy(adflag+1-j:T1-j);     % @-including k lag variables of dy in x2-@
                       end
               else
                      x2=xx;
               end

               %% OLS regression
               beta = (x2'*x2)\(x2'*dy01);                               % @-model A-@
               eps  = dy01 - x2*beta;

                se = eps'*eps/dof;
                sig=sqrt(diag(se*inv(x2'*x2)));

                ADFlag=beta(1)/sig(1);
end
end

function [gsadf sadf]=sPSYsPWYcal(y,swindow0)

dy=diff(y); ct=-2*(dy<=0)+1; y=cumsum(ct); T=length(y);
gsadfs=NaN(T,1); adfs=NaN(T,1);
for r2=swindow0:1:T
    rwadft=zeros(r2-swindow0+1,1);
    for r1=1:1:r2-swindow0+1
               rwadft(r1)= sDFcal(y(r1:r2));   
    end
    gsadfs(r2)=max(rwadft);
	adfs(r2)=rwadft(1);
end

gsadf=max(gsadfs(swindow0:T));
sadf=max(adfs(swindow0:T));

end 

function re = sDFcal(y)
depvar=diff(y); regs=y(1:end-1); T=length(depvar);
regs2=regs'*regs; rho=regs'*depvar/regs2; 
err=depvar-regs*rho; s2=(err'*err/T)/regs2; re=rho/sqrt(s2);
end