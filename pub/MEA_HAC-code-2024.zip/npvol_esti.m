% This function coducts the nonparametric volatility estimation after model selection. 

function sigmasq = npvol_esti(err,cpool)

T = length(err); sigmasq = zeros(T,1);
x = [1:T]'; usq = err.^2;
hpool = cpool*T^(-0.4); hn = length(hpool);
hh = hpool; check = zeros(hn,1);
q = usq; hi = 1;
while hi <= hn
    h = hh(hi);
    qh = epi(x,T*h,1)*usq;
    check(hi) = sum((q-qh).^2);
    hi = hi+1;
end
[~, hi] = min(check); h = hh(hi);
sigmasq = epi(x,T*h,0)*usq;

end

%%% --- Below are some functions built in the main function npvol_esti.m ---
function w = epi(a,h,leave)
aa = a*ones(1,length(a))-ones(length(a),1)*a';
u = (aa'/h)';
w = 1/sqrt(2*pi)*exp(-u.^2/2);
if leave==1
    for i=1:length(w(:,1))
        w(i,i)=0;
    end
end
w=w./(sum(w')'*ones(1,length(w(1,:))));
end