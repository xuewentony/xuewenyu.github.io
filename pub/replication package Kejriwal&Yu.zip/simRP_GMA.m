% This function computes the AMSE/MSFE of various FGLS and OLS estimators
% for given c using simulated random processes.

function [glsre0, glsre1, olsre0, olsre1] = simRP_GMA(num,n,ctotal)

lenc = length(ctotal);
%%% --- simulated random processes under GLS ---
Fm_p0 = zeros(5,lenc); Fm_p1 = zeros(5,lenc);
Ff_p0 = zeros(5,lenc); Ff_p1 = zeros(5,lenc);
cv0 = -1.98; cv1 = -2.91;
parfor j = 1:lenc
    c = ctotal(j);
    rng('default'); rng(1000)
    ma_p0 = zeros(num,1); ma_p1 = zeros(num,1);
    m0_p0 = zeros(num,1); m0_p1 = zeros(num,1);
    m1_p0 = zeros(num,1); m1_p1 = zeros(num,1);
    m01_p0 = zeros(num,1); m01_p1 = zeros(num,1);
    mdf_p0 = zeros(num,1); mdf_p1 = zeros(num,1);
    fa_p0 = zeros(num,1); fa_p1 = zeros(num,1);
    f0_p0 = zeros(num,1); f0_p1 = zeros(num,1);
    f1_p0 = zeros(num,1); f1_p1 = zeros(num,1);
    f01_p0 = zeros(num,1); f01_p1 = zeros(num,1);
    fdf_p0 = zeros(num,1); fdf_p1 = zeros(num,1);
    for i = 1:num
        W = BM(n); [J] = JC(W,c);
        [dmJ] = dm_JC(J); [dtJ] = dt_JC(J);
        [df_t] = DF(dtJ,W); dw = diff(W);
        
        [df] = DF(J,W); gls_p0 = df*J;
        dw_dot = dw-df_t*J(1:end-1)*1/n; c_dot = c+df_t;
        theta_dot = (1-c_dot+1/3*c_dot^2)^(-1);
        Pv = J-[0:n]'/(n+1)*(theta_dot*(1-c_dot*[1:n]/(n+1))*dw_dot);
        gamma1=theta_dot*(1-c_dot*[1:n]/(n+1))*dw_dot;
        df_Pdenom=(1/length(Pv))*Pv(1:end-1)'*Pv(1:end-1);
        df_Pnum=Pv(1:end-1)'*dw+(1/n)*gamma1*Pv(1:end-1)'*(c*[1:n]'/(n+1)-ones(n,1));
        dfP= df_Pnum/df_Pdenom;
        gls_p1 = gamma1*(1-c*[0:n]'/(n+1))+dfP*Pv;
        
        Cons_p0 = -c*J; Cons_p1 = -c*dmJ+W(end);
        
        Fc_p0 = mean(Cons_p0.^2)+mean(gls_p0.^2)-2*mean(Cons_p0.*gls_p0);
        Fc_p1 = mean(Cons_p1.^2)+mean(gls_p1.^2)-2*mean(Cons_p1.*gls_p1);
        
        w0 = 0*(Fc_p0 <=1) + (1-1/Fc_p0)*(Fc_p0 >1); w1 = 0*(Fc_p1 <=1) + (1-1/Fc_p1)*(Fc_p1 >1);
        
        m0_p0(i) = mean(Cons_p0.^2); m0_p1(i) = mean(Cons_p1.^2);
        f0_p0(i) = Cons_p0(end)^2; f0_p1(i) = Cons_p1(end)^2;
        
        m1_p0(i) = mean(gls_p0.^2); m1_p1(i) = mean(gls_p1.^2);
        f1_p0(i) = gls_p0(end)^2; f1_p1(i) = gls_p1(end)^2;
        
        m01_p0(i) = (Cons_p0'*gls_p0)/(n+1); m01_p1(i) = (Cons_p1'*gls_p1)/(n+1);
        f01_p0(i) = Cons_p0(end)*gls_p0(end); f01_p1(i) = Cons_p1(end)*gls_p1(end);
        
        dfgls0 = (0.5*(J(end)^2-1)/sqrt(mean(J.^2)) > cv0);
        dfest0 = Cons_p0*dfgls0+gls_p0*(1-dfgls0);
        lambda = (1+13.5)/(1+13.5+13.5^2/3);
        V = J-[0:n]'/(n+1)*(lambda*J(end)+3*(1-lambda)*mean([0:n]'/(n+1).*J));
        dfgls1 = (0.5*(V(end)^2-1)/sqrt(mean(V.^2)) > cv1);
        dfest1 = Cons_p1*dfgls1+gls_p1*(1-dfgls1);
        
        mdf_p0(i) = (dfest0'*dfest0)/(n+1); mdf_p1(i) = (dfest1'*dfest1)/(n+1);
        fdf_p0(i) = dfest0(end)^2; fdf_p1(i) = dfest1(end)^2;
        
        est0 = w0*gls_p0 + (1-w0)*Cons_p0; est1 = w1*gls_p1 + (1-w1)*Cons_p1;
        ma_p0(i) = est0'*est0/(n+1); ma_p1(i) = est1'*est1/(n+1);
        fa_p0(i) = (est0(end))^2; fa_p1(i) = (est1(end))^2;
        
    end
    Fm_p0(:,j) = mean([mdf_p0, m0_p0, m1_p0, ma_p0, m01_p0]); 
	Fm_p1(:,j) = mean([mdf_p1, m0_p1, m1_p1, ma_p1, m01_p1]);    
    Ff_p0(:,j) = mean([fdf_p0, f0_p0, f1_p0, fa_p0, f01_p0]); 
	Ff_p1(:,j) = mean([fdf_p1, f0_p1, f1_p1, fa_p1, f01_p1]);
    
end
for j = 1:lenc
    Fm_p0(5,j) = (Fm_p0(2,j)*Fm_p0(3,j)-Fm_p0(5,j)^2)/(Fm_p0(2,j)+Fm_p0(3,j)-2*Fm_p0(5,j));
    Fm_p1(5,j) = (Fm_p1(2,j)*Fm_p1(3,j)-Fm_p1(5,j)^2)/(Fm_p1(2,j)+Fm_p1(3,j)-2*Fm_p1(5,j));
    
    Ff_p0(5,j) = (Ff_p0(2,j)*Ff_p0(3,j)-Ff_p0(5,j)^2)/(Ff_p0(2,j)+Ff_p0(3,j)-2*Ff_p0(5,j));
    Ff_p1(5,j) = (Ff_p1(2,j)*Ff_p1(3,j)-Ff_p1(5,j)^2)/(Ff_p1(2,j)+Ff_p1(3,j)-2*Ff_p1(5,j));
end
glsre0 = [Fm_p0; Ff_p0]; glsre1 = [Fm_p1; Ff_p1];

%%% --- simulated random processes under OLS ---
Fm_p0 = zeros(5,lenc); Fm_p1 = zeros(5,lenc);
Ff_p0 = zeros(5,lenc); Ff_p1 = zeros(5,lenc);
cv0 = -2.86; cv1 = -3.41;
parfor j = 1:lenc
    c = ctotal(j);
    rng('default'); rng(1000)
    ma_p0 = zeros(num,1); ma_p1 = zeros(num,1);
	m0_p0 = zeros(num,1); m0_p1 = zeros(num,1);
    m1_p0 = zeros(num,1); m1_p1 = zeros(num,1);
    m01_p0 = zeros(num,1); m01_p1 = zeros(num,1);
    mdf_p0 = zeros(num,1); mdf_p1 = zeros(num,1);
    fa_p0 = zeros(num,1); fa_p1 = zeros(num,1);
    f0_p0 = zeros(num,1); f0_p1 = zeros(num,1);
    f1_p0 = zeros(num,1); f1_p1 = zeros(num,1);
    f01_p0 = zeros(num,1); f01_p1 = zeros(num,1);
    fdf_p0 = zeros(num,1); fdf_p1 = zeros(num,1);
    for i = 1:num
        W = BM(n); [J] = JC(W,c);
        [dmJ] = dm_JC(J); [dtJ] = dt_JC(J);
        [df_t] = DF(dtJ,W); dw = diff(W);
        
        [df] = DF(J,W); [df_m] = DF(dmJ,W);
        ols_p0 = df_m*dmJ+W(end);
        temp1 = (6*([0:n-1]'/(n))-3*ones(n,1))'*dw*(2*[0:n]'/(n)-1);
        ols_p1 = temp1+df_t*dtJ+W(end);   
        
        Cons_p0 = -c*J; Cons_p1 = -c*dmJ+W(end);
        
        Fc_p0 = mean(Cons_p0.^2)+mean(ols_p0.^2)-2*mean(Cons_p0.*ols_p0);
        Fc_p1 = mean(Cons_p1.^2)+mean(ols_p1.^2)-2*mean(Cons_p1.*ols_p1);
        
        w0 = 0*(Fc_p0 <=2) + (1-2/Fc_p0)*(Fc_p0 >2); w1 = 0*(Fc_p1 <=2) + (1-2/Fc_p1)*(Fc_p1 >2);
        
        m0_p0(i) = mean(Cons_p0.^2); m0_p1(i) = mean(Cons_p1.^2);
        f0_p0(i) = Cons_p0(end)^2; f0_p1(i) = Cons_p1(end)^2;
        
        m1_p0(i) = mean(ols_p0.^2); m1_p1(i) = mean(ols_p1.^2);
        f1_p0(i) = ols_p0(end)^2; f1_p1(i) = ols_p1(end)^2;
        
        m01_p0(i) = (Cons_p0'*ols_p0)/(n+1); m01_p1(i) = (Cons_p1'*ols_p1)/(n+1);
        f01_p0(i) = Cons_p0(end)*ols_p0(end); f01_p1(i) = Cons_p1(end)*ols_p1(end);
        
        dfols0 = (0.5*(dmJ(end)^2-1)/sqrt(mean(dmJ.^2)) > cv0);
        dfest0 = Cons_p0*dfols0+ols_p0*(1-dfols0);
        dfols1 = (0.5*(dtJ(end)^2-1)/sqrt(mean(dtJ.^2)) > cv1);
        dfest1 = Cons_p1*dfols1+ols_p1*(1-dfols1);
        
        mdf_p0(i) = (dfest0'*dfest0)/(n+1); mdf_p1(i) = (dfest1'*dfest1)/(n+1);
        fdf_p0(i) = dfest0(end)^2; fdf_p1(i) = dfest1(end)^2;
        
        est0 = w0*ols_p0 + (1-w0)*Cons_p0; est1 = w1*ols_p1 + (1-w1)*Cons_p1;
        ma_p0(i) = est0'*est0/(n+1); ma_p1(i) = est1'*est1/(n+1);
        fa_p0(i) = (est0(end))^2; fa_p1(i) = (est1(end))^2;
        
    end
    Fm_p0(:,j) = mean([mdf_p0, m0_p0, m1_p0, ma_p0, m01_p0]);
    Fm_p1(:,j) = mean([mdf_p1, m0_p1, m1_p1, ma_p1, m01_p1]);
    
    Ff_p0(:,j) = mean([fdf_p0, f0_p0, f1_p0, fa_p0, f01_p0]);
    Ff_p1(:,j) = mean([fdf_p1, f0_p1, f1_p1, fa_p1, f01_p1]);
    
end
for j = 1:lenc
    Fm_p0(5,j) = (Fm_p0(2,j)*Fm_p0(3,j)-Fm_p0(5,j)^2)/(Fm_p0(2,j)+Fm_p0(3,j)-2*Fm_p0(5,j));
    Fm_p1(5,j) = (Fm_p1(2,j)*Fm_p1(3,j)-Fm_p1(5,j)^2)/(Fm_p1(2,j)+Fm_p1(3,j)-2*Fm_p1(5,j));
    
    Ff_p0(5,j) = (Ff_p0(2,j)*Ff_p0(3,j)-Ff_p0(5,j)^2)/(Ff_p0(2,j)+Ff_p0(3,j)-2*Ff_p0(5,j));
    Ff_p1(5,j) = (Ff_p1(2,j)*Ff_p1(3,j)-Ff_p1(5,j)^2)/(Ff_p1(2,j)+Ff_p1(3,j)-2*Ff_p1(5,j));
end
olsre0 = [Fm_p0; Ff_p0]; olsre1 = [Fm_p1; Ff_p1];

end

%%% --- Below are some functions built in the main function simRP_GMA.m ---
function ans = g(c)
ans = (c >= -1e-8)+(c < -1e-8).*(exp(c)-1)./(c+(c >= -1e-8));
end

function [J] = JC(x,c)
N = length(x)-1;
dw = diff(x)*sqrt(N);
J = zeros(N+1,1);
for i = 2:N+1
J(i) = (1+c/N)*J(i-1)+ dw(i-1);
end
J = J/sqrt(N);
end

function [x] = BM(N)
dt = 1/N;
e = sqrt(dt)*randn(N,1);
x = zeros(N+1,1);
for i = 1:N
    x(i+1) = x(i) + e(i);
end
end

function [df] = DF(Bc,W)

N = length(W)-1;
dw = diff(W);
nume = Bc(1:end-1)'*dw;
denom = mean(Bc.^2);
df = nume/denom;
end

function [dmJ] = dm_JC(J)
dmJ = J-mean(J);
end

function [dtJ] = dt_JC(J)
N = length(J)-1;
In_sJ = [0:N]/(N+1)*J/(N+1);
dtJ = zeros(N+1,1);
for i = 1:N+1
dtJ(i) = J(i) -(4-6*i/(N+1))*mean(J)-(12*i/(N+1)-6)*In_sJ;
end
end