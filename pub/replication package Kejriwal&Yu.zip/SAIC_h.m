% This function calculates the (h-step) ahead Selection based on AIC 
% under MacCraken-Ng transformation estimator presented in the empirical part of 
% the paper. 

function [frcst] = SAIC_h(y,maxK,p,h) 
%%% Output: 
% frcst: GLS and then OLS, note by definition it is only available under p=0

if p == 0   
    T = length(y);
    k = maxK;
    n = T-k-1;
    [mu0, mu1, e0, e1] = OLS_frcst(y,maxK,p,h);	
    ej = e1(:,k+1);
    sig = (ej'*ej)/n;
    r1 = [2:k+2]'; 
    a1 = e1'*e1;
   
    e2 = zeros(n,(k+1));
    mu2 = zeros(k+1,1);
    for j = 0:k
        [re, para, u] = GLS_frcst(y,0,j,k,h);
        mu2(j+1) = re;
        e2(:,j+1) = u;
    end
    e2j = e2(:,k+1);
    sig2 = (e2j'*e2j)/n;
    r2 = [1:k+1]';
    a2 = e2'*e2;

    aic1 = log(diag(a1)/n)+r1*2/n;
    [~, minloc1] = min(aic1);
    mu_1 = mu1(minloc1);	
    aic2 = log(diag(a2)/n)+r2*2/n;
    [~, minloc2] = min(aic2);
    mu_4 = mu2(minloc2);
    
    frcst = [mu_4,mu_1];   
end