% This function computes the dfols (lag order chosen by MAIC)
% statistic used for computing PT-OLS estimators in all 
% the figures presenting the empirical results. The function 
% is modified from Senera Ng's original code at 
% https://sites.google.com/site/sn2294/home/code-and-data

function [testre] = dfols(y,p,kmax); 

nt = length(y);
if p == 0;
	cv = -2.86;
end
if p == 1;
	cv = -3.41;
end

kmin = 0;
penalty = 0;  % 0 for maic 1 for bic%
[yols,yols2] = olsd(y,p);
[ahatols,rols,fitols] = olsqr2(yols(2:nt,1),yols(1:nt-1,1));
krule1 = s2ar(yols,penalty,kmax,kmin);
[adfols,a1ols,s2ar1] = adfp(yols,krule1);
testre = (adfols > cv);

end

%%% --- Below are some functions built in the main function dfols.m ---
function [adf,rhore,s2vec] = adfp(yt,kstar);
reg = lagn(yt,1);
dyt = [0; diff(yt,1)];
i = 1;
while i <= kstar;
    reg = [reg, lagn(dyt,i)];
    i=i+1;
end
dyt = dyt(kstar+2:end,:);
reg = reg(kstar+2:end,:);
[rho,ee,ff] = olsqr2(dyt,reg);
%nef=length(ee);%
nef = length(dyt);
s2e = ee'*ee/nef;
xx = inv(reg'*reg);
sre = xx(1,1)*s2e;
adf = rho(1,1)/sqrt(sre);
if kstar > 0;
    sumb = sum(rho(2:kstar+1));
else;
    sumb = 0;
end
s2vec = s2e/(1-sumb)^2;
rhore = rho(1,1)+1;
end

function [b, r, p] = olsqr2(y,x)
b = inv(x'*x)*x'*y;
p = x*b;
r = y-x*b;
end

function [yd, sumre] = olsd(y,p);
reg = ones(length(y),1);
trend = [1:length(y)]';
i = 1;
while i<=p;
    reg= [reg,trend.^i];
    i = i+1;
end
[ahat,yd,fit] = olsqr2(y,reg);
sumre = sum(yd(1:length(yd)-1).^2)/(length(yd)-1).^2;
end

function kopt = s2ar(yts,penalty,kmax,kmin);
nt = length(yts);
min = 9999999999;
tau = zeros(kmax+1,1);
s2e = 999*ones(kmax+1,1);
dyts = [0; diff(yts,1)];
reg = lagn(yts,1);
i=1;
while i <= kmax
    reg = [reg, lagn(dyts,i)];
    i=i+1;
end
dyts0 = dyts;
reg0 = reg;
%loop over k%
dyts0 = dyts(kmax+2:end,:);
reg0 = reg(kmax+2:end,:);
sumy = sum(reg0(:,1).*reg0(:,1));
nef = nt-kmax-1;
k = kmin;
while k <= kmax;
    b = inv(reg0(:,1:k+1)'*reg0(:,1:k+1))*reg0(:,1:k+1)'*dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
    k=k+1;
end
kk = [0:kmax]';

if penalty == 0;
    mic=log(s2e)+2.0*(kk+tau)./nef;
else
    mic=log(s2e)+log(nef)*(kk)./nef;
end
[minv, minloc] = max(-mic);
kopt = minloc -1;
end

function y = lagn(x,n);
if n > 0
    y = [zeros(n,length(x(1,:)));x(1:end-n,:)];
else
    y = [x(abs(n)+1:end,:);zeros(abs(n),length(x(1,:)))];
end
end