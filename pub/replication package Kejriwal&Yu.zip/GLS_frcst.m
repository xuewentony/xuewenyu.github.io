% This function calculates the (h-step) ahead unrestricted FGLS 
% estimator proposed in the paper. 

function [re, para, resid] = GLS_frcst(y,p,kk,K,h) 
%%% Output: 
% re: h-step prediction results.
% para: parameter estimates.
% resid: residuals.

T = length(y); k = kk+1;
if p == 1
    z = [ones(T,1), [1:T]'];
    regs = [ones(T-K-1,1), [K+2:T]'];
    regs = [regs, y(K-1+2:T-1)];
    for i = 1:k-1
        regs = [regs, y(K-i+2:T-i)-y(K-i+1:T-i-1)];
    end
    depvar = y(K+2:T);
    [beta, resid, ~] = ols(depvar,regs);
    a = beta(3);
    if a > 1
        a = 1;
    end
    yp = y(2:T)-a*y(1:T-1);
    zp = z(2:T,:)-a*z(1:T-1,:);
    yp = [y(1); yp];
    zp = [z(1,:); zp];
    [delta, ~, ~] = ols(yp,zp);
    b0 = delta(1);
    b1 = delta(2);
    u = y-z*delta;
    depvar = u(K+2:T);
    regs = [];
    for i = 1:k
        regs = [regs, u(K-i+2:T-i)];
    end
    [beta, resid, ~] = ols(depvar,regs);
    a = sum(beta);
    if a > 1
        a = 1;
    end    
    re = forecast_h(y,delta,beta,p,h);
    para = [beta; delta];
    
elseif p == 0
    
    z = [ones(T,1)];
    regs = [ones(T-K-1,1)];
    regs = [regs, y(K-1+2:T-1)];
    for i = 1:k-1
        regs = [regs, y(K-i+2:T-i)-y(K-i+1:T-i-1)];
    end
    depvar = y(K+2:T);
    [beta, resid, ~] = ols(depvar,regs);
    a = beta(2);
    if a > 1
        a = 1;
    end
    yp = y(2:T)-a*y(1:T-1);
    zp = z(2:T,:)-a*z(1:T-1,:);
    yp = [y(1); yp];
    zp = [z(1,:); zp];
    [delta, ~, ~] = ols(yp,zp);
    b0 = delta(1);
    u = y-z*delta;    
    depvar = u(K+2:T);
    regs = [];
    for i = 1:k
        regs = [regs, u(K-i+2:T-i)];
    end
    [beta, resid, ~] = ols(depvar,regs);
    a = sum(beta);
    if a > 1
        a = 1;
    end
    re = forecast_h(y,delta,beta,p,h);
    para = [beta; delta];
    
end

function yf = forecast_h(y,delta,beta,p,h)

k = length(beta);
T = length(y);
if p == 1
    
    b0 = delta(1);
    b1 = delta(2);
    ulag = [];
    for i = 0:k-1
        ulag = [ulag; y(T-i)-b0-b1*(T-i)];
    end
	F = [beta'; [eye(k-1), zeros(k-1,1)]];
	Fh = F^h;
    yf = b0+b1*(T+h)+Fh(1,:)*ulag;
    
elseif p == 0
    
    b0 = delta(1);
    ulag = [];
    for i = 0:k-1
        ulag = [ulag; y(T-i)-b0];
    end
    F = [beta'; [eye(k-1), zeros(k-1,1)]];
	Fh = F^h;
    yf = b0+Fh(1,:)*ulag;
    
end