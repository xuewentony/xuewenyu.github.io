%  FigureB2.m
%  
%  This program replicates the simulation results (Figure B.2) reported in 
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%  by Mohitosh Kejriwal and Xuewen Yu. 
%  Some parts of the program use Bruce Hansen's code available
%  at https://www.ssc.wisc.edu/~bhansen/progs/progs_paper.htm 
%
%  Note: The number of replications can be changed to a smaller number, say 
%   num = 5000, to get a quicker output. 

clc; clear all; tic
rng('default'); rng(1000);
rep = 500000; h = 1; theta = 0; p = 1;
Tall = [50 200]; kall = [0 4 8];
if p == 0  dfcrit = -2.86; dfglscrit = -1.98;
elseif p ==1  dfcrit = -3.41; dfglscrit = -2.91; end
m = 21; cs = -[0:20]'; num = 1;
for iT = 1:2
    n = Tall(iT);
    for ik = 1:3
        k = kall(ik);
        store = zeros(m,6);
        parfor di = 1:m
            rng('default'); rng(1000);
            %%%% data generating process starts
            c = cs(di);
            if k>0;
                a=-(-theta).^([1:k]');
                a0=c*(1-sum(a))/n;
            else
                a0=c/n;
            end
            stat = zeros(rep,6);
            for i  =  1:rep
                e  =  randn(n+k+1,1);
                y  =  e;
                for j  =  k+2:n+k+1
                    y(j)  =  (1+a0)*y(j-1)+e(j);
                    if k > 0
                        y(j)  =  y(j)+a'*flipud(y(j-k:j-1)-y(j-k-1:j-2));
                    end
                end
                %%%% data generating process ends
                dy = y(k+2:n+k+1)-y(k+1:n+k);
                x0 = ones(n,1);
                if k>0
                    for j = 1:k
                        x0 = [x0, y(k+2-j:n+k+1-j)-y(k+1-j:n+k-j)];
                    end
                end
                x1 = [y(k+1:n+k), [1:n]', x0];
                x0f = 1;
                if k>0;
                    x0f = [x0f, dy(n)];
                    if k>1
                        x0f = [x0f, x0(n,2:k)];
                    end
                end
                x1f = [y(n+k+1), (n+1), x0f];
                mu = y(n+k+1)*a0;
                if k>0;
                    mu=mu+x0f(2:k+1)*a;
                end
                %% mu is the infeasible optimal forecast
                beta0 = inv(x0'*x0)*x0'*dy;
                mu0 = x0f*beta0;
                e0 = dy-x0*beta0;
                sig0 = (e0'*e0)/n;
                
                xxi = inv(x1'*x1);
                beta1 = xxi*(x1'*dy);
                mu1 = x1f*beta1;
                e1 = dy-x1*beta1;
                sig1 = (e1'*e1)/n;
                adf = beta1(1)/sqrt(xxi(1,1)*sig1);
                fc = n*(sig0-sig1)/sig1;
                mdf = mu1.*(adf < dfcrit)+mu0.*(adf >= dfcrit);
                if fc > 2
                    w = 1-2/fc;
                else
                    w = 0;
                end
                mua = mu1.*w+mu0.*(1-w);
                
                [re, para, u] = GLS_frcst(y,p,k,k,h);
                mu1_gls = re-y(n+k+1);
                sig_gls = (u'*u)/n;
                fc_gls = n*(sig0-sig_gls)/sig_gls;
                if fc_gls > 1
                    w_gls = 1-1/fc_gls;
                else
                    w_gls = 0;
                end
                mua_gls = mu1_gls.*w_gls+mu0.*(1-w_gls);
                [dfgls] = dfgls_k(y,1,k);
                mdf_gls = mu1_gls.*(dfgls < dfglscrit)+mu0.*(dfgls >= dfglscrit);
                
                stat(i,1) = mu1-mu;
                stat(i,2) = mdf-mu;
                stat(i,3) = mua-mu;
                stat(i,4) = mu1_gls-mu;
                stat(i,5) = mdf_gls-mu;
                stat(i,6) = mua_gls-mu;
            end
            store(di,:) = n*mean(stat.^2)';
        end
        idstr = strcat('storefigB2_',num2str(num));
        eval([idstr,'=store;']);
        num = num +1;
    end
end
disp('Simulation experiment ends.'); toc
%%% Output storefigB2_i (i = 1,...,6) are the results we need to draw figures

figure;
store = storefigB2_1;
subplot(3,2,1)
hold on; box on;
title('T=50, k=0','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
legend('Unres-OLS','Pretest-OLS','OLS-Ave','Unres-GLS','Pretest-GLS','GLS-Ave','Location','southwest')
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefigB2_2;
subplot(3,2,3)
hold on; box on;
title('T=50, k=4','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefigB2_3;
subplot(3,2,5)
hold on; box on;
title('T=50, k=8','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefigB2_4;
subplot(3,2,2)
hold on; box on;
title('T=200, k=0','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefigB2_5;
subplot(3,2,4)
hold on; box on;
title('T=200, k=4','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefigB2_6;
subplot(3,2,6)
hold on; box on;
title('T=200, k=8','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

saveas(gcf,'FigB2.jpg'); saveas(gcf,'FigB2','epsc');