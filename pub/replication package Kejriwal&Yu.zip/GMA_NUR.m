% This function computes the GMA (S-/PA-/GA-/PT-GLS and OLS counterparts)
% estimators in our Near Unit Root model. This is used in our empirical part.

function [frcst, frcst_maxK_unr] = GMA_NUR(y,maxK,p,h) 
%%% Output: 
% frcst : GLS and then OLS, each includes S-, PA-, GA-, PT-.
% frcst_maxK_unr : GLS and then OLS, the unrestricted estimator when lag=maxK.

if p == 0
    T = length(y);
    k = maxK;
    n = T-k-1;
    [mu0, mu1, e0, e1] = OLS_frcst(y,maxK,p,h);
	
    ej = e1(:,k+1);
    sig = (ej'*ej)/n;
    r1 = [2:k+2]'*sig; 
    a1 = e1'*e1;
    mallows1 = diag(a1)+r1*2;
    [~, minloc1] = min(mallows1);
    mu_1 = mu1(minloc1);
    
    options=optimset('LargeScale','off','Display','off');
    kk = (k+1);
    alpha0 = ones(kk,1)/kk;
    w1 = quadprog(a1,r1,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
    mu_2 = mu1'*w1;
    
    r = [[0:k]'; [2:k+2]']*sig; 
    kk = 2*(k+1);
    alpha0 = ones(kk,1)/kk; 
	H01 = [e0, e1]'*[e0, e1]; H01 = (H01+H01')/2; %% to avoid Matlab warning due to round-off issues
    wa = quadprog(H01,r,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
    mu_3 = [mu0; mu1]'*wa;
    
    e2 = zeros(n,(k+1));
    mu2 = zeros(k+1,1);
    for j = 0:k
        [re, para, u] = GLS_frcst(y,0,j,k,h);
        mu2(j+1) = re;
        e2(:,j+1) = u;
    end
    e2j = e2(:,k+1);
    sig2 = (e2j'*e2j)/n;
    r2 = [1:k+1]'*sig2;
    a2 = e2'*e2;
    kk = (k+1);
    alpha0 = ones(kk,1)/kk;
    w2 = quadprog(a2,r2,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
    mu_5 = mu2'*w2;
    
    mallows2 = diag(a2)+r2*2;
    [~, minloc2] = min(mallows2);
    mu_4 = mu2(minloc2);
    
    r6 = [[0:k]'; [1:k+1]']*sig2;
    kk = 2*(k+1);
    alpha0 = ones(kk,1)/kk;
	H02 = [e0, e2]'*[e0, e2]; H02 = (H02+H02')/2; %% to avoid Matlab warning due to round-off issues
    w2a = quadprog(H02,r6,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
    mu_6 = [mu0; mu2]'*w2a;
%%% PT-OLS and PT-GLS
	e0j = e0(:,k+1); sig0 = (e0j'*e0j)/n; r0 = [0:k]'*sig0; a0 = e0'*e0;    
    mallows0 = diag(a0)+r0*2; [~, minloc0] = min(mallows0); mu_0 = mu0(minloc0);
    [testre] = dfols(y,p,maxK); mu_OLSpre = mu_0*testre+mu_1*(1-testre); 
    [testre, kopt] = dfgls_MAIC(y,p,maxK); mu_GLSpre = mu_0*testre+mu_4*(1-testre);        
	
    frcst = [mu_4,mu_5,mu_6,mu_GLSpre,mu_1,mu_2,mu_3,mu_OLSpre];
    frcst_maxK_unr = [mu2(maxK+1), mu1(maxK+1)];
	
elseif p == 1
    T = length(y);
    k = maxK;
    n = T-k-1;
    [mu0, mu1, e0, e1] = OLS_frcst(y,maxK,p,h);
    
    ej = e1(:,k+1);
    sig = (ej'*ej)/(n-k-3);
    r1 = [3:k+3]'*sig;   
    a1 = e1'*e1;
    mallows1 = diag(a1)+r1*2;
    [~, minloc1] = min(mallows1);
    mu_1 = mu1(minloc1);
    
    options=optimset('LargeScale','off','Display','off');
    kk = (k+1);
    alpha0 = ones(kk,1)/kk;
    w1 = quadprog(a1,r1,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
    mu_2 = mu1'*w1;
    
    r = [[1:k+1]'; [1+2:1+k+2]']*sig; 
    kk = 2*(k+1);
    alpha0 = ones(kk,1)/kk;
	H01 = [e0, e1]'*[e0, e1]; H01 = (H01+H01')/2; %% to avoid Matlab warning due to round-off issues
    wa = quadprog(H01,r,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
    mu_3 = [mu0; mu1]'*wa;
    
    e2 = zeros(n,(k+1));
    mu2 = zeros(k+1,1);
    for j = 0:k
        [re, para, u] = GLS_frcst(y,1,j,k,h);
        mu2(j+1) = re;
        e2(:,j+1) = u;
    end
    e2j = e2(:,k+1);
    sig2 = (e2j'*e2j)/(n-k-3);
    r2 = [2:k+2]'*sig2; 
    a2 = e2'*e2;
    kk = (k+1);
    alpha0 = ones(kk,1)/kk;
    w2 = quadprog(a2,r2,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
    mu_5 = mu2'*w2;
    
    mallows2 = diag(a2)+r2*2;
    [~, minloc2] = min(mallows2);
    mu_4 = mu2(minloc2);
    
    r6 = [[1:k+1]'; [1+1:1+k+1]']*sig2;
    kk = 2*(k+1);
    alpha0 = ones(kk,1)/kk;
	H02 = [e0, e2]'*[e0, e2]; H02 = (H02+H02')/2; %% to avoid Matlab warning due to round-off issues
    w2a = quadprog(H02,r6,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
    mu_6 = [mu0; mu2]'*w2a;
%%% PT-OLS and PT-GLS
	e0j = e0(:,k+1); sig0 = (e0j'*e0j)/n; r0 = [1:k+1]'*sig0; a0 = e0'*e0;    
    mallows0 = diag(a0)+r0*2; [~, minloc0] = min(mallows0); mu_0 = mu0(minloc0);
    [testre] = dfols(y,p,maxK); mu_OLSpre = mu_0*testre+mu_1*(1-testre);
    [testre, kopt] = dfgls_MAIC(y,p,maxK); mu_GLSpre = mu_0*testre+mu_4*(1-testre);        
	
    frcst = [mu_4,mu_5,mu_6,mu_GLSpre,mu_1,mu_2,mu_3,mu_OLSpre];
	frcst_maxK_unr = [mu2(maxK+1), mu1(maxK+1)];
end