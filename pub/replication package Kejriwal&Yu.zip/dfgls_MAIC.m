% This function computes the dfgls_MAIC (lag order chosen by MAIC)
% statistic used for computing PT-GLS estimators in all 
% the figures presenting the empirical results. The function 
% is modified from Senera Ng's original code at 
% https://sites.google.com/site/sn2294/home/code-and-data

function [testre, kopt] = dfgls_MAIC(y,p,kmax); 

nt = length(y);
if p == 0;
    z = ones(nt,1);
    cbar = -7.0;
	cv = -1.98;
end
if p == 1;
    z =[ones(nt,1), [1:nt]'];
    cbar = -13.5;
	cv = -2.91;
end

[yt,ssra] = glsd(y,z,cbar); % transforming the data%
kmin = 0;
penalty = 0;
[kopt] = s2ar(yt,penalty,kmax,kmin);
k = kopt;
dyt = diff(yt);
T = nt-1;
depvar = dyt(k+1:T);
regs = [yt(k+1:T)];
if k > 0
    for i = 1:k
        regs = [regs, dyt(k-i+1:T-i)];
    end
end

[beta, resid, ~] = ols(depvar,regs);
nef = length(dyt);
s2e = resid'*resid/nef;
xx = inv(regs'*regs);
sre = xx(1,1)*s2e;
dfgls = beta(1,1)/sqrt(sre);

testre = (dfgls > cv);

end

%%% --- Below are some functions built in the main function dfgls_MAIC.m ---
function [yt,ssr] = glsd(y,z,cbar);
nt = length(y);
abar = 1+cbar/nt;
ya = zeros(nt,1);
za = zeros(nt,length(z(1,:)));
ya(1:1,1) = y(1:1,1);
za(1:1,:) = z(1:1,:);
ya(2:nt,1) = y(2:nt,1)-abar*y(1:nt-1,1);
za(2:nt,:) = z(2:nt,:)-abar*z(1:nt-1,:);
%constructing the gls detrended series%
bhat = inv(za'*za)*za'*ya;
yt = y-z*bhat;
ssr = (ya-za*bhat)'*(ya-za*bhat);
end

function kopt = s2ar(yts,penalty,kmax,kmin);
nt = length(yts);
min = 9999999999;
tau = zeros(kmax+1,1);
s2e = 999*ones(kmax+1,1);
dyts = [0; diff(yts,1)];
reg = lagn(yts,1);
i=1;
while i <= kmax
    reg = [reg, lagn(dyts,i)];
    i=i+1;
end
dyts0 = dyts;
reg0 = reg;
%loop over k%
dyts0 = dyts(kmax+2:end,:);
reg0 = reg(kmax+2:end,:);
sumy = sum(reg0(:,1).*reg0(:,1));
nef = nt-kmax-1;
k = kmin;
while k <= kmax;
    b = inv(reg0(:,1:k+1)'*reg0(:,1:k+1))*reg0(:,1:k+1)'*dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
    k=k+1;
end
kk = [0:kmax]';
if penalty == 0;
    mic=log(s2e)+2.0*(kk+tau)./nef;
else
    mic=log(s2e)+log(nef)*(kk)./nef;
end
[minv, minloc] = max(-mic);
kopt = minloc -1;
end

function y = lagn(x,n);
if n > 0
    y = [zeros(n,length(x(1,:)));x(1:end-n,:)];
else
    y = [x(abs(n)+1:end,:);zeros(abs(n),length(x(1,:)))];
end
end