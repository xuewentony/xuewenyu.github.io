% This function is used to assist drawing figures 4 and 5.

function [tfd2] = transdata_plot(q,dm);
% q = q3
% dm = DM
d1 = q(1:20); dm1 = dm(1:20);
d2 = q(21:end); dm2 = dm(21:end);
vec1 = [45 47 48:57 87:94];
lab1 = [2 2 3*ones(1,10) 6*ones(1,8)];
mod1 = zeros(1,20);

id1 = [1,2,6:18,19]; id2 = [20:47, 120:122]; id3 = [48:57]; id4 = [3:5, 58:63, 123];
id5 = [64:73, 124:127]; id6 = [78:99]; id7 = [100:119]; id8 = [74:77]; %%% total will be 127 series
id4 = [3:5, 59,61,62,63]; id6 = [78:94, 96:99];  %%% id4 drop series 58, 60, 123 and id6 drop 95 due to too much missing data, so 123 series remained.
id1p0 = []; id2p0 = [45 47]; id3p0 = id3; id4p0 = []; id5p0 = []; id6p0 = [87:94]; id7p0 = []; id8p0 = [];

id1p1 = setdiff(id1,id1p0); id2p1 = setdiff(id2,id2p0); id3p1 = setdiff(id3,id3p0); id4p1 = setdiff(id4,id4p0);
id5p1 = setdiff(id5,id5p0); id6p1 = setdiff(id6,id6p0); id7p1 = setdiff(id7,id7p0); id8p1 = setdiff(id8,id8p0);

vec2 = [id1p1, id2p1, id3p1, id4p1, id5p1, id6p1, id7p1, id8p1];
lab2 = [1*ones(1,length(id1p1)), 2*ones(1,length(id2p1)) ...
    3*ones(1,length(id3p1)), 4*ones(1,length(id4p1)) ...
    5*ones(1,length(id5p1)), 6*ones(1,length(id6p1)) ...
    7*ones(1,length(id7p1)), 8*ones(1,length(id8p1))];
mod2 = ones(1,103);

fd1 = [d1, vec1', lab1', mod1', dm1];
fd2 = [d2, vec2', lab2', mod2', dm2];
fd = [fd1; fd2];
tfd = zeros(123, 4);
num = 1;
for i = 1:127
    if ~ismember(i,[58,60,123,95]);
        loc = find(fd(:,2)==i);
        tfd(num,1) = fd(loc,1);
        tfd(num,2) = fd(loc,3);
        tfd(num,3) = fd(loc,4);
        tfd(num,4) = fd(loc,5);
        num = num +1;
    end
end
tfd;

tfd2 = [];
for i = 1:8
    loc = find(tfd(:,2)==i);
	temp = tfd(loc,:);
	tfd2 = [tfd2; nan(2,4); sortrows(temp,3)];
end
tfd2(1:2,:) = [];

end