%  TableC4.m
%
%  This program replicates the empirical results (Table C.4) reported in
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%   by Mohitosh Kejriwal and Xuewen Yu.

clc; clear all;
%%%------- Data cleaning ------
source=importdata('Macro_8series.csv'); alldata=[source.data]; [rlen,clen]=size(alldata); alldata=[NaN(rlen,1), alldata];
%alldata = readmatrix('Macro_8series.csv');  %for Matlab versions after R2019a 
data = [alldata(1,2:end); alldata(14:end-7,2:end)];   %%%data from 1960/01-2018/12
T = length(data(:,1))-1; %%% first row stores the transformation code
N = 8;
%% actual transformation codes
trs1 = @(y) y; trs2 = @(y) diff(y); trs3 = @(y) diff(diff(y)); trs4 = @(y) log(y);
trs5 = @(y) diff(log(y)); trs6 = @(y) diff(diff(log(y))); trs7 = @(y) diff(y(2:end)./y(1:end-1)-1);
eightdata = zeros(T-2,N);  %%% since some of the data are differenced.
trscode = [5 5 5 5 6 6 6 6];
for j = 1:8
    switch trscode(j)
        case 5
            temp = trs5(data(2:end,j));
            eightdata(:,j) = temp(2:end);
        case 6
            temp = trs6(data(2:end,j));
            eightdata(:,j) = temp;
    end
end
disp("Data cleaning is complete. Forecasting starts running ...")
%%% Data cleaning output: eightdata (p=0)

%%%------- Forecasting ------
%%% rolling, multi-step forecast, set maximum number of lags MaxK=12
tabC4 = []; res_tex = []; hall = [1 6 12];
maxK = 12; scheme = 1; %% schme = 1, rolling;  = 2, recursive.
data = eightdata; %% the first data starts at 1960:03
[T, N] = size(data);
for ih = 1:3
    h = hall(ih);
    start = 118;  %% forecasting starts at 1970:01
    riskall= zeros(N,11); testre = zeros(N,10);
    for j = 1:N
        y = data(:,j);
        p = 0;
        num = T-start-h+1;
        re = zeros(num,11);
        i = 1;
        for t = start+1:T-h+1
            if scheme == 1
                yinput = y(t-start:t-1);
            elseif scheme == 2
                yinput = y(1:t-1);
            end
            yfor = y(t+h-1);
            [frcst, frcst_maxK] = GMA_NUR(yinput,maxK,p,h);
            re(i,[1:4,6:9]) = frcst-yfor;
            re(i,[5,10]) = SAIC_h(yinput,maxK,p,h)-yfor;
            re(i,11) = frcst_maxK(2)-yfor;
            i = i+1;
        end
        for ii = 1:10
            results1 = EvalFore([re(:,11), re(:,ii)],2);
            testre(j,ii) = [results1.DM(2)];
        end
        riskall(j,:) = [sqrt(mean(re.^2))];
    end
    riskall = riskall./repmat(riskall(:,11),1,11); riskall = riskall';
    DM = testre';
    DM(DM<=0.01)=3; sig3 = find(DM==3); length(find(DM==3));
    DM(DM<=0.05)=2; sig2 = find(DM==2); length(find(DM==2));
    DM(DM<=0.10)=1; sig1 = find(DM==1); length(find(DM==1));
    DM(DM<1)=0;  %% transform the DM testing p-values to numbers of stars
    
    tabC4 = [tabC4; [riskall(1:end-1,:); NaN(1,N); DM]; NaN(1,N)];
    res_tex = [res_tex; print_Texre(riskall(1:end-1,:),DM)];
    disp(strcat(num2str(hall(ih)),'-step forecasts are finished.'));
end
%% store the output
csvwrite(strcat('TableC4','_riskandDM.csv'),tabC4);

%%% Obtain the output in a LaTex format (optional)
tex_res_all = cell2table(res_tex);
writetable(tex_res_all, strcat('TableC4','_LaTex.xls'),'WriteVariableNames',0);
