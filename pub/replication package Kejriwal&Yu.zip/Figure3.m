%  Figure3.m
%  
%  This program replicates the simulation results (Figure 3) reported in 
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%  by Mohitosh Kejriwal and Xuewen Yu. 

%  Some parts of the program use Bruce Hansen's code available
%  at https://www.ssc.wisc.edu/~bhansen/progs/progs_paper.htm 
%
%  Note: The number of replications can be changed to a smaller number, say 
%   num = 5000, to get a quicker output.  

clc; clear all; tic
rng('default'); rng(1000);
rep = 500000; h = 1; theta = 0.6; p = 1;
Tall = [50 200]; kall = [4 8 12];
if p == 0  dfcrit = -2.86; dfglscrit = -1.98;
elseif p ==1  dfcrit = -3.41; dfglscrit = -2.91; end
m = 21; cs = -[0:20]'; num = 1;
for iT = 1:2
    n = Tall(iT);
    for ik = 1:3
        k = kall(ik);
        store = zeros(m,6);
        parfor di = 1:m
            rng('default'); rng(1000);
            %%%% data generating process starts
            c = cs(di);
            if k>0;
                a=-(-theta).^([1:k]');
                a0=c*(1-sum(a))/n;
            else
                a0=c/n;
            end
            stat = zeros(rep,3);
            for i  =  1:rep
                e  =  randn(n+k+1,1);
                y  =  e;
                for j  =  k+2:n+k+1
                    y(j)  =  (1+a0)*y(j-1)+e(j);
                    if k > 0
                        y(j)  =  y(j)+a'*flipud(y(j-k:j-1)-y(j-k-1:j-2));
                    end
                end
				%%%% data generating process ends
                dy = y(k+2:n+k+1)-y(k+1:n+k);
                x0 = ones(n,1);
                if k>0
                    for j = 1:k
                        x0 = [x0, y(k+2-j:n+k+1-j)-y(k+1-j:n+k-j)];
                    end
                end
                x1 = [y(k+1:n+k), [1:n]', x0];
                x0f = 1;
                if k>0;
                    x0f = [x0f, dy(n)];
                    if k>1
                        x0f = [x0f, x0(n,2:k)];
                    end
                end
                x1f = [y(n+k+1), (n+1), x0f];
                mu = y(n+k+1)*a0;
                if k>0;
                    mu=mu+x0f(2:k+1)*a;
                end
                %% mu is the infeasible optimal forecast
                e0 = zeros(n,(k+1));
                e1 = zeros(n,(k+1));
                mu0 = zeros(k+1,1);
                mu1 = zeros(k+1,1);
                s0 = x0'*dy;
                xx0 = x0'*x0;
                s1 = x1'*dy;
                xx1 = x1'*x1;
                for j = 0:k
                    betaj = inv(xx0(1:1+j,1:1+j))*s0(1:1+j);
                    mu0(j+1) = x0f(1:1+j)*betaj;
                    e0(:,j+1) = dy-x0(:,1:1+j)*betaj;
                    
                    betaj = inv(xx1(1:3+j,1:3+j))*s1(1:3+j);
                    mu1(j+1) = x1f(1:3+j)*betaj;
                    e1(:,j+1) = dy-x1(:,1:3+j)*betaj;
                end
                
                ej = e1(:,k+1);
                sig = (ej'*ej)/(n-k-3);
                r1 = [3:k+3]'*sig;   
                a1 = e1'*e1;
                mallows1 = diag(a1)+r1*2;
                [~, minloc1] = min(mallows1);
                mu_1 = mu1(minloc1);
                indx(di,i) = minloc1;
                
                options=optimset('LargeScale','off','Display','off');
                kk = (k+1);
                alpha0 = ones(kk,1)/kk;
                w1 = quadprog(a1,r1,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
                mu_2 = mu1'*w1;
                
                r = [[1:k+1]'; [1+2:1+k+2]']*sig; 
                kk = 2*(k+1);
                alpha0 = ones(kk,1)/kk;
				H01 = [e0, e1]'*[e0, e1]; H01 = (H01+H01')/2; %% to avoid Matlab warning due to round-off issues
                wa = quadprog(H01,r,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
                mu_3 = [mu0; mu1]'*wa;
                
                e2 = zeros(n,(k+1));
                mu2 = zeros(k+1,1);
                for j = 0:k
                    [re, para, u] = GLS_frcst(y,p,j,k,h);
                    mu2(j+1) = re-y(n+k+1);
                    e2(:,j+1) = u;
                end
                e2j = e2(:,k+1);
                sig2 = (e2j'*e2j)/(n-k-3);
                r2 = [2:k+2]'*sig2;  
                a2 = e2'*e2;
                kk = (k+1);
                alpha0 = ones(kk,1)/kk;
                w2 = quadprog(a2,r2,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),ones(kk,1),alpha0,options);
                mu_5 = mu2'*w2;
                
				mallows2 = diag(a2)+r2*2;
                [~, minloc2] = min(mallows2);
                mu_4 = mu2(minloc2);
				
                r6 = [[1:k+1]'; [1+1:1+k+1]']*sig2;
                kk = 2*(k+1);
                alpha0 = ones(kk,1)/kk;
				H02 = [e0, e2]'*[e0, e2]; H02 = (H02+H02')/2; %% to avoid Matlab warning due to round-off issues
                w2a = quadprog(H02,r6,zeros(1,kk),0,ones(1,kk),1,zeros(kk,1),1*ones(kk,1),alpha0,options);
                mu_6 = [mu0; mu2]'*w2a;
                
                stat(i,1) = mu_1-mu;
                stat(i,2) = mu_2-mu;
                stat(i,3) = mu_3-mu;
                stat(i,4) = mu_4-mu;
                stat(i,5) = mu_5-mu;
				stat(i,6) = mu_6-mu;
            end
            store(di,:) = n*mean(stat.^2)';
        end
        idstr = strcat('storefig3_',num2str(num));
        eval([idstr,'=store;']);
        num = num +1;
    end
end
disp('Simulation experiment ends.'); toc
%%% Output storefig3_i (i = 1,...,6) are the results we need to draw figures				
								
store = storefig3_1;
subplot(3,2,1)
hold on; box on;
title('T=50, K=4','FontSize',15)
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
h=legend('S-OLS','PA-OLS','GA-OLS','S-GLS','PA-GLS','GA-GLS','Location','southwest');
h.NumColumns=2;
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

store = storefig3_2;
subplot(3,2,3)
hold on; box on;
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);
title('T=50, K=8','FontSize',15)

store = storefig3_3;
subplot(3,2,5)
hold on; box on;
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);
title('T=50, K=12','FontSize',15)

store = storefig3_4;
subplot(3,2,2)
hold on; box on;
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);
title('T=200, K=4','FontSize',15)

store = storefig3_5;
subplot(3,2,4)
hold on; box on;
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);
title('T=200, K=8','FontSize',15)

store = storefig3_6;
subplot(3,2,6)
hold on; box on;
plot(cs,store(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(cs,store(:,2),':','color',[0.8,0,0.8],'LineWidth',2)
plot(cs,store(:,3),'-.','color',[0,0.6,0],'LineWidth',2)
plot(cs,store(:,4),'-*','color',[0,0,0],'MarkerSize',5)
plot(cs,store(:,5),'-o','color',[0.6,0.6,0],'MarkerSize',5)
plot(cs,store(:,6),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);
title('T=200, K=12','FontSize',15)

saveas(gcf,'Fig3.jpg'); saveas(gcf,'Fig3','epsc');