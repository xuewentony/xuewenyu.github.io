%  TableC3.m
%
%  This program replicates the empirical results (Table C.3) reported in
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%   by Mohitosh Kejriwal and Xuewen Yu.

clc; clear all;
%%%------- Data cleaning ------
source=importdata('FRED_MD.csv'); alldata=[source.data]; [rlen,clen]=size(alldata); alldata=[[NaN(rlen,1), alldata];NaN(1,clen+1)];
%alldata = readmatrix('FRED_MD.csv');  %for Matlab versions after R2019a
data = [alldata(1,2:end-1); alldata(14:end-7,2:end-1)];   %%%data from 1960/01-2018/12, delete the last column since VXOCLSx missing too much data
id1 = [1,2,6:18,19]; id2 = [20:47, 120:122]; id3 = [48:57]; id4 = [3:5, 58:63, 123];
id5 = [64:73, 124:127]; id6 = [78:99]; id7 = [100:119]; id8 = [74:77]; %%% total will be 127 series
id4 = [3:5, 59,61,62,63]; id6 = [78:94, 96:99];  %%% id4 drop series 58, 60, 123 and id6 drop 95 due to too much missing data, so 123 series remained.
T = length(data(:,1))-1; %%% first row stores the transformation code
%% actual transformation codes
trs1 = @(y) y; trs2 = @(y) diff(y); trs3 = @(y) diff(diff(y)); trs4 = @(y) log(y);
trs5 = @(y) diff(log(y)); trs6 = @(y) diff(diff(log(y))); trs7 = @(y) diff(y(2:end)./y(1:end-1)-1);
N_id = length([id1, id2, id3, id4, id5, id6, id7, id8]);
mixtrsdata_act = zeros(T-2,N_id);  %%% since some of the data are differenced.
mixidx_act = zeros(2,8); num0 = 0;
mixidx_act(1,:) = [1 2 3 4 5 6 7 8]; ilen = length(mixidx_act(1,:));
for ii = 1:ilen
    i = mixidx_act(1,ii);
    idstr = strcat('id',num2str(i));
    eval(['idvec','=',idstr,';']);
    idlen = length(idvec); 
    for j = 1:idlen
        num0 = num0+1;
        trscode = data(1,idvec(j));
        switch trscode
            case 1
                temp = trs1(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp(3:end);
            case 2
                temp = trs2(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp(2:end);
            case 3
                temp = trs3(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp;
            case 4
                temp = trs4(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp(3:end);
            case 5
                temp = trs5(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp(2:end);
            case 6
                temp = trs6(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp;
            case 7
                temp = trs7(data(2:end,idvec(j)));
                mixtrsdata_act(:,num0) = temp;
        end
    end
    mixidx_act(2,ii) = num0;
end
disp("Data cleaning is complete. Forecasting starts running ...")
%%% Data cleaning output: mixtrsdata_act (p=0)

%%%------- Forecasting ------
%%% rolling, multi-step forecast, set maximum number of lags MaxK=12
tabC3 = []; hall = [1 6 12];
maxK = 12; scheme = 1; %% schme = 1, rolling;  = 2, recursive.
mixtrsdata = mixtrsdata_act;  %% the first data starts at 1960:03
[T, Ndata] = size(mixtrsdata);
for ih = 1:3
    h = hall(ih);
    start = 118;  %% forecasting starts at 1970:01
    riskall = zeros(Ndata,10);
    for j = 1:Ndata
        y = mixtrsdata(:,j);
        N = length(y)-h+1;
        p = 0;
        num = N-start;
        re = zeros(num,10);
        i = 1;
        for t = start+1:N
            if scheme == 1
                yinput = y(t-start:t-1);
            elseif scheme == 2
                yinput = y(1:t-1);
            end
            yfor = y(t+h-1);
            [frcst] = GMA_NUR(yinput,maxK,p,h);
            re(i,[1:4,6:9]) = frcst-yfor;
            re(i,[5,10]) = SAIC_h(yinput,maxK,p,h)-yfor;
            i = i+1;
        end
        riskall(j,:) = [sqrt(mean(re.^2))];
    end
    cpmat = zeros(11,11);
    for i = 1:10
        for j = i+1:11
            if j ~= 11
                cpmat(i,j) = mean(riskall(:,i) < riskall(:,j));
                cpmat(j,i) = 1-cpmat(i,j);
            else
                riskleft = riskall;
                riskleft(:,i) = [];
                riskbest = [min(riskleft')]';
                cpmat(i,11) = mean(riskall(:,i) < riskbest);
            end
        end
    end
    tabC3 = [tabC3; cpmat(1:end-1,:); NaN(1,11)];
    disp(strcat(num2str(hall(ih)),'-step forecasts are finished.'));    
end
%% store the output
csvwrite(strcat('TableC3','_riskmat.csv'),tabC3);

