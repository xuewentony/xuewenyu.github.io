% This function calculates the (h-step) ahead unrestricted OLS 
% estimator proposed in Hansen (2010). It is modified from Hansen's code
% at https://www.ssc.wisc.edu/~bhansen/progs/progs_paper.htm 

function [mu0_h, mu1_h, e0, e1] = OLS_frcst(y,maxK,p,h)

%%% Output: 
% mu0_h: h-step OLS restricted results. 
% mu1_h: h-step OLS unrestricted results. 
% e0/e1: restricted/unrestricted estimation residuals.

if p == 0
    T = length(y); k = maxK; n = T-k-1;
    dy = y(k+2:n+k+1)-y(k+1:n+k); x0 = [];
    if k>0
        for j = 1:k
            x0 = [x0, y(k+2-j:n+k+1-j)-y(k+1-j:n+k-j)];
        end
    end
    x0f = [];
    if k>0
        x0f = [x0f, dy(n)];
        if k>1
            x0f = [x0f, x0(n,1:k-1)];
        end
    end
    x1 = [y(k+1:n+k), ones(n,1), x0];
    x1f = [y(n+k+1), 1, x0f];
    
    e0 = zeros(n,(k+1)); e1 = zeros(n,(k+1));
    mu0_h = zeros(k+1,1);  mu1_h = zeros(k+1,1);
    s0 = x0'*dy; xx0 = x0'*x0;
    s1 = x1'*dy; xx1 = x1'*x1;
    betaj = 0; mu0_h(1) = 0+y(end); e0(:,1) = dy-0;
    for j = 1:k
        betaj = inv(xx0(1:j,1:j))*s0(1:j);
        mu0_h(j+1) = frcst_h_ols_res(x0f(1:j),p,n+1,betaj,y(end),h);
        e0(:,j+1) = dy-x0(:,1:j)*betaj;
    end
    for j = 0:k
        betaj = inv(xx1(1:2+j,1:2+j))*s1(1:2+j);
        mu1_h(j+1) = frcst_h_ols_unres(x1f(1:2+j),p,n+1,betaj,y(end),h);
        e1(:,j+1) = dy-x1(:,1:2+j)*betaj;
    end  
elseif p == 1
    T = length(y); k = maxK; n = T-k-1;
    dy = y(k+2:n+k+1)-y(k+1:n+k); x0 = ones(n,1);
    if k>0
        for j = 1:k
            x0 = [x0, y(k+2-j:n+k+1-j)-y(k+1-j:n+k-j)];
        end
    end
    x0f = 1;
    if k>0
        x0f = [x0f, dy(n)];
        if k>1
            x0f = [x0f, x0(n,2:k)];
        end
    end
    x1 = [y(k+1:n+k), [1:n]', x0];
    x1f = [y(n+k+1), (n+1), x0f];
    e0 = zeros(n,(k+1)); e1 = zeros(n,(k+1));
    mu0_h = zeros(k+1,1); mu1_h = zeros(k+1,1);
    s0 = x0'*dy; xx0 = x0'*x0;
    s1 = x1'*dy; xx1 = x1'*x1;
    for j = 0:k
        betaj = inv(xx0(1:1+j,1:1+j))*s0(1:1+j);
        mu0_h(j+1) = frcst_h_ols_res(x0f(1:1+j),p,n+1,betaj,y(end),h);
        e0(:,j+1) = dy-x0(:,1:1+j)*betaj;
        
        betaj = inv(xx1(1:3+j,1:3+j))*s1(1:3+j);
        mu1_h(j+1) = frcst_h_ols_unres(x1f(1:3+j),p,n+1,betaj,y(end),h);
        e1(:,j+1) = dy-x1(:,1:3+j)*betaj;
    end
end
end

%%% --- Below are some functions built in the main function OLS_frcst.m ---
function xf_h = frcst_h_ols_unres(x,p,t,beta,yend,h)
% x: lag_y, trend, lag_diffy 
xf = x*beta+yend;
if h == 1
    xf_h = xf;
else
    if p == 0
        ylast = yend;
        for i = 2:h
		    if length(x) == 2 x = [xf, 1];
            elseif length(x) == 3 x = [xf, 1, xf-ylast]; 
			else x = [xf, 1, xf-ylast, x(3:end-1)]; end;
            ylast = xf;
            xf = x*beta+ylast;
        end
    elseif p == 1
        ylast = yend;
        for i = 2:h
		    if length(x) == 3 x = [xf, t+i-1, 1];
            elseif length(x) == 4 x = [xf, t+i-1, 1, xf-ylast]; 
			else x = [xf, t+i-1, 1, xf-ylast, x(4:end-1)]; end;
            ylast = xf;
            xf = x*beta+ylast;
        end
    end
    xf_h = xf;
end
end

function xf_h = frcst_h_ols_res(x,p,t,beta,yend,h)
% x: trend (if any), lag_diffy (if any)
xf = x*beta+yend;
if h == 1
    xf_h = xf;
else
    if p == 0
        ylast = yend;
        for i = 2:h
            if length(x) == 1 x = [xf-ylast];
            else x = [xf-ylast, x(1:end-1)]; end;
            ylast = xf;
            xf = x*beta+ylast;
        end
    elseif p == 1
        ylast = yend;
        for i = 2:h
		    if length(x) == 1 x = [1];
            elseif length(x) == 2 x = [1, xf-ylast]; 
			else x = [1, xf-ylast, x(2:end-1)]; end;
            ylast = xf;
            xf = x*beta+ylast;
        end
    end
    xf_h = xf;
end
end