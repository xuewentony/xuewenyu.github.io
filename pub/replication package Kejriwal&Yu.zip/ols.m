% This function coducts the ols estimation. 

function [beta resid varcov] = ols(y,x);

[T, k] = size(x);
invxx = inv(x'*x);
beta = invxx*x'*y;
resid = y-x*beta;
sigsq = resid'*resid/(T-k);
varcov = sigsq*invxx;

end


