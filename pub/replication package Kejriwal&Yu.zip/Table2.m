%  Table2.m
%  
%  This program replicates the empirical results (Table 2) reported in 
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%   by Mohitosh Kejriwal and Xuewen Yu. 

clc; clear all;
%%%------- Data cleaning ------
source=importdata('Macro_8series.csv'); alldata=[source.data]; [rlen,clen]=size(alldata); alldata=[NaN(rlen,1), alldata];
%alldata = readmatrix('Macro_8series.csv');  %for Matlab versions after R2019a 
data = [alldata(1,2:end); alldata(14:end-7,2:end)];   %%%data from 1960/01-2018/12
T = length(data(:,1))-1; %%% first row stores the transformation code
N = 8;
ttrs1 = @(y) y; ttrs4 = @(y) log(y); %%% for p=0
ttrs2 = @(y) y; ttrs3 = @(y) diff(y); %%% for p=1
ttrs5 = @(y) log(y); ttrs6 = @(y) diff(log(y)); ttrs7 = @(y) y(2:end)./y(1:end-1)-1; %%% for p=1
eightdata = zeros(T-1,N);  %%% since some of the data are differenced.
trscode = [5 5 5 5 6 6 6 6]; 
for j = 1:8
    switch trscode(j)
        case 2
            temp = ttrs2(data(2:end,j));
            eightdata(:,j) = temp(2:end);
        case 3
            temp = ttrs3(data(2:end,j));
            eightdata(:,j) = temp;
        case 5
            temp = ttrs5(data(2:end,j));
            eightdata(:,j) = temp(2:end);
        case 6
            temp = ttrs6(data(2:end,j));
            eightdata(:,j) = temp;
        case 7
            temp = ttrs7(data(2:end,j));
            eightdata(:,j) = temp;
    end
end 
disp("Data cleaning is complete. Forecasting starts running ...")
%%% Data cleaning output: eightdata (p=1).

%% rolling, one-step forecast, set maximum number of lags MaxK=12 
maxK = 12; scheme = 1; h = 1; %% schme = 1, rolling;  = 2, recursive. 
start = 119;  %% forecasting starts at 1970:01
data = eightdata; [T, N] = size(data);
riskall= zeros(N,9); testre = zeros(N,8);
for j = 1:N
    y = data(:,j);
    p = 1;
    num = T-start-h+1;
    re = zeros(num,9);
    i = 1;
    for t = start+1:T-h+1
        if scheme == 1
            yinput = y(t-start:t-1);
        elseif scheme == 2
            yinput = y(1:t-1);
        end
		yfor = y(t+h-1);
		[frcst, frcst_maxK] = GMA_NUR(yinput,maxK,p,h); 
        re(i,1:8) = frcst-yfor;		
		re(i,9) = frcst_maxK(2)-yfor;
        i = i+1;
    end
	for ii = 1:8
	    results1 = EvalFore([re(:,9), re(:,ii)],2);
	    testre(j,ii) = [results1.DM(2)];
	end
    riskall(j,:) = [sqrt(mean(re.^2))];
end

riskall = riskall./repmat(riskall(:,9),1,9); riskall = riskall';
DM = testre';
DM(DM<=0.01)=3; sig3 = find(DM==3); length(find(DM==3));
DM(DM<=0.05)=2; sig2 = find(DM==2); length(find(DM==2));
DM(DM<=0.10)=1; sig1 = find(DM==1); length(find(DM==1));
DM(DM<1)=0;  %% transform the DM testing p-values to numbers of stars
csvwrite(strcat('Table2_h',num2str(h),'_riskandDM.csv'),[riskall(1:end-1,:); NaN(1,N); DM]);

%%% Obtain the output in a LaTex format (optional)
res = print_Texre(riskall(1:end-1,:),DM); tex_res = cell2table(res);
writetable(tex_res, strcat('Table2_h',num2str(h),'_LaTex.xls'),'WriteVariableNames',0);
