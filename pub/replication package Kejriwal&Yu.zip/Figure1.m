%  Figure1.m
%  
%  This program replicates the simulation results (Figure 1) reported in 
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%  by Mohitosh Kejriwal and Xuewen Yu. 
%  Note: The number of replications can be changed to a smaller number, say 
%   num = 5000, to get a quicker output. 

clc; clear all;
ctotal = -[0:0.2:20]';
num = 500000; n = 1000;
[~, glsre1, ~, olsre1] = simRP_GMA(num,n,ctotal);
Fm_p1 = glsre1(1:5,:)'; Ff_p1 = glsre1(6:10,:)';
olsFm_p1 = olsre1(1:5,:)'; olsFf_p1 = olsre1(6:10,:)';

subplot(2,1,1); hold on; box on;
title('In-sample AMSE','FontSize',15)
plot(ctotal,olsFm_p1(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(ctotal,olsFm_p1(:,3),':','color',[0.8,0,0.8],'LineWidth',2)
plot(ctotal,olsFm_p1(:,4),'-.','color',[0,0.6,0],'LineWidth',2)
plot(ctotal,olsFm_p1(:,5),'-*','color',[0,0,0],'MarkerSize',5)
plot(ctotal,Fm_p1(:,1),'-o','color',[0,1,1],'MarkerSize',5)
plot(ctotal,Fm_p1(:,3),'-^','color',[1,0,1],'MarkerSize',5)
plot(ctotal,Fm_p1(:,4),'-+','color',[0.6,0.6,0],'MarkerSize',5)
plot(ctotal,Fm_p1(:,5),'-','color',[0,0,1],'LineWidth',2)
h=legend('Pretest-OLS','Unres-OLS','OLS-Ave','OLS-Ave-Opt', ...
'Pretest-GLS','Unres-GLS','GLS-Ave','GLS-Ave-Opt');
h.NumColumns=2;
xlabel('c','FontSize',12);
ylabel('In-sample Risk','FontSize',12);

subplot(2,1,2); hold on; box on;
title('One-step MSFE','FontSize',15)
plot(ctotal,olsFf_p1(:,1),'--','color',[1,0,0],'LineWidth',2)
plot(ctotal,olsFf_p1(:,3),':','color',[0.8,0,0.8],'LineWidth',2)
plot(ctotal,olsFf_p1(:,4),'-.','color',[0,0.6,0],'LineWidth',2)
plot(ctotal,olsFf_p1(:,5),'-*','color',[0,0,0],'MarkerSize',5)
plot(ctotal,Ff_p1(:,1),'-o','color',[0,1,1],'MarkerSize',5)
plot(ctotal,Ff_p1(:,3),'-^','color',[1,0,1],'MarkerSize',5)
plot(ctotal,Ff_p1(:,4),'-+','color',[0.6,0.6,0],'MarkerSize',5)
plot(ctotal,Ff_p1(:,5),'-','color',[0,0,1],'LineWidth',2)
xlabel('c','FontSize',12);
ylabel('Forecast Risk','FontSize',12);

saveas(gcf,'Fig1.jpg'); saveas(gcf,'Fig1','epsc');