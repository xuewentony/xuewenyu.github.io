%  Table1.m
%  
%  This program replicates the empirical results (Table 1) reported in 
%  "Generalized Forecast Averaging in Autoregressions with a Near Unit Root",
%   by Mohitosh Kejriwal and Xuewen Yu.

clc; clear all;
%%%------- Data cleaning ------
source=importdata('FRED_MD.csv'); alldata=[source.data]; [rlen,clen]=size(alldata); alldata=[[NaN(rlen,1), alldata];NaN(1,clen+1)];
%alldata = readmatrix('FRED_MD.csv');  %for Matlab versions after R2019a
data = [alldata(1,2:end-1); alldata(14:end-7,2:end-1)];   %%%data from 1960/01-2018/12, delete the last column since VXOCLSx missing too much data
id1 = [1,2,6:18,19]; id2 = [20:47, 120:122]; id3 = [48:57]; id4 = [3:5, 58:63, 123];
id5 = [64:73, 124:127]; id6 = [78:99]; id7 = [100:119]; id8 = [74:77]; %%% total will be 127 series
id4 = [3:5, 59,61,62,63]; id6 = [78:94, 96:99];  %%% id4 drop series 58, 60, 123 and id6 drop 95 due to too much missing data, so 123 series remained.
T = length(data(:,1))-1; %%% first row stores the transformation code
N = length([id1, id2, id3, id4 ,id5, id6, id7, id8]);
ttrs1 = @(y) y; ttrs4 = @(y) log(y); %%% for p=0
ttrs2 = @(y) y; ttrs3 = @(y) diff(y); %%% for p=1
ttrs5 = @(y) log(y); ttrs6 = @(y) diff(log(y)); ttrs7 = @(y) y(2:end)./y(1:end-1)-1; %%% for p=1

id1p0 = []; id2p0 = [45 47]; id3p0 = id3; id4p0 = []; id5p0 = []; id6p0 = [87:94]; id7p0 = []; id8p0 = [];
N0 = length([id1p0, id2p0, id3p0, id4p0, id5p0, id6p0, id7p0, id8p0]);
mixtrsdata0 = zeros(T,N0);
mixidx0 = zeros(2,3); num0 = 0;
mixidx0(1,:) = [2 3 6]; ilen = length(mixidx0(1,:));
for ii = 1:ilen
    i = mixidx0(1,ii);
    idstr = strcat('id',num2str(i),'p0');
    eval(['idvec','=',idstr,';']);
    idlen = length(idvec);
    for j = 1:idlen
        num0 = num0+1;
        trscode = data(1,idvec(j));
        switch trscode
            case 1
                temp = ttrs1(data(2:end,idvec(j)));
                mixtrsdata0(:,num0) = temp;
            case 4
                temp = ttrs4(data(2:end,idvec(j)));
                mixtrsdata0(:,num0) = temp;
        end
    end
    mixidx0(2,ii) = num0;
end

id1p1 = setdiff(id1,id1p0); id2p1 = setdiff(id2,id2p0); id3p1 = setdiff(id3,id3p0); id4p1 = setdiff(id4,id4p0);
id5p1 = setdiff(id5,id5p0); id6p1 = setdiff(id6,id6p0); id7p1 = setdiff(id7,id7p0); id8p1 = setdiff(id8,id8p0);
N1 = length([id1p1, id2p1, id3p1, id4p1, id5p1, id6p1, id7p1, id8p1]);
mixtrsdata1 = zeros(T-1,N1);  %%% since some of the data are differenced.
mixidx1 = zeros(2,7); num1 = 0;
mixidx1(1,:) = [1 2 4 5 6 7 8]; ilen = length(mixidx1(1,:));
for ii = 1:ilen
    i = mixidx1(1,ii);
    idstr = strcat('id',num2str(i),'p1');
    eval(['idvec','=',idstr,';']);
    idlen = length(idvec);
    for j = 1:idlen
        num1 = num1+1;
        trscode = data(1,idvec(j));
        switch trscode
            case 2
                temp = ttrs2(data(2:end,idvec(j)));
                mixtrsdata1(:,num1) = temp(2:end);
            case 3
                temp = ttrs3(data(2:end,idvec(j)));
                mixtrsdata1(:,num1) = temp;
            case 5
                temp = ttrs5(data(2:end,idvec(j)));
                mixtrsdata1(:,num1) = temp(2:end);
            case 6
                temp = ttrs6(data(2:end,idvec(j)));
                mixtrsdata1(:,num1) = temp;
            case 7
                temp = ttrs7(data(2:end,idvec(j)));
                mixtrsdata1(:,num1) = temp;
        end
    end
    mixidx1(2,ii) = num1;
end
disp("Data cleaning is complete. Forecasting starts running ...")
%%% Data cleaning output: mixtrsdata0 (p=0); mixtrsdata1 (p=1).

%%%------- Forecasting ------
%% rolling, one-step forecast, set maximum number of lags MaxK=12 
maxK = 12; scheme = 1; h = 1; %% schme = 1, rolling;  = 2, recursive.
mixtrsdata = [mixtrsdata0(2:end,:), mixtrsdata1];  %% the first data starts at 1960:02
[T0, N0] = size(mixtrsdata0); [T1, N1] = size(mixtrsdata1);
start = 119;  %% forecasting starts at 1970:01
riskall_0 = zeros(N0,8); 
for j = 1:N0   
    y = mixtrsdata0(2:end,j);
    N = length(y)-h+1;
    p = 0;
    num = N-start;
    re = zeros(num,8);
    i = 1;
    for t = start+1:N        
        if scheme == 1
            yinput = y(t-start:t-1);
        elseif scheme == 2
            yinput = y(1:t-1);
        end
        yfor = y(t+h-1);
        [frcst] = GMA_NUR(yinput,maxK,p,h);
        re(i,:) = frcst-yfor;
        i = i+1;        
    end
    riskall_0(j,:) = [sqrt(mean(re.^2))];
end

riskall_1 = zeros(N1,8); 
for j = 1:N1    
    y = mixtrsdata1(:,j);
    N = length(y)-h+1;
    p = 1;
    num = N-start;
    re = zeros(num,8);
    i = 1;
    for t = start+1:N        
        if scheme == 1
            yinput = y(t-start:t-1);
        elseif scheme == 2
            yinput = y(1:t-1);
        end 
        yfor = y(t+h-1);
        [frcst] = GMA_NUR(yinput,maxK,p,h);
        re(i,:) = frcst-yfor;
        i = i+1;        
    end
    riskall_1(j,:) = [sqrt(mean(re.^2))];
end

riskall = [riskall_0; riskall_1];
cpmat = zeros(9,9);
for i = 1:8
    for j = i+1:9
        if j ~= 9
            cpmat(i,j) = mean(riskall(:,i) < riskall(:,j));
            cpmat(j,i) = 1-cpmat(i,j);
        else
            riskleft = riskall;
            riskleft(:,i) = [];
            riskbest = [min(riskleft')]';
            cpmat(i,9) = mean(riskall(:,i) < riskbest);
        end
    end
end
%% store the output
csvwrite(strcat('Table1_h',num2str(h),'_riskmat.csv'),cpmat(1:end-1,:));

