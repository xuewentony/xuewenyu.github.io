% This function transforms the outputs in Table 2, C2 and C4 to
% LaTex version outputs.

function re = print_Texre(risk, DM)

risk = round(risk,3);
[m, N] = size(risk); minset = [];
for j = 1:N
    colmin = find(risk(:,j)==min(risk(:,j)));
    for jj = 1:length(colmin)
        minset = [minset; [colmin(jj), j]];
    end
end
minset;
re = [];
for i = 1:m
    strtemp = [];
    for j = 1:N
        num = risk(i,j);
        tempnum = num2str(num,'%.3f');
        if num <1
            tempnum(1) = [];
        end
        
        star = DM(i,j); word = '';
        if star == 1 word = '\oneS';
        elseif star == 2 word = '\twoS';
        elseif star == 3 word = '\threeS';
        end
        
        if ismember(i,minset(find(j == minset(:,2)),1))
            re_str = strcat('\textbf{',tempnum,'}',word,' ');
        else
            re_str = strcat(tempnum,word,' ');
        end
        strtemp = [strtemp, split(re_str)];
    end
    re = [re; strtemp];
end

end




