% This function conducts the Cavaliere and Taylor (2008b) ratio-based tests 
% of persistence change as a comparison reported in column 7 of table 1.

function [stat_output_CTasym, pvalue_output_CT] = CT_test(y);

brep = 400;
T = size(y,1)-1;
[kappa1_value,kappa1prime_value,kappa4_value] = CTstatistics_compute(y);
stat_output_CTasym = [kappa1_value,kappa1prime_value,kappa4_value];
threestatboot_output = zeros(brep,3);
for n = 1:brep
    error = y-mean(y);
    tprand = randn(length(error),1);
    omegaCT = tprand;
    epsbootCT = error.*omegaCT;
    yboot = epsbootCT;
    [kappa1_boot_value, kappa1prime_boot_value, kappa4_boot_value] = CTstatistics_compute(yboot);
    threestatboot_output(n,:) = [kappa1_boot_value, kappa1prime_boot_value, kappa4_boot_value];
end;
sort_threestatboot_output = sort(threestatboot_output);
pvalue_K1 = length(find(sort_threestatboot_output(:,1) >= kappa1_value))/brep;
pvalue_K1prime = length(find(sort_threestatboot_output(:,2) >= kappa1prime_value))/brep;
pvalue_K4 = length(find(sort_threestatboot_output(:,3) >= kappa4_value))/brep;
pvalue_output_CT = [pvalue_K1, pvalue_K1prime, pvalue_K4];

end

%%% --- Below are some functions built in the main function CT_test.m ---
function [kappa1,kappa1prime,kappa4] = CTstatistics_compute(y);

T = length(y); x = ones(T,1);
tau_low = 0.15; tau_high = 0.85;
s = floor(tau_low*T):floor(tau_high*T);
kappa1_total = zeros(length(s),1);
for t = 1:length(s)
    kappa1_total(t) = CTkappa_compute(s(t)/T,y,x);
end
kappa1 = max(kappa1_total);
kappa1prime = max(ones(length(s),1)./kappa1_total);
kappa4 = max(kappa1,kappa1prime);
end

function kappa_value = CTkappa_compute(tau,y,x);

T = length(y); tauT = floor(tau*T);
y1 = y(1:tauT); y2 = y(tauT+1:T);
x1 = x(1:tauT); x2 = x(tauT+1:T);        
bhat1 = inv(x1'*x1)*(x1'*y1); err1 = y1-x1*bhat1;
bhat2 = inv(x2'*x2)*(x2'*y2); err2 = y2-x2*bhat2;
partsumsq1 = 0; partsumsq2 = 0;
for t1 = 1:tauT partsumsq1 = partsumsq1+(sum(err1(1:t1)))^2; end
for t2 = 1:T-tauT partsumsq2 = partsumsq2+(sum(err2(1:t2)))^2; end
kappa_value = (((T-tauT)^-2)*partsumsq2)/((tauT^-2)*partsumsq1);
end