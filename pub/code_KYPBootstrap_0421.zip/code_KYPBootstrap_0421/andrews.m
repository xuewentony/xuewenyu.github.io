% This function conducts the Andrews and Guggenberger (2014) robust interval estimation 
% of persistence reported in table 1 and 2 in the paper.

function [CIlow CIup] = andrews(rhohat,robvarcov,T,gridp,range)

AG_CV = [-2.87	-2.83	-2.79	-2.76	-2.73	-2.7 ...
-2.65	-2.61	-2.57	-2.54	-2.51	-2.48 ...
-2.46	-2.44	-2.42	-2.39	-2.35   -2.32 ...	
-2.29	-2.26	-2.23	-2.21	-2.19	-2.18 ...	
-2.16	-2.14	-2.09	-2.05	-2.01	-1.97 ...	
-1.93	-1.91	-1.89	-1.87	-1.86	-1.85	-1.79	-1.76	-1.74;
-0.07	-0.02	0.04	0.08	0.13	0.17 ...	
0.25	0.31	0.37	0.43	0.48	0.52 ...	
0.57	0.61	0.64	0.68	0.75	0.81 ...	
0.87	0.91	0.95	0.98	1.01	1.03 ...	
1.05	1.08	1.15	1.2	    1.24	1.3 ...	
1.34	1.36	1.39	1.4	    1.42	1.43	1.49	1.52	1.55]'; %%from AG14 paper
cvl = AG_CV(:,1); cvu = AG_CV(:,2);

rhostd = sqrt(robvarcov);
rhogrid = [rhohat-range*rhostd:2*range*rhostd/(gridp-1):rhohat+range*rhostd]';
hgrid = T*(1-rhogrid);
hspace = [0 .2 .4 .6 .8 1 1.4 1.8 2.2 2.6 3 3.4 3.8 ...
    4.2 4.6 5 6 7 8 9 10 11 12 13 14 15 ...
    20 25 30 40 50 60 70 80 90 100 200 300 500]';
ql = interp(hspace,cvl,hgrid); qu = interp(hspace,cvu,hgrid);
ta = (rhohat - rhogrid)/rhostd;
 
quantile = [ql, qu];
[CIlow CIup]=g_ends(rhogrid,ta,quantile);
end

%%% --- Below are some functions built in the main function andrews.m ---
function re = interp(h,qt,d);
T = length(h); len = length(d); re = zeros(len,1);
for i = 1:len
    p = d(i); ind = find(h > p);
    if ~isempty(ind)
        if ~(length(ind) == T)
            loc = ind(1)-1; hl = h(loc); ql = qt(loc);
            hu = h(loc+1); qu = qt(loc+1);
            re(i) = (p-hl)*(qu-ql)/(hu-hl)+ql;
        else
            re(i) = qt(1);
        end
    else
        re(i) = qt(end);
    end
end
end

function [l,u]=g_ends(a0,ta,grid);
[l1,l2]=cross(a0,ta,grid(:,1));
[u1,u2]=cross(a0,ta,grid(:,2));
is=sortrows([l1;l2;u1;u2],1);
if length(is(1,:))>1
   iis=isnan(sum(is')');
else
   iis=isnan(is);
end
ind=0;
for i=1:length(iis)
    if iis(i)==0;
        if ind==0
            s=is(i);
            ind=1;
        else
            s=[s;is(i)];
        end
    end
end
l=min(s);
u=max(s);
if l==min(u2) l=min(a0);end;
if l==min(l1) l=min(a0);end;
if u==max(l2) u=max(a0);end;
if u==max(u1) u=max(a0);end;
end


function [g1,g2]=cross(a,x,y);
ms=NaN; rn=length(a(:,1));
r=(x<y); d=[0;(r(2:rn)-r(1:rn-1))];
s=(1:rn)'; ind=0; id=(d==1);
for i=1:length(id)
    if id(i)==1
        if ind==0
            li=s(i); ind=1;
        else
            li=[li;s(i)];
        end
    end
end
if min(id==0) li=NaN; end
if 1-(isnan(sum(li)))             
    al=a(li-1); au=a(li);
    bl=x(li-1)-y(li-1); bu=y(li)-x(li);
    g1=(bu.*al+bl.*au)./(bl+bu);
else
    g1=ms;
end

ind=0; id=(d==-1);
for i=1:length(id)
    if id(i)==1
        if ind==0
            li=s(i); ind=1;
        else
            li=[li;s(i)];
        end
    end
end
if min(id==0) li=NaN; end        
if 1-(isnan(sum(li)))
    al=a(li-1); au=a(li);
    bl=y(li-1)-x(li-1); bu=x(li)-y(li);
    g2=(bu.*al+bl.*au)./(bl+bu);
else
    g2=ms;
end
end