% This function stores the regression errors after model selection. 
% This function is very similiar to robesti_regime.m, except we focus on storing 
% error terms conditional on the selected model.

function [errall, lagsall] = err_aftersel(y,estdate,optlag,model,regimemodel,waldresult)

m = length(estdate); lagsmax = 12; gridp = 200; range = 5;
if waldresult == 0     %%%% pure mean shifts
    
    datevec = [0; estdate; length(y)]; ydm = zeros(length(y),1);
    for i = 1:m+1
        ydm(datevec(i)+1:datevec(i+1)) = y(datevec(i)+1:datevec(i+1)) - mean(y(datevec(i)+1:datevec(i+1)));
    end
    bigt = length(y)-1; c = ones(bigt,1);
    yyf = ydm(2:bigt+1,1); yyb = ydm(1:bigt,1);
    lags = optlag; zbar0 = c; zbar0 = zbar0(lags+1:bigt,:);
    if lags == 0
        wbar0 = [zbar0, yyb(lags+1:bigt)];
    else
        delyyflag = zeros(bigt-lags,lags);
        for f= 1:lags
            delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
        end
        wbar0 = [zbar0, yyb(lags+1:bigt), delyyflag];
    end
    alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:); Larsum = alphahat0(2);
    errall = yyf(lags+1:bigt,:)-wbar0*alphahat0; lagsall = lags;
    
elseif isnan(waldresult)        %%%% no break case
    
    if model == 0
        bigt = length(y)-1; c = ones(bigt,1);n = bigt+1; 
		yyf = y(2:n,1); yyb = y(1:n-1,1); ssr0 = zeros(lagsmax+1,1);
        bic0 = zeros(lagsmax+1,1); zbar0 = c; zbar0 = zbar0(lagsmax+1:bigt,:);
        for lags = 0:lagsmax
            if lags == 0
                wbar0 = [zbar0, yyb(lagsmax+1:bigt)];
            else
                delyyflag = zeros(bigt-lagsmax,lags);
                for f = 1:lags
                    delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
                end
                wbar0 = [zbar0, yyb(lagsmax+1:bigt), delyyflag];
            end
            alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lagsmax+1:bigt,:);
            ssr0(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyf(lagsmax+1:bigt,:)-wbar0*alphahat0);
            bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
        end
        [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
        
        lags = bic0lags;
        if lags == 0
            wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt)];
        else
            delyyflag = zeros(bigt-lags,lags);
            for f= 1:lags
                delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
            end
            wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt), delyyflag];
        end
        alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:);
        errall = yyf(lags+1:bigt,:)-wbar0*alphahat0; lagsall = lags;
    elseif model == 1
        bigt = length(y)-1; c = ones(bigt,1); n = bigt+1;
        yyf = y(2:n,1); yyb = y(1:n-1,1); yyfd = yyf-yyb;
        ssr0 = zeros(lagsmax+1,1); bic0 = zeros(lagsmax+1,1);
        for lags = 0:lagsmax
            if lags == 0
                wbar0 = 0;
                alphahat0 = 0;
            else
                delyyflag = zeros(bigt-lagsmax,lags);
                for f = 1:lags
                    delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
                end
                wbar0 = [delyyflag];
                alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyfd(lagsmax+1:bigt,:);
            end
            
            ssr0(lags+1,1) = (yyfd(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyfd(lagsmax+1:bigt,:)-wbar0*alphahat0);
            bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
        end
        [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
        
        lags = bic0lags;
        if lags == 0
            err = yyfd(1:bigt,:); lagsall = lags;
        else
            delyyflag = zeros(bigt-lags,lags);
            for f= 1:lags
                delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
            end
            wbar0 = [delyyflag]; alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyfd(lags+1:bigt,:);
            errall = yyfd(lags+1:bigt,:)-wbar0*alphahat0; lagsall = lags;
        end
    end
    
elseif waldresult == 1        %%%% persistence break case
    
    errall = []; lagsall = [];
    datevec = [0; estdate; length(y)]; yregime = zeros(length(y),1);
    for i = 1:m+1
        model = regimemodel(i);
        if model == 0
            yregime = y(datevec(i)+1:datevec(i+1)); bigt = length(yregime)-1;
            n = bigt+1; c = ones(bigt,1);
            yyf = yregime(2:n,1); yyb = yregime(1:n-1,1);
            ssr0 = zeros(lagsmax+1,1); bic0 = zeros(lagsmax+1,1);
            zbar0 = c; zbar0 = zbar0(lagsmax+1:bigt,:);
            for lags = 0:lagsmax
                if lags == 0
                    wbar0 = [zbar0, yyb(lagsmax+1:bigt)];
                else
                    delyyflag = zeros(bigt-lagsmax,lags);
                    for f= 1:lags
                        delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
                    end
                    wbar0 = [zbar0, yyb(lagsmax+1:bigt), delyyflag];
                end
                alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lagsmax+1:bigt,:);
                ssr0(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyf(lagsmax+1:bigt,:)-wbar0*alphahat0);
                bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
            end
            [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
            
            lags = bic0lags;
            if lags == 0
                wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt)];
            else
                delyyflag = zeros(bigt-lags,lags);
                for f= 1:lags
                    delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
                end
                wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt), delyyflag];
            end
            alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:);
            erri = yyf(lags+1:bigt,:)-wbar0*alphahat0;
            
            if i ~= 1
                if lags == 0
                    backreg = [1, y(datevec(i))];
                    lasterr = y(datevec(i)+1) - backreg*alphahat0;
                    erri = [lasterr;erri];
                else
                    for jj = 1:lags+1
                        backreg = [1, y(datevec(i)+1-jj)];
                        for f = 1:lags
                            addone = y(datevec(i)+1-jj-f+1)-y(datevec(i)-jj-f+1);
                            backreg = [backreg, addone];
                        end
                        lasterr = y(datevec(i)+1-jj+1) - backreg*alphahat0;
                        erri = [lasterr;erri];
                    end
                end
            end
			errall = [errall;erri]; lagsall = [lagsall;lags];
            
        elseif model == 1
            yregime = y(datevec(i)+1:datevec(i+1)); bigt = length(yregime)-1;
            n = bigt+1; c = ones(bigt,1);
            yyf = yregime(2:n,1); yyb = yregime(1:n-1,1);
            yyfd = yyf-yyb; ssr0 = zeros(lagsmax+1,1); bic0 = zeros(lagsmax+1,1);
            for lags = 0:lagsmax
                if lags == 0
                    wbar0 = 0;
                    alphahat0 = 0;
                else
                    delyyflag = zeros(bigt-lagsmax,lags);
                    for f= 1:lags
                        delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
                    end
                    wbar0 = [delyyflag];
                    alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyfd(lagsmax+1:bigt,:);
                end
                ssr0(lags+1,1) = (yyfd(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyfd(lagsmax+1:bigt,:)-wbar0*alphahat0);
                bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
            end
            [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
            
            lags = bic0lags;
            if lags == 0
                erri = yyfd(1:bigt,:); lagsall = lags;
                if i ~= 1
                    lasterr = y(datevec(i)+1) - y(datevec(i));
                    erri = [lasterr;erri];
                end
            else
                delyyflag = zeros(bigt-lags,lags);
                for f = 1:lags
                    delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
                end
                wbar0 = [delyyflag]; alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyfd(lags+1:bigt,:);
                erri = yyfd(lags+1:bigt,:)-wbar0*alphahat0;
                
                if i ~= 1
                    for jj = 1:lags+1
                        backreg = [];
                        for f = 1:lags
                            addone = y(datevec(i)+1-jj-f+1)-y(datevec(i)-jj-f+1);
                            backreg = [backreg, addone];
                        end
                        lasterr = y(datevec(i)+1-jj+1) - y(datevec(i)+1-jj)- backreg*alphahat0;
                        erri = [lasterr;erri];
                    end
                end
            end
			errall = [errall;erri]; lagsall = [lagsall;lags];
        end
    end
end





