% This function conducts mean shift robust wald test.

function [result, waldresult, lag, CV] = robtest_levshift(y,brnum,estdate)

trm = 0.15; waldCV = chi2inv(0.9,1:5); bigt = length(y)-1;
if brnum ~= 0
    datevecest = estdate - 1;    % minus 1 to match the subsequent analysis
    [robwald0,wald0,wald0_alt,alphahat0return,lag] = roblevshift_cal(y,brnum,datevecest,bigt,trm);
    result = [robwald0,wald0,wald0_alt,alphahat0return,lag];
    %disp('The Wald test statistic for this model is:');
    %disp(robwald0);
    CV = waldCV(brnum);
    %disp('The critical value of Wald test for this model is:');
    %disp(CV);
    waldresult = (robwald0 >= CV);
else
    result = NaN(1,5); waldresult = NaN; lag = NaN; CV = NaN;
end
%if isnan(waldresult)
%    disp('No, there is no pure mean shift. Since no breaks is obtained from previous procedure.');
%elseif waldresult == 1
%    disp('No, there are persistence changes. Wald test is rejected.');
%elseif waldresult == 0
%	disp('Yes, there is pure mean shift. Wald test is not rejected.');
%end
end

%%% --- Below are some functions built in the main function robtest_levshift.m ---
function [robwald0,wald0,wald0_alt,alphahat0return,bic0lags] = roblevshift_cal(y,m,datevecest,bigt,trm)

n = bigt+1; c = ones(bigt,1);
yyf = y(2:n,1); yyb = y(1:n-1,1); x = [c, yyb]; 
lagsmax = 12; ssr0 = zeros(lagsmax+1,1); ssr1 = zeros(lagsmax+1,1);
bic0 = zeros(lagsmax+1,1);
for lags = 0:lagsmax
    zbar0 = pzbar(c,m,datevecest); zbar0 = zbar0(lagsmax+1:bigt,:);
    zbar1 = pzbar([c,yyb],m,datevecest); zbar1 = zbar1(lagsmax+1:bigt,:);
    if lags == 0
        wbar0 = [zbar0, yyb(lagsmax+1:bigt)]; wbar1 = zbar1;
    else
        delyyflag = zeros(bigt-lagsmax,lags);
        for f= 1:lags
            delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
        end
        wbar0 = [zbar0, yyb(lagsmax+1:bigt), delyyflag]; wbar1 = [zbar1, delyyflag];
    end
    alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lagsmax+1:bigt,:);
    alphahat1 = inv(wbar1'*wbar1)*wbar1'*yyf(lagsmax+1:bigt,:);
    ssr0(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyf(lagsmax+1:bigt,:)-wbar0*alphahat0);
    ssr1(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar1*alphahat1)'*(yyf(lagsmax+1:bigt,:)-wbar1*alphahat1);
    bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
end
[~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;

zbar0 = pzbar(c,m,datevecest); zbar0 = zbar0(bic0lags+1:bigt,:);
zbar1 = pzbar([c, yyb],m,datevecest); zbar1 = zbar1(bic0lags+1:bigt,:);
if bic0lags == 0
    wbar0 = [zbar0, yyb(bic0lags+1:bigt)]; wbar1 = zbar1;
else
    delyyflag = zeros(bigt-bic0lags,bic0lags);
    for f = 1:bic0lags
        delyyflag(:,f) = yyb(bic0lags+1-f+1:bigt-f+1,1)-yyb(bic0lags+1-f:bigt-f,1);
    end
    wbar0 = [zbar0, yyb(bic0lags+1:bigt), delyyflag]; wbar1 = [zbar1, delyyflag];
end
alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(bic0lags+1:bigt,:);
alphahat1 = inv(wbar1'*wbar1)*wbar1'*yyf(bic0lags+1:bigt,:);
ssr0 = (yyf(bic0lags+1:bigt,:)-wbar0*alphahat0)'*(yyf(bic0lags+1:bigt,:)-wbar0*alphahat0);
ssr1 = (yyf(bic0lags+1:bigt,:)-wbar1*alphahat1)'*(yyf(bic0lags+1:bigt,:)-wbar1*alphahat1);
wald0 = (bigt-2*(m+1)-bic0lags)*(ssr0-ssr1)/ssr1;
alphahat0return = alphahat0(m+2,1);

err = yyf(bic0lags+1:bigt,:)-wbar1*alphahat1; sig = err'*err/(bigt-2*(m+1)-bic0lags);
varb = inv(wbar1'*wbar1)*sig;
robvarb = inv(wbar1'*wbar1)*wbar1'*(diag(err.*err))*wbar1*inv(wbar1'*wbar1);
tmp1 = zeros(m,2*m);
for i = 1:m
    tmp1(i,2*i) = 1;
end
R = [tmp1,zeros(m,1),-ones(m,1), zeros(m,bic0lags)]; beta = alphahat1;
r = zeros(m,1); wald0_alt = (R*beta-r)'*inv(R*varb*R')*(R*beta-r);
robwald0 = (R*beta-r)'*inv(R*robvarb*R')*(R*beta-r);
end

function zb=pzbar(zz,m,bb)
% procedure to construct the diagonal partition of z with m break at date b.
[nt,q1]=size(zz);

zb=zeros(nt,(m+1)*q1);
zb(1:bb(1,1),1:q1)=zz(1:bb(1,1),:);
i=2;
while i <= m
    zb(bb(i-1,1)+1:bb(i,1),(i-1)*q1+1:i*q1)=zz(bb(i-1,1)+1:bb(i,1),:);
    i=i+1;
end
zb(bb(m,1)+1:nt,m*q1+1:(m+1)*q1)=zz(bb(m,1)+1:nt,:);
end
