% This function conducts the model estimation after mean shift test.

function [re1, re2, re3, re4, model, regimemodel] = robesti_regime(y,estdate,optlag,waldresult)

m = length(estdate); lagsmax = 12;
gridp = 200; range = 5;

if waldresult == 0     %%%% pure mean shifts
    
    datevec = [0; estdate; length(y)]; ydm = zeros(length(y),1);
    for i = 1:m+1
        ydm(datevec(i)+1:datevec(i+1)) = y(datevec(i)+1:datevec(i+1)) - mean(y(datevec(i)+1:datevec(i+1)));
    end
    bigt = length(y)-1; c = ones(bigt,1);
    yyf = ydm(2:bigt+1,1); yyb = ydm(1:bigt,1);
    lags = optlag; zbar0 = c;
    zbar0 = zbar0(lags+1:bigt,:);
    if lags == 0
        wbar0 = [zbar0, yyb(lags+1:bigt)];
    else
        delyyflag = zeros(bigt-lags,lags);
        for f= 1:lags
            delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
        end
        wbar0 = [zbar0, yyb(lags+1:bigt), delyyflag];
    end
    alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:); Larsum = alphahat0(2);
    err = yyf(lags+1:bigt,:)-wbar0*alphahat0;
    
    var = inv(wbar0'*wbar0)*(err'*err)/(bigt-2-lags); std = sqrt(var(2,2));
    robvar = inv(wbar0'*wbar0)*wbar0'*(diag(err.*err))*wbar0*inv(wbar0'*wbar0);
    robstd = sqrt(robvar(2,2));
    
    ci_low = Larsum-1.646*std; ci_up = Larsum+1.646*std;
    robci_low = Larsum-1.646*robstd; robci_up = Larsum+1.646*robstd;
    
    [beta resid varcov robvarcov0 robvarcov5] = ols(yyf(lags+1:bigt,:),wbar0);
    rhohat = beta(2); T = length(yyf(lags+1:bigt,:));
    [CIlow5 CIup5] = andrews(rhohat,robvarcov5(2,2),T,gridp,range);
    [CIlow0 CIup0] = andrews(rhohat,robvarcov0(2,2),T,gridp,range);
    [~, ~, ur1,kur1,beta1,sebeta1] = URtest(ydm,lags,1);
	[~, ~, ur2,kur2,beta2,sebeta2] = URtest(ydm,lags,2);

    re1 = [Larsum std robstd sqrt(robvarcov5(2,2)) sqrt(robvarcov0(2,2)) lags];
    re2 = [ci_low ci_up robci_low robci_up];
    re3 = [CIlow5 CIup5 CIlow0 CIup0];
	re4 = [ur1 kur1 beta1 sebeta1 ur2 kur2 beta2 sebeta2];
    model = []; regimemodel = [];
    
elseif isnan(waldresult)        %%%% no break case
    
    bigt = length(y)-1; c = ones(bigt,1);
    n = bigt+1; yyf = y(2:n,1);
    yyb = y(1:n-1,1); ssr0 = zeros(lagsmax+1,1);
    bic0 = zeros(lagsmax+1,1); zbar0 = c;
    zbar0 = zbar0(lagsmax+1:bigt,:);
    for lags = 0:lagsmax
        if lags == 0
            wbar0 = [zbar0, yyb(lagsmax+1:bigt)];
        else
            delyyflag = zeros(bigt-lagsmax,lags);
            for f = 1:lags
                delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
            end
            wbar0 = [zbar0, yyb(lagsmax+1:bigt), delyyflag];
        end
        alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lagsmax+1:bigt,:);
        ssr0(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyf(lagsmax+1:bigt,:)-wbar0*alphahat0);
        bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
    end
    [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
    
    lags = bic0lags;
    if lags == 0
        wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt)];
    else
        delyyflag = zeros(bigt-lags,lags);
        for f= 1:lags
            delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
        end
        wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt), delyyflag];
    end
    alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:);
    Larsum = alphahat0(2); err = yyf(lags+1:bigt,:)-wbar0*alphahat0;
    
    var = inv(wbar0'*wbar0)*(err'*err)/(bigt-m-2-lags); std = sqrt(var(2,2));
    robvar = inv(wbar0'*wbar0)*wbar0'*(diag(err.*err))*wbar0*inv(wbar0'*wbar0);
    robstd = sqrt(robvar(2,2));
    
    ci_low = Larsum-1.646*std; ci_up = Larsum+1.646*std;
    robci_low = Larsum-1.646*robstd; robci_up = Larsum+1.646*robstd;
    
    [beta resid varcov robvarcov0 robvarcov5] = ols(yyf(lags+1:bigt,:),wbar0);
    rhohat = beta(2);
    T = length(yyf(lags+1:bigt,:));
    [CIlow5 CIup5] = andrews(rhohat,robvarcov5(2,2),T,gridp,range);
    [CIlow0 CIup0] = andrews(rhohat,robvarcov0(2,2),T,gridp,range);
    [~, ~, ur1,kur1,beta1,sebeta1] = URtest(y,lags,1);
	[~, ~, ur2,kur2,beta2,sebeta2] = URtest(y,lags,2);
	
    re1 = [Larsum std robstd sqrt(robvarcov5(2,2)) sqrt(robvarcov0(2,2)) lags];
    re2 = [ci_low ci_up robci_low robci_up];
    re3 = [CIlow5 CIup5 CIlow0 CIup0];
	re4 = [ur1 kur1 beta1 sebeta1 ur2 kur2 beta2 sebeta2];
    if (CIlow5 <= 1 && CIup5 >= 1) 
        model = 1;
    else
        model = 0;
    end
    regimemodel = [];
    
elseif waldresult == 1        %%%% persistence break case
    
    re1all= []; re2all = [];
    re3all = []; re4all = [];
    model = []; regimemodel = [];
    datevec = [0; estdate; length(y)];
    for i = 1:m+1
        yregime = y(datevec(i)+1:datevec(i+1)); bigt = length(yregime)-1;
        n = bigt+1; c = ones(bigt,1);
        yyf = yregime(2:n,1); yyb = yregime(1:n-1,1);
        ssr0 = zeros(lagsmax+1,1); bic0 = zeros(lagsmax+1,1);
        zbar0 = c; zbar0 = zbar0(lagsmax+1:bigt,:);
        for lags = 0:lagsmax
            if lags == 0
                wbar0 = [zbar0, yyb(lagsmax+1:bigt)];
            else
                delyyflag = zeros(bigt-lagsmax,lags);
                for f= 1:lags
                    delyyflag(:,f) = yyb(lagsmax+1-f+1:bigt-f+1,1)-yyb(lagsmax+1-f:bigt-f,1);
                end
                wbar0 = [zbar0, yyb(lagsmax+1:bigt), delyyflag];
            end
            alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lagsmax+1:bigt,:);
            ssr0(lags+1,1) = (yyf(lagsmax+1:bigt,:)-wbar0*alphahat0)'*(yyf(lagsmax+1:bigt,:)-wbar0*alphahat0);
            bic0(lags+1,1) = log((ssr0(lags+1,1))/(bigt-lagsmax))+lags*log(bigt-lagsmax)/(bigt-lagsmax);
        end
        [~, minbic0loc] = min(bic0); bic0lags = minbic0loc-1;
        
        lags = bic0lags;
        if lags == 0
            wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt)];
        else
            delyyflag = zeros(bigt-lags,lags);
            for f= 1:lags
                delyyflag(:,f) = yyb(lags+1-f+1:bigt-f+1,1)-yyb(lags+1-f:bigt-f,1);
            end
            wbar0 = [ones(bigt-lags,1), yyb(lags+1:bigt), delyyflag];
        end
        alphahat0 = inv(wbar0'*wbar0)*wbar0'*yyf(lags+1:bigt,:); arsum = alphahat0(2);
        err = yyf(lags+1:bigt,:)-wbar0*alphahat0;       
        var = inv(wbar0'*wbar0)*(err'*err)/(bigt-m-2-lags); std = sqrt(var(2,2));
        robvar = inv(wbar0'*wbar0)*wbar0'*(diag(err.*err))*wbar0*inv(wbar0'*wbar0);
        robstd = sqrt(robvar(2,2));        
        ci_low = arsum-1.646*std; ci_up = arsum+1.646*std;
        robci_low = arsum-1.646*robstd; robci_up = arsum+1.646*robstd;        
        [beta resid varcov robvarcov0 robvarcov5] = ols(yyf(lags+1:bigt,:),wbar0);
        rhohat = beta(2); T = length(yyf(lags+1:bigt,:));
        [CIlow5 CIup5] = andrews(rhohat,robvarcov5(2,2),T,gridp,range);
        [CIlow0 CIup0] = andrews(rhohat,robvarcov0(2,2),T,gridp,range);
        [~, ~, ur1,kur1,beta1,sebeta1] = URtest(yregime,lags,1);
	    [~, ~, ur2,kur2,beta2,sebeta2] = URtest(yregime,lags,2);
		
        re1temp = [arsum std robstd sqrt(robvarcov5(2,2)) sqrt(robvarcov0(2,2)) lags];
        re2temp = [ci_low ci_up robci_low robci_up]; re3temp = [CIlow5 CIup5 CIlow0 CIup0];
		re4temp = [ur1 kur1 beta1 sebeta1 ur2 kur2 beta2 sebeta2];
        re1all = [re1all; re1temp]; re2all = [re2all; re2temp];
        re3all = [re3all; re3temp]; re4all = [re4all; re4temp];
        if (CIlow5 <= 1 && CIup5 >= 1) 
            eachmodel = 1;
        else
            eachmodel = 0;
        end
        regimemodel = [regimemodel; eachmodel];
    end
    [Larsum, maxloc] = max(re1all(:,1));
    re1 = re1all(maxloc,:); re2 = re2all(maxloc,:);
    re3 = re3all(maxloc,:); re4 = re4all(maxloc,:);
end

end



