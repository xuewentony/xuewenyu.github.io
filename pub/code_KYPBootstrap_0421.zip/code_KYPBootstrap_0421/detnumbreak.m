% This function conducts our determining no. of breaks procedure.
% Note this function contains many bulit-in (sub-)functions as we merge 
% all of them into one file to make it clear to view.

function [realb tmpnt pvall] = detnumbreak(y,mb,eps,eta,BICmaxlag,brep)

index = [1:5];
etaall = 1-(1-eta).^(1./index);

tmpnt = NaN(5,5);
pvall = NaN(6,6);

[optlag] = LagDatesel(y,[],BICmaxlag,eps,0);
[hi cvw pvh] = H(y,mb,eps,eta,optlag,BICmaxlag,brep,'m');
pvall(1,1:1) = [pvh];
if pvh > etaall(1)
    realb = 0;
else    
    for i = 1:5
	    [optlag, datevec] = LagDatesel(y,i,BICmaxlag,eps,1);
        thisdate = [datevec(i,:)]';
        thisdate = thisdate + BICmaxlag + 1;
        tmpnt(i,1:i) = thisdate;
        extdate = [0; thisdate; length(y)];
        for j = 1:i+1        		
            [hi1 cvw1 pvh1] = H(y(extdate(j)+1:extdate(j+1)),mb,eps,eta,optlag,BICmaxlag,brep,'1');            
            pvall(i+1,j) = pvh1;
        end
        pvall(i+1,:);
        if (min(pvall(i+1,1:i+1)) > etaall(i))
            realb = i;
            break;
        end
        
    end
    if i == 5
	    realb = 5;
	end
end
end



%%% --- Below are some functions built in the main function detnumbreak.m ---
function [optlag, datevec] = LagDatesel(y,m,BICmaxlag,eps,type);

T = length(y)-1;
h = round(eps*T);
dy = diff(y);
SSR0total = zeros(BICmaxlag+1,1);
SSR0total_0 = zeros(BICmaxlag+1,1);
SSR0total_1 = zeros(BICmaxlag+1,1);
BICvalue = zeros(BICmaxlag+1,1);
BICvalue_0 = zeros(BICmaxlag+1,1);
BICvalue_1 = zeros(BICmaxlag+1,1);

if type == 0
    
	depvar = dy(BICmaxlag+1:T);
    regs = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
	SSR0total_0(1) = sum((depvar-regs*inv(regs'*regs)*regs'*depvar).^2);
    BICvalue_0(1) = log(SSR0total_0(1)/(length(depvar)));
    for k = 1:BICmaxlag
        regs_lag = zeros(T-BICmaxlag,k);
        regs_consy = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
        for i=1:k
            regs_lag(:,i) = dy(BICmaxlag-i+1:T-i);
        end
        regs = [regs_consy regs_lag];
        SSR0total_0(k+1) = sum((depvar-regs*inv(regs'*regs)*regs'*depvar).^2);
        BICvalue_0(k+1) = log(SSR0total_0(k+1)/(length(depvar)))+(k)*log(length(depvar))/length(depvar);
    end
    [minBIC_0, minBICloc_0] = min(BICvalue_0);
    optlag_0 = minBICloc_0 - 1;
	SSR0_0 = SSR0total_0(minBICloc_0);
   	
	depvar = dy(BICmaxlag+1:T);
    regs = [ones(T-BICmaxlag,1)];
	SSR0total_1(1) = sum((depvar).^2);
    BICvalue_1(1) = log(SSR0total_1(1)/(length(depvar)));
    for k = 1:BICmaxlag
        regs_lag = zeros(T-BICmaxlag,k);
        regs_cons = [ones(T-BICmaxlag,1)];
        for i=1:k
            regs_lag(:,i) = dy(BICmaxlag-i+1:T-i);
        end
        regs = [regs_cons regs_lag];
        SSR0total_1(k+1) = sum((depvar-regs*inv(regs'*regs)*regs'*depvar).^2);
        BICvalue_1(k+1) = log(SSR0total_1(k+1)/(length(depvar)))+(k)*log(length(depvar))/length(depvar);
    end
    [minBIC_1, minBICloc_1] = min(BICvalue_1);
    optlag_1 = minBICloc_1 - 1;
	SSR0_1 = SSR0total_1(minBICloc_1); 
	
	optlag = max(optlag_0,optlag_1);
    datevec = [];
	
elseif type == 1
    
	depvar = dy(BICmaxlag+1:T);
    regs = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
    [glb datevec matssr] = Ldate(depvar,regs,h,m);
    BICvalue(1) = log(glb(m)/(length(depvar)));
    savedate = [datevec];
    for lag = 1:BICmaxlag 
        regs_lag = zeros(T-BICmaxlag,lag);
        for i=1:lag;
            regs_lag(:,i)=dy(BICmaxlag-i+1:T-i);
        end;
        regs = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T) regs_lag];
        [glb datevec matssr] = Ldate(depvar,regs,h,m);        
        savedate = [savedate;datevec];        
        BICvalue(lag+1) = log(glb(m)/(length(depvar)))+(lag)*log(length(depvar))/length(depvar);
    end
    [minBIC, minBICloc] = min(BICvalue);
    optlag = minBICloc - 1;
    datevec = savedate((minBICloc - 1)*m+1:(minBICloc)*m,:);
    
end
end 

function [hi cvw pvh] = H(y,mb,eps,eta,optlag,BICmaxlag,brep,option)

T = length(y)-1;
if option == 'm'
    [Woutput] = W_compute(y,mb,optlag,eps,BICmaxlag);
	W1output = Woutput(1);
	W2output = Woutput(2);
	Wmax_output = max(Woutput);
    [BPoutput] = BP_compute(y,mb,optlag,eps,BICmaxlag);
	BP1output = BPoutput(1);
	BP2output = BPoutput(2); 
    BPUDmax_output = max(BPoutput);
    op = [W1output,BP1output,W2output,BP2output,Wmax_output,BPUDmax_output];
    
    bstat = zeros(brep,6);
    rng('shuffle')   %%%Try to ensure that MATLAB always gives different random numbers in separate runs
    parfor (n = 1:brep, 24)
 
        rndsmpl_1 = Genrndsmpl(T);
		rndsmpl_2 = Genrndsmpl(T);
        if optlag == 0
            ybootW_3 = Bootconstruc('W',y,optlag,1,rndsmpl_1);
			ybootBP_3 = Bootconstruc('BP',y,optlag,2,rndsmpl_2);
        else
            ybootW_3 = Bootconstruc('W',y,optlag,3,rndsmpl_1);
			ybootBP_3 = Bootconstruc('BP',y,optlag,3,rndsmpl_2);
        end;
        [Wboot_3] = W_compute(ybootW_3,mb,0,eps,BICmaxlag);
        W1boot_3 = Wboot_3(1);
		W2boot_3 = Wboot_3(2);
		maxWboot_3 = max(Wboot_3);
		
        [BPboot_3] = BP_compute(ybootBP_3,mb,0,eps,BICmaxlag);
        BP1boot_3 = BPboot_3(1);
		BP2boot_3 = BPboot_3(2);
		maxBPboot_3 = max(BPboot_3);
       
        bstat(n,:) = [W1boot_3, BP1boot_3, W2boot_3, BP2boot_3, maxWboot_3, maxBPboot_3];
    end;
 
	sort_bstat = sort(bstat);
	cv = sort_bstat(round(brep*(1-eta)),:);
	cvWmax = cv(5);
	cvBPmax = cv(6);
	hi = min(Wmax_output,cvWmax/cvBPmax*BPUDmax_output);
	cvw = cvWmax;
	pvhw = length(find(sort_bstat(:,5) > Wmax_output))/brep;
	pvhbp = length(find(sort_bstat(:,6) > BPUDmax_output))/brep;
	pvh = max(pvhw,pvhbp);

	
elseif option == '1'
    [W1output] = W_compute(y,1,optlag,eps,BICmaxlag);
    [BP1output] = BP_compute(y,1,optlag,eps,BICmaxlag);

    bstat = zeros(brep,2);
	rng('shuffle')
    parfor (n = 1:brep, 24)
        
        rndsmpl_1 = Genrndsmpl(T);
		rndsmpl_2 = Genrndsmpl(T);
        if optlag == 0
            ybootW_3 = Bootconstruc('W',y,optlag,1,rndsmpl_1);
			ybootBP_3 = Bootconstruc('BP',y,optlag,2,rndsmpl_2);
        else
            ybootW_3 = Bootconstruc('W',y,optlag,3,rndsmpl_1);
			ybootBP_3 = Bootconstruc('BP',y,optlag,3,rndsmpl_2);
        end;
        [W1boot_3] = W_compute(ybootW_3,1,0,eps,BICmaxlag);
		[BP1boot_3] = BP_compute(ybootBP_3,1,0,eps,BICmaxlag);		
       
        bstat(n,:) = [W1boot_3, BP1boot_3];
    end;
	
	sort_bstat = sort(bstat);
	cv = sort_bstat(round(brep*(1-eta)),:);
	cvW1 = cv(1);
	cvBP1 = cv(2);
	hi = min(W1output,cvW1/cvBP1*BP1output);
	cvw = cvW1;
	pvhw = length(find(sort_bstat(:,1) > W1output))/brep;
	pvhbp = length(find(sort_bstat(:,2) > BP1output))/brep;
	pvh = max(pvhw,pvhbp);

end
end

function [W, datevec] = W_compute(y,m,optlag,eps,BICmaxlag);

W = zeros(m,1);
T = length(y)-1;
h = round(eps*T);
dy = diff(y);

if  optlag ~= 0
    
    k = optlag;
    
	depvar = dy(BICmaxlag+1:T);
	regs_lag = zeros(T-BICmaxlag,k);
    regs_consy = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
	for i=1:k
        regs_lag(:,i)=dy(BICmaxlag-i+1:T-i);
    end	
    SSR0 = sum((depvar-regs_lag*inv(regs_lag'*regs_lag)*regs_lag'*depvar).^2);
    zx = [regs_consy,regs_lag];
    [glb datevec matssr] = Ldate(depvar,zx,h,m);
    [R1a R2a R3a R4a R5a R1b R2b R3b R4b R5b] = ResM(k);
    
    for j = 1:m
        eval(['[minssr',num2str(j),'a] = RLdate(depvar,regs_consy,regs_lag,h,R',num2str(j),...
            'a,datevec(',num2str(j),',1:',num2str(j),'),',num2str(j),');']);
        eval(['[minssr',num2str(j),'b] = RLdate(depvar,regs_consy,regs_lag,h,R',num2str(j),...
            'b,datevec(',num2str(j),',1:',num2str(j),'),',num2str(j),');']);
    end;
    
    for j = 1:m
        if mod(j,2) == 1
            eval(['[supf',num2str(j),'a] = (length(depvar)-',num2str(j),'-1-k)*(SSR0-minssr',num2str(j),'a)/((',...
                num2str(j),'+1)*minssr',num2str(j),'a);']);
            eval(['[supf',num2str(j),'b] = (length(depvar)-',num2str(j),'-1-k)*(SSR0-minssr',num2str(j),'b)/((',...
                num2str(j),'+1)*minssr',num2str(j),'b);']);
        elseif mod(j,2) == 0
            eval(['[supf',num2str(j),'a] = (length(depvar)-',num2str(j),'-k)*(SSR0-minssr',num2str(j),'a)/((',...
                num2str(j),')*minssr',num2str(j),'a);']);
            eval(['[supf',num2str(j),'b] = (length(depvar)-',num2str(j),'-2-k)*(SSR0-minssr',num2str(j),'b)/((',...
                num2str(j),'+2)*minssr',num2str(j),'b);']);
        end;
        eval(['W',num2str(j),' = ','max(supf',num2str(j),'a,supf',num2str(j),'b);']);
    end
    
    for j = 1:m
        eval(['W(',num2str(j),') = ','W',num2str(j),';']);
    end
    
elseif optlag == 0
    
    depvar = dy(BICmaxlag+1:T);
    SSR0 = sum((depvar).^2);
    
    regs_consy = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
    [glb datevec matssr] = Ldate(depvar,regs_consy,h,m);
    [R1a R2a R3a R4a R5a R1b R2b R3b R4b R5b] = ResM(0);
    
    for j = 1:m
        eval(['[minssr',num2str(j),'a] = RLdate(depvar,regs_consy,[],h,R',num2str(j),...
            'a,datevec(',num2str(j),',1:',num2str(j),'),',num2str(j),');']);
        eval(['[minssr',num2str(j),'b] = RLdate(depvar,regs_consy,[],h,R',num2str(j),...
            'b,datevec(',num2str(j),',1:',num2str(j),'),',num2str(j),');']);
    end;
    
    for j = 1:m
        if mod(j,2) == 1
            eval(['[supf',num2str(j),'a] = (length(depvar)-',num2str(j),'-1)*(SSR0-minssr',num2str(j),'a)/((',...
                num2str(j),'+1)*minssr',num2str(j),'a);']);
            eval(['[supf',num2str(j),'b] = (length(depvar)-',num2str(j),'-1)*(SSR0-minssr',num2str(j),'b)/((',...
                num2str(j),'+1)*minssr',num2str(j),'b);']);
            
        elseif mod(j,2) == 0
            eval(['[supf',num2str(j),'a] = (length(depvar)-',num2str(j),')*(SSR0-minssr',num2str(j),'a)/((',...
                num2str(j),')*minssr',num2str(j),'a);']);
            eval(['[supf',num2str(j),'b] = (length(depvar)-',num2str(j),'-2)*(SSR0-minssr',num2str(j),'b)/((',...
                num2str(j),'+2)*minssr',num2str(j),'b);']);
        end
        eval(['W',num2str(j),' = ','max(supf',num2str(j),'a,supf',num2str(j),'b);']);
    end
    
    for j = 1:m
        eval(['W(',num2str(j),') = ','W',num2str(j),';']);
    end
end
end

function [BP, datevec] = BP_compute(y,m,optlag,eps,BICmaxlag);

BP = zeros(m,1);
T = length(y)-1;
h = round(eps*T);
dy = diff(y);

if  optlag ~= 0
    
    k = optlag;
    depvar = dy(BICmaxlag+1:T);
    regs = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
	regs_lag = zeros(T-BICmaxlag,k);
    regs_consy = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
    for i=1:k
        regs_lag(:,i)=dy(BICmaxlag-i+1:T-i);
    end
    [glb datevec matssrnl] = Nldate(depvar,regs_consy,regs_lag,h,m);
    regs = [regs_consy regs_lag];
    SSR0 = sum((depvar-regs*inv(regs'*regs)*regs'*depvar).^2);
    
    for i = 1:m
        BP(i) = (length(depvar)-(i+1)*2-k)./(i*2)*(SSR0-glb(i))/glb(i);
    end
    
    
elseif optlag == 0

    depvar = dy(BICmaxlag+1:T);
    regs = [ones(T-BICmaxlag,1) y(BICmaxlag+1:T)];
    SSR0 = sum((depvar-regs*inv(regs'*regs)*regs'*depvar).^2);
    regs_consy = regs;
    [glb datevec matssr] = Ldate(depvar,regs_consy,h,m);
    for i = 1:m
        BP(i) = (length(depvar)-(i+1)*2)./(i*2)*(SSR0-glb(i))/glb(i);
    end
    
end
end

function rndsmpl = Genrndsmpl(T);
rndsmpl = (rand(T,1)>=0.5)*(-2)+1;
end

function [glb datevec matssr] = Ldate(y,z,h,m)
% This is the main procedure which calculates the break points that globally
% minimizes the SSR. It returns optiomal dates and associated SSR for all
% numbers of breaks less than or equal to m.
T = length(y);
datevec = zeros(m,m);
glb = zeros(m,1);
matssr = Ssr(y,z,h,T);
optssr = zeros(m,T);
optdt = zeros(m,T);

for j = 2*h:T
    b1 = h;
    b2 = j-h;
    dvec = zeros(T,1);
    for ii = b1:b2
        dvec(ii,1) = matssr(1,ii)+matssr(ii+1,j);
    end
    [ssr_tmp dt_tmp] = min(dvec(b1:b2,1));
    optssr(1,j) = ssr_tmp;
    optdt(1,j) = dt_tmp+b1-1;
end
glb(1) = optssr(1,T);
datevec(1,1:1) = optdt(1,T);

for ib=2:m
    for j = (ib+1)*h:T
        b1 = ib*h;
        b2 = j-h;
        dvec = zeros(T,1);
        for ii = b1:b2
            dvec(ii,1) = optssr(ib-1,ii)+matssr(ii+1,j);
        end
        [ssr_tmp dt_tmp] = min(dvec(b1:b2,1));
        optssr(ib,j) = ssr_tmp;
        optdt(ib,j) = dt_tmp+b1-1;
    end
    glb(ib) = optssr(ib,T);
    datevec(ib,ib) = optdt(ib,T);
    for i = 1:ib-1
        datevec(ib,ib-i) = optdt(ib-i,datevec(ib,ib-i+1));
    end
end
end

function [glb datevec matssrnl] = Nldate(y,z,x,h,m)
p = size(x,2);
q = size(z,2);
datevec = zeros(m,m);
glb = zeros(m,1);
epsconv = 0.0001;
mi = 1;
while mi <= m
    
    qq = p+q;
    xz = [x z];
    
    [globnl datenl matssrnl] = Ldate(y,xz,h,m);
    
    xbar = pzbar(x,mi,datenl(mi,1:mi)');
    zbar = pzbar(z,mi,datenl(mi,1:mi)');
    regs = [zbar xbar];
    teta = inv(regs'*regs)*regs'*y;
    delta1 = teta(1:q*(mi+1),1);
    depvar = y-zbar*delta1;
    beta1 = inv(x'*x)*x'*depvar;
    
    % Calculate SSR
    ssr1=(y-x*beta1-zbar*delta1)'*(y-x*beta1-zbar*delta1);
           
    % Starting the iterations.    
    length=99999999.0;
    i=1;
    maxi = 100;
    
    while length > epsconv   
	
        [globnl datenl matssrnl] = Ldate(y-x*beta1,z,h,mi);        
        zbar=pzbar(z,mi,datenl(mi,1:mi)');
        regs = [x zbar];
        teta1 = inv(regs'*regs)*regs'*y;
        beta1 = teta1(1:p,1);
        delta1 = teta1(p+1:p+q*(mi+1),1);
        ssrn = (y-regs*teta1)'*(y-regs*teta1);
        
        % Calculate overall SRR and check if significantly smaller.        
        length = abs(ssrn-ssr1);
        
        if i >= maxi
            disp('The number of iterations has reached the upper limit');
        else
            i = i+1;
            ssr1 = ssrn;
            glb(mi) = ssrn;
            datevec(mi,1:mi) = datenl(mi,1:mi);
        end
        
    end
    mi = mi+1;
	%disp(['The number of iteration is: ' num2str(i-1)]);
end
end

function zb=pzbar(zz,m,bb)
% procedure to construct the diagonal partition of z with m break at date b.
[nt,q1]=size(zz);
zb=zeros(nt,(m+1)*q1);
zb(1:bb(1,1),1:q1)=zz(1:bb(1,1),:);
i=2;
while i <= m
    zb(bb(i-1,1)+1:bb(i,1),(i-1)*q1+1:i*q1)=zz(bb(i-1,1)+1:bb(i,1),:);
    i=i+1;
end
zb(bb(m,1)+1:nt,m*q1+1:(m+1)*q1)=zz(bb(m,1)+1:nt,:);
end

function [R1a R2a R3a R4a R5a R1b R2b R3b R4b R5b] = ResM(p)
if p ~= 0

R1a = [[eye(2),zeros(2,2*p+2)];[zeros(p,2),eye(p),zeros(p,2),-eye(p)]];

R2a_p1 = [zeros(p,4+p),eye(p),zeros(p,2),-eye(p)];
R2a_p2 = [zeros(2,4+2*p),eye(2),zeros(2,p)];
R2a = [R1a, zeros(size(R1a,1),2+p);R2a_p1;R2a_p2];

R3a_p1 = [zeros(p,6+2*p),eye(p),zeros(p,2),-eye(p)];
R3a = [R2a, zeros(size(R2a,1),2+p);R3a_p1];

R4a_p1 = [zeros(p,8+3*p),eye(p),zeros(p,2),-eye(p)];
R4a_p2 = [zeros(2,8+4*p),eye(2),zeros(2,p)];
R4a = [R3a, zeros(size(R3a,1),2+p);R4a_p1;R4a_p2];

R5a_p1 = [zeros(p,10+4*p),eye(p),zeros(p,2),-eye(p)];
R5a = [R4a, zeros(size(R4a,1),2+p);R5a_p1];

R1b = [[zeros(p,2),eye(p),zeros(p,2),-eye(p)];[zeros(2,2+p),eye(2),zeros(2,p)]];

R2b_p1 = [zeros(p,4+p),eye(p),zeros(p,2),-eye(p)];
R2b = [R1b, zeros(size(R1b,1),2+p);R2b_p1];

R3b_p1 = [zeros(2,6+3*p),eye(2),zeros(2,p)];
R3b_p2 = [zeros(p,6+2*p),eye(p),zeros(p,2),-eye(p)];
R3b = [R2b, zeros(size(R2b,1),2+p);R3b_p1;R3b_p2];

R4b_p1 = [zeros(p,8+3*p),eye(p),zeros(p,2),-eye(p)];
R4b = [R3b, zeros(size(R3b,1),2+p);R4b_p1];

R5b_p1 = [zeros(2,10+5*p),eye(2),zeros(2,p)];
R5b_p2 = [zeros(p,10+4*p),eye(p),zeros(p,2),-eye(p)];
R5b = [R4b, zeros(size(R4b,1),2+p);R5b_p1;R5b_p2];
    
else
    
R1a = [eye(2),zeros(2,2)];

R2a_p1 = [];
R2a_p2 = [zeros(2,4),eye(2)];
R2a = [R1a, zeros(size(R1a,1),2);R2a_p1;R2a_p2];

R3a_p1 = [];
R3a = [R2a, zeros(size(R2a,1),2);R3a_p1];

R4a_p1 = [];
R4a_p2 = [zeros(2,8),eye(2)];
R4a = [R3a, zeros(size(R3a,1),2);R4a_p1;R4a_p2];

R5a_p1 = [];
R5a = [R4a, zeros(size(R4a,1),2);R5a_p1];

R1b = [zeros(2,2),eye(2)];

R2b_p1 = [];
R2b = [R1b, zeros(size(R1b,1),2);R2b_p1];

R3b_p1 = [zeros(2,6),eye(2)];
R3b_p2 = [];
R3b = [R2b, zeros(size(R2b,1),2);R3b_p1;R3b_p2];

R4b_p1 = [];
R4b = [R3b, zeros(size(R3b,1),2);R4b_p1];

R5b_p1 = [zeros(2,10),eye(2)];
R5b_p2 = [];
R5b = [R4b, zeros(size(R4b,1),2);R5b_p1;R5b_p2];
    
end
end

function [minssr optdate] = RLdate(y,z,x,h,R,datevec,m)   
% This is the main procedure which calculates the break points that globally
% minimizes the SSR. It returns optiomal dates and associated SSR for all
% numbers of breaks less than or equal to m.
zx = [z x];
maxi = 100;
diff = 0;
i1 = 0;
while diff ~= -1
    
    zxdiag = pzbar(zx,m,datevec');
    r = zeros(size(R,1),1);
    bhat = inv(zxdiag'*zxdiag)*zxdiag'*y;
    btild = inv(zxdiag'*zxdiag)*R'*inv(R*inv(zxdiag'*zxdiag)*R')*(r-R*bhat)+bhat;
    [optrssr optrdt] = Rssrmin(y,z,x,h,btild,m);
    if i1 >= maxi
        disp('The number of iterations has reached the upper limit');
		optdate = optrdt;
        minssr = optrssr;
        break
    end
    i1 = i1+1;
    if optrdt == datevec;
        diff = -1;
        optdate = optrdt;
        minssr = optrssr;
    end
    datevec = optrdt;	
end
end

function [optrssr optrdt] = Rssrmin(y,z,x,h,btild,m);   %%%delta1 means the parameters for one break, delta2 means for 2 breaks

T = length(y);
p = size(x,2);
zx = [z x];
datevec = zeros(m,m);
glb = zeros(m,1);
optssr = zeros(m,T);
optdt = zeros(m,T);
for j = 2*h:T
    b1 = h;
    b2 = j-h;
    dvec = zeros(T,1);
    for ii = b1:b2
        s1 = sum((y(1:ii)- zx(1:ii,:)*btild(1:p+2)).^2);
        s2 = sum((y(ii+1:j)- zx(ii+1:j,:)*btild(p+3:2*p+4)).^2);
        dvec(ii,1) = s1+s2;
    end
    [ssr_tmp dt_tmp] = min(dvec(b1:b2,1));
    optssr(1,j) = ssr_tmp;
    optdt(1,j) = dt_tmp+b1-1;
end
glb(1) = optssr(1,T);
datevec(1,1:1) = optdt(1,T);
optrssr = glb(1);
optrdt = datevec(1,1:1);
if m ~= 1
    for ib=2:m
        for j = (ib+1)*h:T
            b1 = ib*h;
            b2 = j-h;
            dvec = zeros(T,1);
            for ii = b1:b2
                s2 = sum((y(ii+1:j)- zx(ii+1:j,:)*btild(ib*(p+2)+1:(ib+1)*(p+2))).^2);
                dvec(ii,1) = optssr(ib-1,ii)+s2;
            end
            [ssr_tmp dt_tmp] = min(dvec(b1:b2,1));
            optssr(ib,j) = ssr_tmp;
            optdt(ib,j) = dt_tmp+b1-1;
        end
        glb(ib) = optssr(ib,T);
        datevec(ib,ib) = optdt(ib,T);
        for i = 1:ib-1
            datevec(ib,ib-i) = optdt(ib-i,datevec(ib,ib-i+1));
        end
    end
end
optrssr = glb(m);
optrdt = datevec(m,1:m);
end

function matssr = Ssr(y,z,h,T)
% y: dependent variable
% z: matrix of regressors of dimension q
% h: minimal length of a segment
matssr=zeros(T,T);
% initialize the recursion with the first h data points.
for i = 1:T-h+1
    
    inv1 = inv(z(i:i+h-1,:)'*z(i:i+h-1,:));
    delta1 = inv1*(z(i:i+h-1,:)'*y(i:i+h-1,1));
    res = y(i:i+h-1,1)-z(i:i+h-1,:)*delta1;
    matssr(i,i+h-1) = res'*res;
    
    % loop to construct the recursive residuals and update the SSR
    
    r = i+h;
    while r <= T
        v = y(r,1)-z(r,:)*delta1;
        invz = inv1*z(r,:)';
        f = 1+z(r,:)*invz;
        delta2 = delta1+(invz*v)/f;
        inv2 = inv1-(invz*invz')/f;
        inv1 = inv2;
        delta1 = delta2;
        matssr(i,r) = matssr(i,r-1)+v*v/f;
        r = r+1;
    end    
end
end

function Bsmp = Bootconstruc(type,y,optlag,Btype,rndsmpl);
T = length(y)-1;
dy = diff(y);
if Btype == 1     %%%% Bootstrap demeaned residuals in BP and AR(1)residuals in W
    
    if type == 'BP'
        
        error = y(2:T+1)-mean(y(2:T+1));
        Bsmp = error.*rndsmpl;
        Bsmp = [0;Bsmp];
		
    elseif type == 'W'
        
        error = dy(1:T);
        eps_boot = error.*rndsmpl;
        Bsmp = zeros(T,1);
        Bsmp(1) = eps_boot(1);
        for i = 2:T
            Bsmp(i) = Bsmp(i-1) + eps_boot(i);
        end;
        Bsmp = [0;Bsmp];
    end;
    
elseif Btype == 2    %%%%Bootstrap AR(1) residuals in both BP and W
    
    if type == 'BP'
        
        depvar = dy(1:T);
        regs = [ones(T,1) y(1:T)];
        error = depvar - regs*inv(regs'*regs)*regs'*depvar;
        Bsmp = error.*rndsmpl;
        Bsmp = [0;Bsmp];
        
    elseif type == 'W'
        
        error = dy(1:T);
        eps_boot = error.*rndsmpl;
        Bsmp = zeros(T,1);
        Bsmp(1) = eps_boot(1);
        for i = 2:T
            Bsmp(i) = Bsmp(i-1) + eps_boot(i);
        end;
        Bsmp = [0;Bsmp];
    end;
    
elseif Btype == 3   %%%%Bootstrap AR(k) residuals in both BP and W
    
    if type == 'BP'
        
        k = optlag;
        depvar = dy(k+1:T);
        regs_lag = zeros(T-k,k);
        for i=1:k
            regs_lag(:,i)=dy(k-i+1:T-i);
        end;
        regs_consy = [ones(T-k,1) y(k+1:T)];
        regs = [regs_consy regs_lag];
        error = depvar-regs*inv(regs'*regs)*regs'*depvar;        
        Bsmp = error.*rndsmpl(k+1:T);
        Bsmp = [zeros(k+1,1);Bsmp];
        
    elseif type == 'W'
        
        k = optlag;
        depvar = dy(k+1:T);
        regs_lag = zeros(T-k,k);
        for i=1:k
            regs_lag(:,i)=dy(k-i+1:T-i);
        end;
        error = depvar-regs_lag*inv(regs_lag'*regs_lag)*regs_lag'*depvar;
        eps_boot = error.*rndsmpl(k+1:T);
        Bsmp = zeros(length(y),1);
        for i = k+2:T+1               
            Bsmp(i) = Bsmp(i-1) + eps_boot(i-k-1);
        end;
    end;
    
else
    disp('Warning: Input is wrong, please check your inputs.')   
end
end










