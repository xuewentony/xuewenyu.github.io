%  FigureD1D2.m
%  
%  This program uses err_modelsel.mat generated from Table1and2.m.

clc; clear all;
countrynames = { ...
    'Austria'; 'Belgium'; 'Canada'; 'Finland'; ...
    'France'; 'Germany'; 'Greece'; 'Italy'; ...
    'Japan'; 'Korea'; 'Luxembourg'; 'Netherlands'; ...
    'Norway'; 'Portugal'; 'Spain'; 'Sweden'; ...
    'Switzerland'; 'UK'; 'USA';};
load err_modelsel.mat; cpool = [0.25; 0.4; 0.6; 0.75]; 
%%Figure D-1 nonparametric volatility estimates
figure;
for num = 1:19
    eval(['errall=err',num2str(num),';']);
    errall(find(isnan(errall))) = []; len = length(errall);
    sigmasq = npvol_esti(errall,cpool); sigmasq = sigmasq/mean(sigmasq);
    omit = 580-len;
    if omit ~= 0
        dd = datetime(1960,2,28)+ calmonths(1:omit);
    else
        dd = datetime(1960,2,28);
    end
    newdd = dd(end) + calmonths(1:len); b = [1:len]';
    subplot(5,4,num); plot(newdd,sigmasq); if num ==1 ylabel('volatility intensity','interpreter','latex'); end
    title(strcat('$',countrynames(num,:),'$'),'interpreter','latex');
    %title(countrynames(num,:));
end
saveas(gcf,'Figure-D1.jpg'); saveas(gcf,'Figure-D1','epsc');

%%Figure D-2 variance profile
figure;
for num = 1:19
    eval(['errall=err',num2str(num),';']);
    errall(find(isnan(errall))) = []; errall = errall.^2;
    len = length(errall); new = zeros(len,1);
    for i = 1:length(new)
        new(i) = (sum(errall(1:i)))/sum(errall);
    end
    b = [0:1/(length(new)-1):1]';
    subplot(5,4,num); plot(b,new,b,b,'--')
    title(strcat('$',countrynames(num,:),'$'),'interpreter','latex');
    %title(countrynames(num,:));
end
saveas(gcf,'Figure-D2.jpg'); saveas(gcf,'Figure-D2','epsc');