% This function coducts the ols estimation. 

function [beta resid varcov robvarcov0 robvarcov5] = ols(y,x);

[T, k] = size(x);
invxx = inv(x'*x);
beta = invxx*x'*y;
resid = y-x*beta;
sigsq = resid'*resid/(T-k);
varcov = sigsq*invxx;
p = diag(x*invxx*x');
pstar = min(p,1/sqrt(T));
residnew = resid./(ones(T,1)-pstar);
robvarcov0 = invxx*x'*diag(resid.^2)*x*invxx;
robvarcov5 = invxx*x'*diag(residnew.^2)*x*invxx;

end


