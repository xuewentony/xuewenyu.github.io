clc; clear all;
totaltime = tic;
model_name = 'BreakResult_table1'; save(model_name);
rng('default'); rng(1000); load data.csv;
for i=1:19
    tic
    disp(['Country ', num2str(i), ' is currently running']);
    cpi = data(:,i); y = 1200*(log(cpi(2:end,1))-log(cpi(1:end-1,1)));
    mb = 5; eps = .15; eta = .1; BICmaxlag = 8; brep = 400;
    [realb tmpnt pvall] = detnumbreak(y,mb,eps,eta,BICmaxlag,brep);
    total = [tmpnt, [realb; NaN(4,1)]; pvall];
    eval(['br',num2str(i),'=total;']);
    save(model_name,strcat(['br',num2str(i)]),'-append');
    toc
end
totaltimespend = toc(totaltime);
disp('The bootstrap procedures are finished for all 19 countries.');