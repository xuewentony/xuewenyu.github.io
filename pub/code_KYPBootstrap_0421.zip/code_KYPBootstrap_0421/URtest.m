% This function conducts the Cavaliere and Taylor (2009) bootstrap unit root 
% test reported in the last columns of table 1 and 2 in the paper.

function [t, stb, re,k,betaar, sebeta] = URtest(Y,lag,type)
T = length(Y)-1;
if type == 1
    y = Y-mean(Y);
elseif type == 2
    trend = [ones(T+1,1), [1:T+1]'];
    y = Y-trend*inv(trend'*trend)*trend'*Y;
end
k = lag; dy = diff(y);
depvar = dy(k+1:T);
if k ~= 0
    regs_lag = zeros(T-k,k);
    for i=1:k
        regs_lag(:,i)=dy(k-i+1:T-i);
    end;
    regs = [y(k+1:T), regs_lag];
else
    regs = [y(k+1:T)];
end
invx = inv(regs'*regs); beta = invx*regs'*depvar;
betaar = 1+beta(1); error = depvar-regs*beta;
varcov = error'*error/(T-k)*invx; sebeta = sqrt(varcov(1,1));
t = (beta(1))/sqrt(varcov(1,1)); tball = zeros(499,1);
for b = 1:499    
    if k ~= 0
        regs_lag = zeros(T-k,k);
        for i=1:k;
            regs_lag(:,i)=dy(k-i+1:T-i);
        end;
        regs = [regs_lag]; invx = inv(regs'*regs);
        beta = invx*regs'*depvar; error = depvar-regs*beta;
        err_new = error.*randn(length(error),1); Bsmp = zeros(T+1,1);
        for i = k+2:T+1
            Bsmp(i) = Bsmp(i-1) + beta'*flipud(diff(Bsmp(i-k-1:i-1)))+err_new(i-k-1);
        end;
    else
        error = dy(1:T); eps_boot = error.*randn(length(error),1);
        Bsmp = zeros(T,1); Bsmp(1) = eps_boot(1);
        for i = 2:T
            Bsmp(i) = Bsmp(i-1) + eps_boot(i);
        end;
        Bsmp = [0;Bsmp];
    end
    tb = ADF(Bsmp,type); tball(b) = tb;
end
stb = sort(tball); re = length(find(t >= stb))/499;
end

%%% --- Below are some functions built in the main function URtest.m ---
function t = ADF(Y,type)
T = length(Y)-1;
if type == 1
    y = Y-mean(Y);
elseif type == 2
    trend = [ones(T+1,1), [1:T+1]'];
    y = Y-trend*inv(trend'*trend)*trend'*Y;
end
kmin = 0; kmax = round(12*(T/100)^(1/4));
penalty = 0; [kopt] = s2ar(y,penalty,kmax,kmin);
k = kopt; dy = diff(y);
depvar = dy(k+1:T);
if k ~= 0
    regs_lag = zeros(T-k,k);
    for i=1:k
        regs_lag(:,i)=dy(k-i+1:T-i);
    end;
    regs = [y(k+1:T), regs_lag];
else
    regs = [y(k+1:T)];
end
invx = inv(regs'*regs); beta = invx*regs'*depvar;
error = depvar-regs*beta; varcov = error'*error/(T-k)*invx;
t = (beta(1))/sqrt(varcov(1,1));
end

function [kopt, beta, resid] = s2ar(yts,penalty,kmax,kmin);

nt = length(yts);
tau = zeros(kmax+1,1);
s2e = 999*ones(kmax+1,1);
dyts = [0; diff(yts,1)];
reg = lagn(yts,1);
i=1;
while i <= kmax
    reg = [reg, lagn(dyts,i)];
    i=i+1;
end
dyts0 = dyts;
reg0 = reg;
%loop over k%
dyts0 = dyts(kmax+2:end,:);
reg0 = reg(kmax+2:end,:);
sumy = sum(reg0(:,1).*reg0(:,1));
nef = nt-kmax-1;
k = kmin;
while k <= kmax
    %[b,e,fit]=olsqr2(dyts0,reg0[.,1:k+1]);%
	%b = dyts0/reg0(:,1:k+1);
    b = inv(reg0(:,1:k+1)'*reg0(:,1:k+1))*reg0(:,1:k+1)'*dyts0;
    e = dyts0-reg0(:,1:k+1)*b;
    s2e(k+1) = e'*e/nef;
    tau(k+1) = (b(1)*b(1))*sumy/s2e(k+1);
    k=k+1;
end
kk = [0:kmax]';

if penalty == 0
    mic=log(s2e)+2.0*(kk+tau)./nef;
else
    mic=log(s2e)+log(nef)*(kk)./nef;
end
[minv, minloc] = max(-mic);
kopt = minloc -1;

beta = inv(reg0(:,1:kopt+1)'*reg0(:,1:kopt+1))*reg0(:,1:kopt+1)'*dyts0;
resid = dyts0-reg0(:,1:kopt+1)*beta;
end

function y = lagn(x,n);
if n > 0
    y = [zeros(n,length(x(1,:)));x(1:end-n,:)];
end
end